# Pocket Arcade

A collection of original browser games. Everything runs as plain HTML and JavaScript, so no build step is needed.

| Folder | Game |
|---|---|
| `pocket-arcade/` | The main arcade: 2D, 3D, versus, board games and a play-money casino (including Baccarat and Street Craps) |
| `vanguard-squad/` | First-person 5v5 hero shooter with 41 heroes |
| `clash-point/` | Red vs Blue team shooter with party mode (1v1 to 5v5) |
| `swat-city/` | 3D superhero fly brawler in a destructible city |
| `rush-kitchen/` | 3D multi-floor restaurant tycoon |
| `pack-rat-cards/` | 3D trading card shop sim |
| `tycoon-town/` | 3D business empire tycoon |
| `blockbreaker-brawl/` | Mine, build and blast arena game |
| `lucky-lounge/` | Play-chip Baccarat and Street Craps |

## Play it

Open `index.html` in a browser, or turn on **GitHub Pages** (Settings → Pages → Deploy from branch → `main` / root). Your games will then be live at `https://<your-username>.github.io/<repo-name>/`.

## What works outside Claude

Gameplay, saving progress and local best scores work anywhere. Online features (shared leaderboards, live co-op, Clash Point multiplayer and party mode, online board-game parties) use Claude's artifact services, so they only work when the games are opened from their claude.ai links. On GitHub Pages the games quietly fall back to offline play.

The casino games use pretend chips only. There is no real money anywhere.
