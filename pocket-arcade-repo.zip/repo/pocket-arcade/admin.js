/* Admin panel. Unlock: tap the POCKET ARCADE title 5 times, then enter the code. */
const ADMIN_CODE='ADMIN2026';
let cashTaint=(()=>{try{return localStorage.getItem('pa_cashtaint')==='1'}catch(e){return false}})();
/* Cheated scores stay off the shared leaderboard */
{const realPost=lbPost;lbPost=function(k,v){if(ADM.used)return;if(k==='cash'&&cashTaint)return;return realPost(k,v)}}
function taint(){ADM.used=true}
function bankTaint(){cashTaint=true;try{localStorage.setItem('pa_cashtaint','1')}catch(e){}taint()}

const G=id=>GAMES.find(g=>g.id===id);
const ADMX={
  snake:[['Grow +5',g=>{for(let i=0;i<5;i++)g.body.push(g.body[g.body.length-1].slice())}]],
  brick:[['Clear all but one brick',g=>{let k=0;g.b.forEach(b=>{if(!b.dead&&k++)b.dead=1})}]],
  merge:[['Drop a 1024 tile',g=>{const e=g.b.map((v,i)=>v?-1:i).filter(i=>i>=0);if(e.length)g.b[e[0]]=1024}],['Drop a 2048 tile',g=>{const e=g.b.map((v,i)=>v?-1:i).filter(i=>i>=0);if(e.length)g.b[e[0]]=2048}]],
  drop:[['Clear bottom 4 rows',g=>{g.b.splice(14,4);while(g.b.length<18)g.b.unshift(Array(10).fill(0))}],['Next piece: long bar',g=>{g.next='I'}]],
  echo:[['Replay the pattern',g=>{g.ph='show';g.si=0;g.tm=30}]],
  putt:[['Hole in one',g=>{const L=HOLES[g.hole];g.bx=L.h[0];g.by=L.h[1];g.vx=g.vy=0}]],
  stacker:[['Widen moving slab',g=>{g.m.w=Math.min(W,g.m.w+80)}]],
  cliff:[['Rescue: drop back on land',g=>{g.y=120;g.vy=0;g.j=0;g.pl.unshift({x:0,w:300,y:400})}]],
  bounce:[['Rocket bounce',g=>{g.vy=-28}]],
  swarm:[['Clear the sky',g=>{setScore(score+g.f.length);g.f.forEach(f=>f.dead=1)}]],
  rocks:[['Shatter all rocks',g=>{setScore(score+g.r.length);g.r.forEach(r=>r.dead=1)}]],
  slice:[['Remove all bombs',g=>{g.o=g.o.filter(o=>!o.bomb)}]],
  tug:[['Blue wins the pull',g=>{g.cd=0;g.r=.99}],['Pink wins the pull',g=>{g.cd=0;g.r=-.99}]],
  maze:[['Teleport to goal',g=>{g.b.position.x=g.goal.position.x;g.b.position.z=g.goal.position.z}]],
  stack3:[['Perfect drop',g=>{g.mv[g.ax]=g.bl[g.bl.length-1][g.ax];g.drop()}]],
  bowl:[['Strike!',g=>{g.pins.forEach(p=>{if(p.visible){p.userData.fall=1;p.userData.vx=.01}});g.st='settle';g.tm=30;g.ball.position.z=-23}]],
  hoops:[['Swish shot',g=>{if(g.st!=='ready')g.ready();g.shoot(g.hx/45/.25,.38)}]],
  guard:[['Wipe out crawlers',g=>{setScore(score+g.en.length);g.en.forEach(e=>e.userData.hp=0)}]],
  raid:[['Nuke the fleet',g=>{setScore(score+g.en.length);g.en.forEach(e=>e.userData.hp=0)}]],
  lava:[['Restore the whole floor',g=>g.ti.forEach(t=>{t.st=0;t.t=0;t.m.visible=true;t.m.material.color.setHex(0x4a4258)})]],
  sumo:[['Knock Pink off',g=>{g.fall[1]=1}],['Knock Blue off',g=>{g.fall[0]=1}]],
  pair:[['Peek at every card (2s)',g=>{if(!g.deck)return;g.deck.forEach(c=>{if(!c.up&&!c.done)c.el.textContent=c.i});setTimeout(()=>g.deck.forEach(c=>{if(!c.up&&!c.done)c.el.textContent=''}),2000)}]],
};
/* how each game's score is really stored, so "add score" sticks */
const ADDSC={cliff:(g,n)=>g.d+=n*10,tunnel:(g,n)=>g.d+=n,bounce:(g,n)=>g.h+=n*10,dodge:(g,n)=>g.bonus+=n,dash:(g,n)=>g.bonus+=n,lava:(g,n)=>g.coins+=n/5,merge:(g,n)=>{g.pts+=n;setScore(g.pts)}};

/* modal */
const admM=document.createElement('div');admM.id='admM';admM.hidden=true;admM.setAttribute('role','dialog');admM.setAttribute('aria-label','Admin panel');admM.innerHTML='<div id="admBox"></div>';document.body.appendChild(admM);
admM.addEventListener('pointerdown',e=>{if(e.target===admM)admClose()});
let admMode='panel';
function admOpen(mode){admMode=mode||'panel';admM.hidden=false;if(admMode==='panel'){ADM.wasRunning=running;}admRender();if(admMode==='code')setTimeout(()=>{const i=$('admCode');i&&i.focus()},50)}
function admClose(){admM.hidden=true}
function inGame(){return cur&&!$('play').hidden}
function admRender(){const box=$('admBox');
  if(admMode==='code'){box.innerHTML=`<div class="aHd"><h3>🔧 Admin access</h3><button class="aB" data-x="close">Close</button></div>
    <form id="admForm"><label for="admCode">Enter admin code</label><input id="admCode" autocomplete="off" autocapitalize="characters" spellcheck="false"><button class="aB gold" type="submit">Unlock</button><p class="aNote" id="admErr"></p></form>`;
    $('admForm').onsubmit=e=>{e.preventDefault();const v=$('admCode').value.toUpperCase().replace(/[^A-Z0-9]/g,'');
      if(v===ADMIN_CODE){ADM.on=true;try{localStorage.setItem('pa_admin','1')}catch(_){}admSync();admMode='panel';admRender();beep(880,.2,'triangle')}else{$('admErr').textContent='That code is not right.';beep(150,.2,'sawtooth')}};
    box.querySelector('[data-x=close]').onclick=admClose;return}
  const g=inGame()?cur:null,cat=g&&g.cat,solo=g&&(cat==='2ds'||cat==='3ds'||cat==='3dc'),vs=g&&(cat==='2dv'||cat==='3dv'),cas=cat==='casino';
  const tog=(k,l)=>`<button class="aB ${ADM[k]?'on':''}" data-x="t_${k}">${l}: ${ADM[k]?'ON':'OFF'}</button>`;
  let h=`<div class="aHd"><h3>🔧 Admin${g?' · '+g.name:''}</h3><button class="aB" data-x="close">Close</button></div>`;
  if(g&&!g.dom){h+=`<div class="aSec"><h4>Game control</h4><div class="aRow">${solo?tog('god','God mode'):''}${tog('freeze','Freeze')}${tog('party','Party colors')}<button class="aB" data-x="restart">Restart game</button></div>
    <div class="aRow"><span class="aL">Speed</span>${[.25,.5,1,1.5,2,3].map(s=>`<button class="aB sm ${ADM.speed===s?'on':''}" data-x="sp_${s}">${s}x</button>`).join('')}</div></div>`}
  if(solo&&g.id!=='rush'){h+=`<div class="aSec"><h4>Score & lives</h4><div class="aRow">${[10,100,1000,10000].map(n=>`<button class="aB" data-x="sc_${n}">+${n.toLocaleString()}</button>`).join('')}</div><div class="aRow"><input id="admSc" inputmode="numeric" placeholder="Exact score"><button class="aB gold" data-x="scset">Set score</button></div><div class="aRow"><button class="aB" data-x="lives">Max lives & time</button></div></div>`}
  if(g&&ADMT[g.id]){h+=`<div class="aSec"><h4>${g.name} cheats · stay on</h4><div class="aRow">${ADMT[g.id].map(([k,l])=>`<button class="aB ${ADM.tg.has(g.id+':'+k)?'on':''}" data-x="tg_${k}">${l}: ${ADM.tg.has(g.id+':'+k)?'ON':'OFF'}</button>`).join('')}</div></div>`}
  if(vs&&Array.isArray(g.sc)){h+=`<div class="aSec"><h4>Scoreboard</h4><div class="aRow"><button class="aB blue" data-x="vs_0">+1 Blue</button><button class="aB red" data-x="vs_1">+1 ${g.cpu?'CPU':'Pink'}</button><button class="aB" data-x="vs_r">Reset score</button></div></div>`}
  if(g&&ADMX[g.id]){h+=`<div class="aSec"><h4>${g.name} tools</h4><div class="aRow">${ADMX[g.id].map((a,i)=>`<button class="aB gold" data-x="gx_${i}">${a[0]}</button>`).join('')}</div></div>`}
  if(g&&['mines','gmines','bj','holdem','hilo'].includes(g.id))h+=`<div class="aSec"><h4>Vision</h4><div class="aRow">${tog('xray',g.id==='bj'?'See dealer card':g.id==='holdem'?'See bot cards':g.id==='hilo'?'See next card':'See mines')}</div></div>`;
  if(!g||cas){h+=`<div class="aSec"><h4>Casino bank · ${money(CASH)}</h4><div class="aRow"><input id="admCash" inputmode="numeric" placeholder="Amount"><button class="aB gold" data-x="cset">Set bank</button></div>
    <div class="aRow"><button class="aB" data-x="c_1000">+$1,000</button><button class="aB" data-x="c_100000">+$100,000</button><button class="aB" data-x="c_1000000">+$1,000,000</button><button class="aB red" data-x="creset">Reset to $1,000</button></div></div>`}
  if(cas||!g){h+=`<div class="aSec"><h4>Casino cheats · every game</h4><div class="aRow">${tog('luck','Lucky mode (always win)')}${tog('freebets','Free bets')}</div></div>`}
  if(cas){const f=ADM.forced,fl=k=>k in f?' <b>(armed)</b>':'';let r='';
    if(g.id==='roul')r=`<div class="aRow"><input id="admN" inputmode="numeric" placeholder="0-36"><button class="aB gold" data-x="f_roul">Next number${fl('roul')}</button></div>`;
    if(g.id==='pwheel')r=`<div class="aRow"><button class="aB gold" data-x="f_pwheel">Next spin hits 7x${fl('pwheel')}</button></div>`;
    if(g.id.startsWith('s_'))r=`<div class="aRow"><button class="aB gold" data-x="f_slots">Next spin is the jackpot${fl('slots')}</button></div>`;
    if(g.id==='dice')r=`<div class="aRow">${[2,3,7,11,12].map(n=>`<button class="aB sm" data-x="fd_${n}">${n}</button>`).join('')}<span class="aL">next total${fl('dice')}</span></div>`;
    if(g.id==='crash')r=`<div class="aRow"><input id="admCp" inputmode="decimal" placeholder="e.g. 50"><button class="aB gold" data-x="f_crash">Next crash at${fl('crash')}</button></div>`;
    if(g.id==='scratch')r=`<div class="aRow"><button class="aB gold" data-x="f_scratch">Next card wins 💰 50x${fl('scratch')}</button></div>`;
    if(r)h+=`<div class="aSec"><h4>Rig the next result</h4>${r}</div>`}
  if(!g)h+=`<div class="aSec"><h4>Arcade</h4><div class="aRow"><button class="aB red" data-x="wipe">Reset all my best scores</button></div></div>`;
  h+=`<p class="aNote">${ADM.used||cashTaint?'Admin tools were used, so scores from this session (and an edited bank) stay off the shared leaderboard. Your local bests still save.':'Using admin tools keeps that session\'s scores off the shared leaderboard.'}</p>
    <div class="aRow"><button class="aB" data-x="lock">Lock admin (hide 🔧)</button></div>`;
  box.innerHTML=h;
  box.querySelectorAll('[data-x]').forEach(b=>b.onclick=()=>admAct(b.dataset.x))}
function admAct(x){const g=inGame()?cur:null;
  if(x==='close')return admClose();
  if(x==='lock'){ADM.on=false;ADM.god=ADM.freeze=ADM.xray=ADM.luck=ADM.freebets=ADM.party=false;ADM.tg.clear();$('stage').classList.remove('party');ADM.speed=1;try{localStorage.removeItem('pa_admin')}catch(e){}admSync();return admClose()}
  if(x==='restart'){admClose();start(g.mode);return}
  if(x==='scset'){const v=parseInt(($('admSc').value||'').replace(/[^0-9]/g,''),10);if(Number.isFinite(v)){taint();const d=v-(+score||0);if(ADDSC[g.id])ADDSC[g.id](g,d);else setScore(v)}}
  else if(x.startsWith('tg_')){const k=g.id+':'+x.slice(3);ADM.tg.has(k)?ADM.tg.delete(k):ADM.tg.add(k);taint()}
  else if(x.startsWith('t_')){const k=x.slice(2);ADM[k]=!ADM[k];if(k==='luck'||k==='freebets')bankTaint();else if(k!=='freeze'&&k!=='party')taint();if(k==='party')$('stage').classList.toggle('party',ADM.party);if(g&&g.dom&&g.render)g.render()}
  else if(x.startsWith('sp_')){ADM.speed=+x.slice(3);if(ADM.speed>1)taint()}
  else if(x.startsWith('sc_')){const n=+x.slice(3);taint();if(ADDSC[g.id])ADDSC[g.id](g,n);else setScore((+score||0)+n)}
  else if(x==='lives'){taint();for(const k of['lives','hp'])if(typeof g[k]==='number')g[k]=Math.max(g[k],99);if(typeof g.time==='number')g.time+=60*60;if(typeof g.left==='number'&&g.m&&g.m.time)g.left+=60;
    if(g.id==='lava')g.pl.forEach(p=>{if(p.userData.dead){p.userData={dead:0,vy:0};p.visible=true;p.position.set(0,0,0)}})}
  else if(x.startsWith('vs_')){const k=x.slice(3);taint();if(k==='r')g.sc.fill(0);else g.sc[+k]++;vsScore(...g.sc)}
  else if(x.startsWith('gx_')){if(!g.dom&&!running)return admRender();taint();try{ADMX[g.id][+x.slice(3)][1](g)}catch(e){}if(g.dom&&g.render)g.render()}
  else if(x==='cset'){const v=parseFloat(($('admCash').value||'').replace(/[^0-9.]/g,''));if(Number.isFinite(v)){bankTaint();CASH=0;cashAdd(Math.min(v,1e12))}}
  else if(x.startsWith('c_')){bankTaint();cashAdd(+x.slice(2))}
  else if(x==='creset'){CASH=0;cashAdd(1000);cashTaint=false;try{localStorage.removeItem('pa_cashtaint')}catch(e){}}
  else if(x==='f_roul'){const n=parseInt($('admN').value,10);if(n>=0&&n<=36){ADM.forced.roul=n;bankTaint()}}
  else if(x==='f_pwheel'){ADM.forced.pwheel=PW.findIndex(s=>s.m===7);bankTaint()}
  else if(x==='f_slots'){ADM.forced.slots=1;bankTaint()}
  else if(x.startsWith('fd_')){ADM.forced.dice=+x.slice(3);bankTaint()}
  else if(x==='f_crash'){const v=parseFloat($('admCp').value);if(v>=1){ADM.forced.crash=Math.round(v*100)/100;bankTaint()}}
  else if(x==='f_scratch'){ADM.forced.scratch=1;bankTaint()}
  else if(x==='wipe'){try{Object.keys(localStorage).filter(k=>k.startsWith('pa_')&&!['pa_cash','pa_cbet','pa_admin','pa_cashtaint'].includes(k)).forEach(k=>localStorage.removeItem(k))}catch(e){}refreshBest()}
  if(g&&g.cat==='casino'&&g.render)g.render();cashUI();beep(660,.04);admRender()}
function admSync(){$('admBtn').hidden=!ADM.on;$('admLobby').hidden=!ADM.on}
/* unlock gesture: tap the title 5 times quickly */
{let taps=[];document.querySelector('header h1').addEventListener('click',()=>{const t=performance.now();taps=taps.filter(x=>t-x<2500);taps.push(t);if(taps.length>=5){taps=[];admOpen(ADM.on?'panel':'code')}})}
$('admBtn').onclick=()=>admOpen('panel');$('admLobby').onclick=()=>admOpen('panel');
admSync();
