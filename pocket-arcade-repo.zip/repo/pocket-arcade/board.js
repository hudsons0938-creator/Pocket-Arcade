/* BOARD GAMES framework: bots (easy/medium/hard) · pass & play · online parties.
   Online sync: each party is a named room. Players publish {seat, gid, mv, t, rs} as presence;
   the longest valid move list that extends ours wins, so late joiners and reconnects catch up. */
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const PCODE='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const BLV=[['EASY'],['MEDIUM'],['HARD']];
const BW={get(k){try{return +localStorage.getItem('pa_bw_'+k)||0}catch(e){return 0}},inc(k){try{localStorage.setItem('pa_bw_'+k,BW.get(k)+1)}catch(e){}}};
const PNAMES={};
function pname(by){if(!by)return'Player';if(by in PNAMES)return PNAMES[by]||'Player';const u=LB.user;if(!u||!u.profiles)return'Player';PNAMES[by]='';
  u.profiles([by]).then(ps=>{PNAMES[by]=(ps&&ps[by]&&ps[by].name)||'Player';if(cur&&cur.cat==='board'&&!$('play').hidden){cur.ui==='menu'?cur.renderList():cur.render()}}).catch(()=>{PNAMES[by]='Player'});return'Player'}
function bGrid(cls,cols,rows,flip,cell){let h='';const n=cols*rows;for(let k=0;k<n;k++)h+=cell(flip?n-1-k:k);return `<div class="bgrid ${cls}" style="grid-template-columns:repeat(${cols},1fr);aspect-ratio:${cols}/${rows}">${h}</div>`}
const bCell=(i,cls,inner,label)=>`<button class="bc ${cls}" data-c="${i}" aria-label="${label}">${inner}</button>`;
/* generic negamax for games without their own engine; handles extra turns (same side moves again) */
function negamax(G,s,d,a,be,ev){const r=G.end(s);if(r)return r.w<0?0:(r.w===G.turn(s)?1e6+d:-1e6-d);if(d<=0)return ev(s);
  const ms=G.moves(s);if(!ms.length)return ev(s);
  for(const m of ms){const n=G.play(s,m);const v=G.turn(n)===G.turn(s)?negamax(G,n,d-1,a,be,ev):-negamax(G,n,d-1,-be,-a,ev);if(v>=be)return be;if(v>a)a=v}return a}
function rootPick(G,s,d,ev,noise=0,order){let ms=G.moves(s);if(order)ms=order(ms);let best=ms[0],bv=-Infinity;
  for(const m of ms){const n=G.play(s,m);const same=G.turn(n)===G.turn(s);const v=(same?negamax(G,n,d-1,-Infinity,Infinity,ev):-negamax(G,n,d-1,-Infinity,-bv+noise,ev))+rnd(0,noise);if(v>bv){bv=v;best=m}}return best}

function boardGame(def){return Object.assign({cat:'board',dom:true,how:'Play a bot, pass and play on one device, or join an online party.',
  init(){const d=$('dom');d.classList.add('cas');d.onclick=e=>this.onTap(e);this.netLeave();this.ui='menu';this.pside=this.pside??0;this.lvl=this.lvl??1;setScore('');this.render();
    if(!this.lobW&&room){try{this.lobW=room.onPeers(()=>{if(cur===this&&this.ui==='menu')this.renderList()})}catch(e){}}},
  leave(){this.netLeave();if(this.lobW){try{this.lobW()}catch(e){}this.lobW=null}this.tok=(this.tok||0)+1},
  L(s){if(this._ls!==s){this._ls=s;this._lm=this.moves(s)}return this._lm},
  onTap(e){const c=e.target.closest('[data-c]');if(c){this.cellTap(+c.dataset.c);return}const b=e.target.closest('[data-a]');if(b&&!b.disabled)this.act(b.dataset.a)},
  newGame(){this.S=this.start();this.hist=[];this.last=null;this.sel=null;this.done=null;this.think=false;this.tok=(this.tok||0)+1;this.nmvKey=null},
  act(a){
    if(a.startsWith('side')){this.pside=+a.slice(4);return this.render()}
    if(a.startsWith('bot')){this.lvl=+a.slice(3);this.pm='bot';this.me=this.pside===2?(Math.random()<.5?0:1):this.pside;this.ui='play';this.newGame();this.render();return this.maybeBot()}
    if(a==='local'){this.pm='local';this.me=0;this.ui='play';this.newGame();return this.render()}
    if(a==='create')return this.netStart(this.code(),true);
    if(a==='quick'){const o=this.parties().find(p=>p.o);return o?this.netStart(o.c,false):this.netStart(this.code(),true)}
    if(a.startsWith('j:'))return this.netStart(a.slice(2),false);
    if(a==='menu'){this.netLeave();this.ui='menu';this.tok++;return this.render()}
    if(a==='again'){this.newGame();this.render();return this.maybeBot()}
    if(a==='undo')return this.undo();
    if(a==='resign'){if(this.pm==='net'){const n=this.net;if(n&&n.seat>=0){n.rs=n.gid;this.netPush();this.netSync()}}else{this.tok++;this.think=false;this.done={w:this.pm==='bot'?1-this.me:1-this.turn(this.S),why:'Resigned.'};this.render()}return}
    if(a==='rematch'){const n=this.net;if(!n)return;n.gid++;n.mv=[];n.rs=null;this.netPush();return this.netSync()}
    if(a==='seat'){const n=this.net;if(!n)return;n.seat=-1;return this.netClaim()}
    if(a==='copy'){const code=this.net&&this.net.code;try{navigator.clipboard.writeText(code).then(()=>{this.msg2='Code '+code+' copied. Send it to a friend.';this.render()},()=>{this.msg2='Party code: '+code;this.render()})}catch(e){this.msg2='Party code: '+code;this.render()}return}
  },
  undo(){if(this.pm==='net'||!this.hist.length)return;this.tok++;this.think=false;
    if(this.pm==='bot'){do{this.S=this.hist.pop()}while(this.hist.length&&this.turn(this.S)!==this.me)}else this.S=this.hist.pop();
    this.done=null;this.sel=null;this.last=null;this.render();this.maybeBot()},
  canAct(){if(this.done||this.think||!this.S)return false;const t=this.turn(this.S);if(this.pm==='local')return true;if(this.pm==='bot')return t===this.me;
    if(this.pm==='net'){const n=this.net;return!!(n&&n.rn&&n.seat===t&&this.hold&&this.hold[0]&&this.hold[1])}return false},
  cellTap(c){if(!this.canAct())return;const ms=this.L(this.S);let m=null;
    if(this.kind==='ft'){if(this.sel!=null)m=ms.find(x=>x.f===this.sel&&x.t===c);if(!m){this.sel=ms.some(x=>x.f===c)?(this.sel===c?null:c):null;beep(600,.02);return this.render()}}
    else m=this.pickCell?this.pickCell(this.S,ms,c):ms.find(x=>x.t===c);
    if(m)this.doMove(m)},
  doMove(m){this.hist.push(this.S);this.S=this.play(this.S,m);this.last=m;this.sel=null;beep(this.turn(this.S)?520:440,.04);
    if(this.pm==='net'&&this.net){this.net.mv.push(m.k);this.nmvKey=this.net.mv.join(' ');this.netPush()}
    this.checkEnd();this.render();this.maybeBot();this.maybePass()},
  checkEnd(){if(this.done)return;const r=this.end(this.S);if(r){this.done=r;if(this.pm==='bot'&&r.w===this.me)BW.inc(this.id);beep(r.w<0?440:880,.25,'triangle')}},
  maybeBot(){if(this.pm!=='bot'||this.done||this.turn(this.S)===this.me)return;this.think=true;const tok=++this.tok;this.render();
    setTimeout(()=>{if(cur!==this||tok!==this.tok)return;let m=null;try{m=this.bot(this.S,this.lvl)}catch(e){console.error(e)}if(tok!==this.tok)return;this.think=false;
      if(!m){const ms=this.L(this.S);m=ms[Math.random()*ms.length|0]}if(m)this.doMove(m);else this.render()},420)},
  maybePass(){if(this.done||!this.canAct())return;const ms=this.L(this.S);if(ms.length===1&&ms[0].k==='pass'){const tok=++this.tok;this.msg2='No moves available, so this turn passes.';this.render();
    setTimeout(()=>{if(cur===this&&tok===this.tok&&this.canAct()&&this.L(this.S)[0].k==='pass')this.doMove(this.L(this.S)[0])},1100)}},
  who(i){if(this.pm==='bot')return i===this.me?'You':'Bot';if(this.pm==='net'){const n=this.net;if(n&&i===n.seat)return'You';const h=this.hold&&this.hold[i];return h?pname(h.by):'Open seat'}return this.sides[i]},
  status(){if(!this.S)return'';if(this.done){const r=this.done;if(r.w<0)return'Draw. '+r.why;const nm=this.who(r.w);
      return(nm==='You'?'You win! ':nm==='Bot'?'The bot wins. ':this.pm==='local'?this.sides[r.w]+' wins! ':nm+' ('+this.sides[r.w]+') wins! ')+r.why}
    const t=this.turn(this.S);if(this.think)return'Bot is thinking…';
    if(this.pm==='net'){if(!this.net||!this.net.rn)return'Connecting…';if(!this.hold||!this.hold[0]||!this.hold[1])return this.net.seat<0?'Waiting for players…':'Waiting for an opponent to join. Share code '+this.net.code+'.'}
    const x=this.badge?this.badge(this.S):'';const nm=this.who(t);return(nm==='You'?'Your move':this.pm==='local'?this.sides[t]+' to move':nm+' to move')+(this.pm!=='local'?' · '+this.sides[t]:'')+(x?' · '+x:'')},
  ctx(){const act=this.canAct(),ms=act?this.L(this.S):[],tg=new Set(),hint=new Set(),from=new Set();
    if(this.kind==='ft'){ms.forEach(m=>{from.add(m.f);if(m.f===this.sel)tg.add(m.t)})}else ms.forEach(m=>{if(m.t>=0)hint.add(m.t)});
    const vs=this.pm==='bot'?this.me:this.pm==='net'&&this.net?Math.max(0,this.net.seat):0;return{sel:this.sel,tg,hint,from,last:this.last,flip:!!this.flip&&vs===1,act,vs}},
  render(){if(cur!==this||$('play').hidden&&this.ui!=='menu')return;const d=$('dom');
    if(this.ui==='menu'){d.innerHTML=this.menuHTML();return this.afterMenu()}
    const n=this.net,t=this.S?this.turn(this.S):0;const chips=[0,1].map(i=>`<i class="${i===t&&!this.done?'on':''}">${esc(this.sides[i])}: ${esc(this.who(i))}</i>`).join('');
    const top=this.pm==='net'?`<div class="pbar"><span>PARTY <b>${esc(n?n.code:'')}</b></span><button class="cb sq" data-a="copy">COPY CODE</button><span class="ppl">${chips}${this.spect?`<i>👀 ${this.spect} watching</i>`:''}</span></div>`
      :`<div class="pbar"><span>${this.pm==='bot'?'VS BOT · '+BLV[this.lvl][0]:'PASS & PLAY'}</span><span class="ppl">${chips}</span></div>`;
    const B=(a,l,c='',dis=false)=>`<button class="cb ${c}" data-a="${a}" ${dis?'disabled':''}>${l}</button>`;let bt='';
    if(this.pm==='net'){const seated=n&&n.seat>=0,full=this.hold&&this.hold[0]&&this.hold[1];
      if(n&&n.rn&&!seated&&!full)bt+=B('seat','TAKE A SEAT','gold');if(seated&&!this.done&&full)bt+=B('resign','RESIGN','red');if(seated&&this.done)bt+=B('rematch','REMATCH','gold');bt+=B('menu','LEAVE PARTY')}
    else bt=B('undo','UNDO','',!this.hist.length)+(this.done?'':B('resign','RESIGN','red'))+B('again','NEW GAME','gold')+B('menu','MENU');
    d.innerHTML=`<div class="casino bgame">${top}<div class="cmsg">${esc(this.status())}${this.msg2?`<br><small>${esc(this.msg2)}</small>`:''}</div>${this.S?this.view(this.S,this.ctx()):''}<div class="crow">${bt}</div></div>`;this.msg2=''},
  menuHTML(){const B=(a,l,c='')=>`<button class="cb ${c}" data-a="${a}">${l}</button>`;
    return `<div class="casino bmenu"><div class="bhead"><canvas id="bart" width="128" height="96"></canvas><div><h3>${this.name}</h3><p>${this.desc}</p><small>WINS VS BOTS · ${BW.get(this.id)}</small></div></div>
      ${this.flash?`<div class="cmsg warn">${esc(this.flash)}</div>`:''}
      <div class="bsec"><h4>PLAY A BOT</h4><div class="crow">${[0,1,2].map(i=>`<button class="cb sq ${this.pside===i?'gold':''}" data-a="side${i}">${i<2?'AS '+this.sides[i].toUpperCase():'RANDOM SIDE'}</button>`).join('')}</div>
        <div class="crow">${B('bot0','EASY')}${B('bot1','MEDIUM','blue')}${B('bot2','HARD','red')}</div></div>
      <div class="bsec"><h4>PASS & PLAY</h4><div class="crow">${B('local','2 PLAYERS · 1 DEVICE')}</div></div>
      <div class="bsec"><h4>ONLINE PARTY</h4>${room?`<div class="crow">${B('quick','QUICK MATCH','gold')}${B('create','CREATE PARTY')}</div>
        <form class="crow" id="joinF"><input id="pcode" maxlength="4" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="CODE" aria-label="Party code"><button class="cb" type="submit">JOIN</button></form>
        <div id="bpList" class="plist"></div><p class="bnote">Quick Match drops you into an open party, or opens one for the next person. Anyone can watch a full party. Friends need this page shared with them to join.</p>`
        :`<p class="bnote">Online parties work when this page is opened in Claude while signed in. Bots and pass & play work everywhere.</p>`}</div></div>`},
  afterMenu(){this.flash='';const c=$('bart');if(c&&c.getContext){const x=c.getContext('2d');x.fillStyle='#0c0a14';x.fillRect(0,0,128,96);try{this.art(x)}catch(e){}}
    const f=$('joinF');if(f)f.onsubmit=e=>{e.preventDefault();const v=(($('pcode')||{}).value||'').toUpperCase().replace(/[^A-Z0-9]/g,'');if(v.length!==4){this.flash='Party codes are 4 letters or numbers.';return this.render()}this.netStart(v,false)};this.renderList()},
  parties(){if(!room)return[];const seen={},out=[];for(const p of room.peers()){const bp=p.presence&&p.presence.bp;if(!bp||p.sameTab||bp.g!==this.id||typeof bp.c!=='string'||!/^[A-Z0-9]{4}$/.test(bp.c)||seen[bp.c])continue;seen[bp.c]=1;out.push({c:bp.c,o:!!bp.o,by:p.by})}return out.sort((a,b)=>b.o-a.o)},
  renderList(){const el=$('bpList');if(!el)return;const ps=this.parties();el.innerHTML=ps.length?ps.map(p=>`<div class="prow"><span><b>${p.c}</b> · ${esc(pname(p.by))} · ${p.o?'1 seat open':'full'}</span><button class="cb sq ${p.o?'gold':''}" data-a="j:${p.c}">${p.o?'JOIN':'WATCH'}</button></div>`).join(''):'<p class="bnote">No parties for this game right now. Create one and it shows up here for everyone.</p>'},
  code(){let s='';for(let i=0;i<4;i++)s+=PCODE[Math.random()*PCODE.length|0];return s},
  async netStart(code,host){if(!room){this.flash='Online parties need this page opened in Claude while signed in.';return this.render()}
    this.netLeave();this.ui='play';this.pm='net';this.newGame();const n=this.net={code,rn:null,seat:-1,gid:0,mv:[],t:Date.now(),rs:null};this.hold=[null,null];this.spect=0;this.msg2='Connecting to party '+code+'…';this.render();
    let rn;try{rn=await room.join(('pab-'+this.id+'-'+code).toLowerCase())}catch(e){if(cur===this&&this.net===n){this.net=null;this.ui='menu';this.flash=e&&e.code==='not_permitted'?'Online parties are not available on this account.':'Could not reach that party. Check your connection and try again.';this.render()}return}
    if(cur!==this||this.net!==n){rn.leave().catch(()=>{});return}
    n.rn=rn;n.unsub=rn.onPeers(()=>this.netSync());
    if(host){n.seat=0;n.t=Date.now();this.netPush();this.netSync()}else{this.msg2='Joining party '+code+'…';this.render();setTimeout(()=>{if(this.net===n)this.netClaim()},1400)}},
  netClaim(){const n=this.net;if(!n||!n.rn)return;const ps=n.rn.peers().filter(p=>!p.sameTab);const taken=s=>ps.some(p=>p.presence&&p.presence.seat===s);
    if(n.seat<0){if(!taken(0))n.seat=0;else if(!taken(1))n.seat=1}n.t=Date.now();this.netPush();this.netSync()},
  netPush(){const n=this.net;if(!n||!n.rn)return;const mv=n.mv.join(' '),ch=[];for(let i=0;i<mv.length;i+=900)ch.push(mv.slice(i,i+900));
    n.rn.presence({seat:n.seat,gid:n.gid,mv:ch,t:n.t,rs:n.rs}).catch(()=>{});this.lobbyAd()},
  lobbyAd(){const n=this.net;if(!room||!n)return;const full=!!(this.hold&&this.hold[0]&&this.hold[1]);const bp=n.seat>=0?{g:this.id,c:n.code,o:full?0:1}:null;const j=JSON.stringify(bp);
    if(j!==this.adJ){this.adJ=j;room.presence({bp}).catch(()=>{})}},
  netLeave(){const n=this.net;if(!n)return;this.net=null;try{n.unsub&&n.unsub()}catch(e){}if(n.rn)n.rn.leave().catch(()=>{});this.adJ=null;if(room)room.presence({bp:null}).catch(()=>{})},
  netSync(){const n=this.net;if(!n||!n.rn||cur!==this)return;const P=p=>p.presence||{};
    const others=n.rn.peers().filter(p=>!p.sameTab&&p.kind!=='agent');const me={peer:'~me',by:null,presence:{seat:n.seat,t:n.t}};const all=others.concat([me]);
    const hold=[null,null];for(const s of[0,1]){const cl=all.filter(p=>P(p).seat===s).sort((a,b)=>((+P(a).t||0)-(+P(b).t||0))||(a.peer<b.peer?-1:1));hold[s]=cl[0]||null}
    let ch=false;if(n.seat>=0&&hold[n.seat]!==me){n.seat=-1;ch=true;this.msg2='Someone else took that seat first. You are watching.'}
    let gid=n.gid;for(const p of others){const g=+P(p).gid;if(Number.isFinite(g)&&g>gid&&g<1e6)gid=Math.floor(g)}if(gid>n.gid){n.gid=gid;n.mv=[];n.rs=null;ch=true;this.done=null}
    let best=n.mv;for(const h of hold){if(!h||h===me||+P(h).gid!==n.gid)continue;const raw=Array.isArray(P(h).mv)?P(h).mv.filter(x=>typeof x==='string').join(''):'';const list=raw?raw.split(' ').slice(0,1500):[];
      if(list.length>best.length&&best.every((k,i)=>k===list[i]))best=list}
    if(best!==n.mv){n.mv=best.slice();ch=true}
    const key=n.mv.join(' ');if(key!==this.nmvKey){let S=this.start(),last=null,ok=0;const hist=[];for(const k of n.mv){const m=this.L(S).find(x=>x.k===k);if(!m)break;hist.push(S);S=this.play(S,m);last=m;ok++}
      if(ok!==n.mv.length){n.mv=n.mv.slice(0,ok);ch=true}this.S=S;this.hist=hist;this.last=last;this.sel=null;this.nmvKey=n.mv.join(' ')}
    this.hold=hold;this.spect=others.filter(p=>P(p).seat!==0&&P(p).seat!==1).length;
    let rsd=null;for(const s of[0,1]){const h=hold[s];if(!h)continue;const rv=h===me?n.rs:+P(h).rs;if(rv===n.gid&&(h===me||+P(h).gid===n.gid))rsd=s}
    const was=!!this.done;this.done=this.end(this.S)||(rsd!=null?{w:1-rsd,why:this.sides[rsd]+' resigned.'}:null);if(this.done&&!was)beep(this.done.w===n.seat?880:330,.25,'triangle');
    if(ch)this.netPush();else this.lobbyAd();this.render();this.maybePass()}
},def)}
