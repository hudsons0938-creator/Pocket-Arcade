/* CHESS — full rules (castling, en passant, auto-queen, check, mate, stalemate, 50-move, repetition, insufficient material) */
const CGL={K:'♚',Q:'♛',R:'♜',B:'♝',N:'♞',P:'♟'};
const CP={P:100,N:320,B:330,R:500,Q:900,K:0};
const PST={P:[0,0,0,0,0,0,0,0,50,50,50,50,50,50,50,50,10,10,20,30,30,20,10,10,5,5,10,25,25,10,5,5,0,0,0,20,20,0,0,0,5,-5,-10,0,0,-10,-5,5,5,10,10,-20,-20,10,10,5,0,0,0,0,0,0,0,0],
 N:[-50,-40,-30,-30,-30,-30,-40,-50,-40,-20,0,0,0,0,-20,-40,-30,0,10,15,15,10,0,-30,-30,5,15,20,20,15,5,-30,-30,0,15,20,20,15,0,-30,-30,5,10,15,15,10,5,-30,-40,-20,0,5,5,0,-20,-40,-50,-40,-30,-30,-30,-30,-40,-50],
 B:[-20,-10,-10,-10,-10,-10,-10,-20,-10,0,0,0,0,0,0,-10,-10,0,5,10,10,5,0,-10,-10,5,5,10,10,5,5,-10,-10,0,10,10,10,10,0,-10,-10,10,10,10,10,10,10,-10,-10,5,0,0,0,0,5,-10,-20,-10,-10,-10,-10,-10,-10,-20],
 R:[0,0,0,0,0,0,0,0,5,10,10,10,10,10,10,5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,0,0,0,5,5,0,0,0],
 Q:[-20,-10,-10,-5,-5,-10,-10,-20,-10,0,0,0,0,0,0,-10,-10,0,5,5,5,5,0,-10,-5,0,5,5,5,5,0,-5,0,0,5,5,5,5,0,-5,-10,5,5,5,5,5,0,-10,-10,0,5,0,0,0,0,-10,-20,-10,-10,-5,-5,-10,-10,-20],
 K:[-30,-40,-40,-50,-50,-40,-40,-30,-30,-40,-40,-50,-50,-40,-40,-30,-30,-40,-40,-50,-50,-40,-40,-30,-30,-40,-40,-50,-50,-40,-40,-30,-20,-30,-30,-40,-40,-30,-30,-20,-10,-20,-20,-20,-20,-20,-20,-10,20,20,0,0,0,0,20,20,20,30,10,0,0,10,30,20],
 KE:[-50,-40,-30,-20,-20,-30,-40,-50,-30,-20,-10,0,0,-10,-20,-30,-30,-10,20,30,30,20,-10,-30,-30,-10,30,40,40,30,-10,-30,-30,-10,30,40,40,30,-10,-30,-30,-10,20,30,30,20,-10,-30,-30,-30,0,0,0,0,-30,-30,-50,-30,-30,-30,-30,-30,-30,-50]};
const KN=[[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]],KG=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]],DB=[[-1,-1],[-1,1],[1,-1],[1,1]],DR=[[-1,0],[1,0],[0,-1],[0,1]],DQ=DB.concat(DR);
const isW=p=>p>='A'&&p<='Z';
const sqn=i=>'abcdefgh'[i&7]+(8-(i>>3));
function chAtt(b,sq,byW){const r=sq>>3,c=sq&7,pr=byW?r+1:r-1,P=byW?'P':'p';
  if(pr>=0&&pr<8){if(c>0&&b[pr*8+c-1]===P)return true;if(c<7&&b[pr*8+c+1]===P)return true}
  const N=byW?'N':'n',K=byW?'K':'k',B=byW?'B':'b',R=byW?'R':'r',Q=byW?'Q':'q';
  for(const[dr,dc]of KN){const rr=r+dr,cc=c+dc;if(rr>=0&&rr<8&&cc>=0&&cc<8&&b[rr*8+cc]===N)return true}
  for(const[dr,dc]of KG){const rr=r+dr,cc=c+dc;if(rr>=0&&rr<8&&cc>=0&&cc<8&&b[rr*8+cc]===K)return true}
  for(const[dr,dc]of DB){let rr=r+dr,cc=c+dc;while(rr>=0&&rr<8&&cc>=0&&cc<8){const p=b[rr*8+cc];if(p){if(p===B||p===Q)return true;break}rr+=dr;cc+=dc}}
  for(const[dr,dc]of DR){let rr=r+dr,cc=c+dc;while(rr>=0&&rr<8&&cc>=0&&cc<8){const p=b[rr*8+cc];if(p){if(p===R||p===Q)return true;break}rr+=dr;cc+=dc}}
  return false}
function chPseudo(s){const b=s.b,w=s.t===0,o=[],add=(f,t,fl)=>o.push({f,t,fl,k:sqn(f)+sqn(t)}),en=q=>q&&isW(q)!==w;
  for(let i=0;i<64;i++){const p=b[i];if(!p||isW(p)!==w)continue;const P=p.toUpperCase(),r=i>>3,c=i&7;
    if(P==='P'){const d=w?-1:1,r1=r+d;if(r1<0||r1>7)continue;const f1=r1*8+c;
      if(!b[f1]){add(i,f1);if(r===(w?6:1)&&!b[f1+8*d])add(i,f1+8*d,'d')}
      for(const dc of[-1,1]){const cc=c+dc;if(cc<0||cc>7)continue;const t=r1*8+cc;if(en(b[t]))add(i,t);else if(t===s.ep)add(i,t,'e')}}
    else if(P==='N'||P==='K'){for(const[dr,dc]of P==='N'?KN:KG){const rr=r+dr,cc=c+dc;if(rr<0||rr>7||cc<0||cc>7)continue;const t=rr*8+cc;if(!b[t]||en(b[t]))add(i,t)}
      if(P==='K'&&i===(w?60:4)&&!chAtt(b,i,!w)){const R=w?'R':'r';
        if(s.cas.includes(w?'K':'k')&&!b[i+1]&&!b[i+2]&&b[i+3]===R&&!chAtt(b,i+1,!w)&&!chAtt(b,i+2,!w))add(i,i+2,'k');
        if(s.cas.includes(w?'Q':'q')&&!b[i-1]&&!b[i-2]&&!b[i-3]&&b[i-4]===R&&!chAtt(b,i-1,!w)&&!chAtt(b,i-2,!w))add(i,i-2,'q')}}
    else for(const[dr,dc]of P==='B'?DB:P==='R'?DR:DQ){let rr=r+dr,cc=c+dc;while(rr>=0&&rr<8&&cc>=0&&cc<8){const t=rr*8+cc;if(!b[t])add(i,t);else{if(en(b[t]))add(i,t);break}rr+=dr;cc+=dc}}}
  return o}
function chMake(s,m){const b=s.b.slice(),p=b[m.f],w=s.t===0,cap=b[m.t];let cas=s.cas,ep=-1,hm=s.hm+1;b[m.t]=p;b[m.f]='';
  if(p==='P'||p==='p'){hm=0;if(m.fl==='d')ep=(m.f+m.t)>>1;if(m.fl==='e')b[m.t+(w?8:-8)]='';const rr=m.t>>3;if(rr===0||rr===7)b[m.t]=w?'Q':'q'}
  if(cap)hm=0;if(m.fl==='k'){b[m.t-1]=b[m.t+1];b[m.t+1]=''}if(m.fl==='q'){b[m.t+1]=b[m.t-2];b[m.t-2]=''}
  if(p==='K')cas=cas.replace(/[KQ]/g,'');if(p==='k')cas=cas.replace(/[kq]/g,'');
  for(const[sq,ch]of[[63,'K'],[56,'Q'],[7,'k'],[0,'q']])if(m.f===sq||m.t===sq)cas=cas.replace(ch,'');
  return{b,t:1-s.t,cas,ep,hm,rep:s.rep}}
function chLegal(s){const w=s.t===0;return chPseudo(s).filter(m=>{const n=chMake(s,m);return!chAtt(n.b,n.b.indexOf(w?'K':'k'),!w)})}
const chCheck=s=>chAtt(s.b,s.b.indexOf(s.t===0?'K':'k'),s.t!==0);
function chEval(b){let np=0;for(const p of b)if(p&&'NBRQnbrq'.includes(p))np+=CP[p.toUpperCase()];const eg=np<=2600;let s=0;
  for(let i=0;i<64;i++){const p=b[i];if(!p)continue;const P=p.toUpperCase(),w=isW(p),idx=w?i:((7-(i>>3))*8+(i&7));const v=CP[P]+(P==='K'?(eg?PST.KE:PST.K)[idx]:PST[P][idx]);s+=w?v:-v}return s}
function chOrder(s,ms){const b=s.b;for(const m of ms){const v=b[m.t];m.o=(v?CP[v.toUpperCase()]*10-CP[b[m.f].toUpperCase()]/10:0)+(m.fl==='e'?900:0)+(((b[m.f]==='P'&&m.t<8)||(b[m.f]==='p'&&m.t>55))?8000:0)}return ms.sort((x,y)=>y.o-x.o)}
function chQ(s,a,be,qd){const sp=(s.t===0?1:-1)*chEval(s.b);if(sp>=be)return be;if(sp>a)a=sp;if(qd<=0)return a;
  const ms=chOrder(s,chLegal(s).filter(m=>s.b[m.t]||m.fl==='e'));for(const m of ms){const v=-chQ(chMake(s,m),-be,-a,qd-1);if(v>=be)return be;if(v>a)a=v}return a}
function chNeg(s,d,a,be,ply){const ms=chLegal(s);if(!ms.length)return chCheck(s)?-100000+ply:0;if(s.hm>=100)return 0;if(d<=0)return chQ(s,a,be,4);
  chOrder(s,ms);for(const m of ms){const v=-chNeg(chMake(s,m),d-1,-be,-a,ply+1);if(v>=be)return be;if(v>a)a=v}return a}
const chKey=s=>s.b.join(',')+s.t+s.cas+s.ep;
add(boardGame({id:'chess',name:'CHESS',c:'--a1',kind:'ft',flip:true,sides:['White','Black'],desc:'The classic. Full rules with castling, en passant and checkmate.',
  art(c){c.fillStyle='#ecd9b4';c.fillRect(0,0,128,96);c.fillStyle='#a87650';for(let r=0;r<6;r++)for(let k=0;k<8;k++)if((r+k)%2)c.fillRect(k*16,r*16,16,16);c.font='30px serif';c.fillStyle='#111';c.fillText('♚',22,54);c.fillStyle='#fff';c.strokeStyle='#222';c.fillText('♛',70,70);c.strokeText('♛',70,70)},
  start(){const b='rnbqkbnrpppppppp'.split('').concat(Array(32).fill(''),'PPPPPPPPRNBQKBNR'.split(''));const s={b,t:0,cas:'KQkq',ep:-1,hm:0,rep:{}};s.rep[chKey(s)]=1;return s},
  turn:s=>s.t,moves:s=>chLegal(s),
  play(s,m){const n=chMake(s,m);const k=chKey(n);n.rep=Object.assign({},s.rep);n.rep[k]=(n.rep[k]||0)+1;return n},
  end(s){if(!chLegal(s).length)return chCheck(s)?{w:1-s.t,why:'Checkmate!'}:{w:-1,why:'Stalemate.'};if(s.hm>=100)return{w:-1,why:'50 moves without a capture or pawn move.'};
    if(s.rep&&s.rep[chKey(s)]>=3)return{w:-1,why:'Same position three times.'};const pc=s.b.filter(p=>p&&p.toUpperCase()!=='K');if(!pc.length||(pc.length===1&&'NBnb'.includes(pc[0])))return{w:-1,why:'Not enough pieces left to checkmate.'};return null},
  badge:s=>chCheck(s)?'CHECK!':'',
  bot(s,lvl){const ms=chOrder(s,chLegal(s));if(!ms.length)return null;
    if(lvl===0){if(Math.random()<.3)return pick(ms);let best=ms[0],bv=-1e9;for(const m of ms){const v=-chQ(chMake(s,m),-1e9,1e9,1)+rnd(-70,70);if(v>bv){bv=v;best=m}}return best}
    const d=lvl===1?2:3;let best=ms[0],a=-1e9;for(const m of ms){const n=chMake(s,m);const k=chKey(n);const rp=s.rep&&s.rep[k]>=2;const v=(rp?0:-chNeg(n,d-1,-1e9,-a,1))+rnd(0,lvl===1?14:3);if(v>a){a=v;best=m}}return best},
  view(s,x){const chk=chCheck(s)?s.b.indexOf(s.t===0?'K':'k'):-1;return bGrid('chess',8,8,x.flip,i=>{const p=s.b[i],dk=((i>>3)+(i&7))%2===1;let c=dk?'dk':'lt';
    if(x.last&&(x.last.f===i||x.last.t===i))c+=' lm';if(x.sel===i)c+=' sel';if(x.tg.has(i))c+=p?' cap':' dot';if(i===chk)c+=' chk';
    return bCell(i,c,p?`<span class="pz ${isW(p)?'pw':'pb'}">${CGL[p.toUpperCase()]}︎</span>`:'',sqn(i)+(p?' '+(isW(p)?'white ':'black ')+{K:'king',Q:'queen',R:'rook',B:'bishop',N:'knight',P:'pawn'}[p.toUpperCase()]:''))})}}));

/* CHECKERS — American rules: forced captures, multi-jumps, kings. 1 red man, 2 red king (moves first, up), 3 black man, 4 black king */
const ckOwn=(p,t)=>t===0?(p===1||p===2):(p===3||p===4);
const CKD4=[[-1,-1],[-1,1],[1,-1],[1,1]];
function ckMoves(s){const b=s.b,t=s.t,jumps=[],steps=[];
  for(let i=0;i<64;i++){const p=b[i];if(!ckOwn(p,t))continue;const king=p===2||p===4,dirs=king?CKD4:t===0?CKD4.slice(0,2):CKD4.slice(2);
    const dfs=(pos,path,caps)=>{let any=false;const r=pos>>3,c=pos&7;
      for(const[dr,dc]of dirs){const lr=r+2*dr,lc=c+2*dc;if(lr<0||lr>7||lc<0||lc>7)continue;const mid=(r+dr)*8+c+dc,land=lr*8+lc;
        if(b[mid]&&!ckOwn(b[mid],t)&&(!b[land]||land===i)&&!caps.includes(mid)){any=true;
          if(!king&&((t===0&&lr===0)||(t===1&&lr===7)))jumps.push({f:i,t:land,path:path.concat(land),cap:caps.concat(mid)});else dfs(land,path.concat(land),caps.concat(mid))}}
      if(!any&&caps.length)jumps.push({f:i,t:pos,path,cap:caps})};
    dfs(i,[i],[]);
    for(const[dr,dc]of dirs){const r=(i>>3)+dr,c=(i&7)+dc;if(r<0||r>7||c<0||c>7)continue;const to=r*8+c;if(!b[to])steps.push({f:i,t:to,path:[i,to],cap:[]})}}
  const out=jumps.length?jumps:steps;out.forEach(m=>m.k=m.path.join('.'));return out}
function ckPlay(s,m){const b=s.b.slice();let p=b[m.f];b[m.f]=0;m.cap.forEach(c=>b[c]=0);const r=m.t>>3;if(p===1&&r===0)p=2;if(p===3&&r===7)p=4;b[m.t]=p;
  return{b,t:1-s.t,np:(m.cap.length||p===1||p===3)?0:s.np+1}}
function ckEval(b){let s=0;for(let i=0;i<64;i++){const p=b[i];if(!p)continue;const r=i>>3,cen=(i&7)>1&&(i&7)<6?3:0;if(p===1)s+=100+(7-r)*5+cen+(r===7?6:0);else if(p===2)s+=175+cen;else if(p===3)s-=100+r*5+cen+(r===0?6:0);else s-=175+cen}return s}
function ckNeg(s,d,a,be){const ms=ckMoves(s);if(!ms.length)return -99999-d;if(s.np>=80)return 0;if(d<=0&&!(ms[0].cap.length&&d>-6))return(s.t===0?1:-1)*ckEval(s.b);
  ms.sort((x,y)=>y.cap.length-x.cap.length);for(const m of ms){const v=-ckNeg(ckPlay(s,m),d-1,-be,-a);if(v>=be)return be;if(v>a)a=v}return a}
add(boardGame({id:'checkers',name:'CHECKERS',c:'--a3',kind:'ft',flip:true,sides:['Red','Black'],desc:'Jump your rival\'s pieces. Captures are forced and you can chain jumps.',
  art(c){c.fillStyle='#f0dcc0';c.fillRect(0,0,128,96);c.fillStyle='#5a3a24';for(let r=0;r<6;r++)for(let k=0;k<8;k++)if((r+k)%2)c.fillRect(k*16,r*16,16,16);[[24,72,'#d22d3d'],[56,72,'#d22d3d'],[72,24,'#1c1a22'],[104,24,'#1c1a22'],[88,56,'#1c1a22']].forEach(([x,y,col])=>{c.fillStyle=col;c.beginPath();c.arc(x,y,6,0,7);c.fill()})},
  start(){const b=Array(64).fill(0);for(let i=0;i<64;i++){const r=i>>3,c=i&7;if((r+c)%2===1){if(r<3)b[i]=3;else if(r>4)b[i]=1}}return{b,t:0,np:0}},
  turn:s=>s.t,moves:s=>ckMoves(s),play:(s,m)=>ckPlay(s,m),
  end(s){if(!ckMoves(s).length)return{w:1-s.t,why:(s.t?'Black':'Red')+' has no moves left.'};if(s.np>=80)return{w:-1,why:'40 moves each with no captures.'};return null},
  badge(s){const ms=ckMoves(s);return ms.length&&ms[0].cap.length?'MUST JUMP':''},
  bot(s,lvl){const ms=ckMoves(s);if(ms.length===1)return ms[0];if(lvl===0&&Math.random()<.35)return pick(ms);const d=[2,5,7][lvl];let best=ms[0],a=-1e9;
    for(const m of ms){const v=-ckNeg(ckPlay(s,m),d-1,-1e9,-a)+rnd(0,lvl===0?60:lvl===1?8:1);if(v>a){a=v;best=m}}return best},
  view(s,x){return bGrid('ckb',8,8,x.flip,i=>{const p=s.b[i],dk=((i>>3)+(i&7))%2===1;let c=dk?'dk':'lt';if(x.last&&x.last.path.includes(i))c+=' lm';if(x.sel===i)c+=' sel';if(x.tg.has(i))c+=' dot';if(x.act&&x.from.has(i)&&x.sel==null)c+=' can';
    return bCell(i,c,p?`<span class="ckp ${p<3?'r':'k'}">${p===2||p===4?'♛︎':''}</span>`:'',sqn(i)+(p?(p<3?' red':' black')+(p%2?'':' king'):''))})}}));
