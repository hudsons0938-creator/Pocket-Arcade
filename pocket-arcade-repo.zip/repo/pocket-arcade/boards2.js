/* REVERSI — b: 0 empty, 1 black (moves first), 2 white */
const RVD=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
const RVW=[100,-20,10,5,5,10,-20,100,-20,-50,-2,-2,-2,-2,-50,-20,10,-2,-1,-1,-1,-1,-2,10,5,-2,-1,-1,-1,-1,-2,5,5,-2,-1,-1,-1,-1,-2,5,10,-2,-1,-1,-1,-1,-2,10,-20,-50,-2,-2,-2,-2,-50,-20,100,-20,10,5,5,10,-20,100];
function rvFlips(b,i,me){if(b[i])return null;const op=3-me,r=i>>3,c=i&7,fl=[];for(const[dr,dc]of RVD){let rr=r+dr,cc=c+dc;const run=[];while(rr>=0&&rr<8&&cc>=0&&cc<8&&b[rr*8+cc]===op){run.push(rr*8+cc);rr+=dr;cc+=dc}if(run.length&&rr>=0&&rr<8&&cc>=0&&cc<8&&b[rr*8+cc]===me)fl.push(...run)}return fl.length?fl:null}
function rvPlace(b,me){const o=[];for(let i=0;i<64;i++){const f=rvFlips(b,i,me);if(f)o.push({t:i,k:String(i),fl:f})}return o}
const rvCount=(b,v)=>b.reduce((a,x)=>a+(x===v),0);
add(boardGame({id:'reversi',name:'REVERSI',c:'--a2',kind:'pl',sides:['Black','White'],desc:'Trap your rival\'s discs between yours to flip them. Most discs wins.',
  art(c){c.fillStyle='#1f7a46';c.fillRect(0,0,128,96);c.strokeStyle='#0d4a29';for(let k=0;k<=8;k++){c.beginPath();c.moveTo(k*16,0);c.lineTo(k*16,96);c.stroke();c.beginPath();c.moveTo(0,k*16);c.lineTo(128,k*16);c.stroke()}[[56,40,'#111'],[72,40,'#f5f5f5'],[56,56,'#f5f5f5'],[72,56,'#111'],[88,56,'#111']].forEach(([x,y,col])=>{c.fillStyle=col;c.beginPath();c.arc(x,y,6,0,7);c.fill()})},
  start(){const b=Array(64).fill(0);b[27]=2;b[36]=2;b[28]=1;b[35]=1;return{b,t:0}},
  turn:s=>s.t,
  moves(s){const me=s.t+1,ms=rvPlace(s.b,me);if(ms.length)return ms;return rvPlace(s.b,3-me).length?[{t:-1,k:'pass'}]:[]},
  play(s,m){if(m.k==='pass')return{b:s.b,t:1-s.t};const b=s.b.slice();b[m.t]=s.t+1;(m.fl||rvFlips(s.b,m.t,s.t+1)||[]).forEach(i=>b[i]=s.t+1);return{b,t:1-s.t}},
  end(s){if(this.moves(s).length)return null;const a=rvCount(s.b,1),w=rvCount(s.b,2);return{w:a>w?0:w>a?1:-1,why:a+' to '+w+' discs.'}},
  badge(s){return '⚫ '+rvCount(s.b,1)+'  ⚪ '+rvCount(s.b,2)},
  bot(s,lvl){const ms=this.moves(s);if(ms.length<=1)return ms[0];if(lvl===0){return Math.random()<.5?pick(ms):ms.reduce((a,m)=>m.fl.length>a.fl.length?m:a)}
    const ev=st=>{const me=st.t+1;let v=0;for(let i=0;i<64;i++){if(st.b[i]===me)v+=RVW[i];else if(st.b[i])v-=RVW[i]}return v+(rvPlace(st.b,me).length-rvPlace(st.b,3-me).length)*3};
    return rootPick(this,s,lvl===1?2:4,ev,lvl===1?4:0,l=>l.slice().sort((a,b)=>RVW[b.t]-RVW[a.t]))},
  view(s,x){return bGrid('rv',8,8,false,i=>{const v=s.b[i];let c='';if(x.last&&x.last.t===i)c+=' lm';
    return bCell(i,c,v?`<span class="disc ${v===1?'b':'w'}"></span>`:x.hint.has(i)?'<span class="hintd"></span>':'',sqn(i)+(v?(v===1?' black':' white'):''))})}}));

/* FIVE IN A ROW — 15x15, five or more in a line wins */
const GMN=15;
function gmLine(b,i,dr,dc,me){let n=1,o=0;const r=Math.floor(i/GMN),c=i%GMN;for(const sg of[1,-1]){let rr=r+dr*sg,cc=c+dc*sg;while(rr>=0&&rr<GMN&&cc>=0&&cc<GMN&&b[rr*GMN+cc]===me){n++;rr+=dr*sg;cc+=dc*sg}if(rr>=0&&rr<GMN&&cc>=0&&cc<GMN&&!b[rr*GMN+cc])o++}return[n,o]}
const GMS=(n,o)=>n>=5?1e6:o===0?0:n===4?(o===2?1e5:1.2e4):n===3?(o===2?6e3:500):n===2?(o===2?300:40):(o===2?10:2);
const GMDIR=[[0,1],[1,0],[1,1],[1,-1]];
function gmScore(b,i,me){let s=0;for(const[dr,dc]of GMDIR){const[n,o]=gmLine(b,i,dr,dc,me);s+=GMS(n,o)}return s}
function gmCands(b){const out=[];let any=false;for(let i=0;i<GMN*GMN;i++){if(b[i]){any=true;continue}const r=i/GMN|0,c=i%GMN;let near=false;
  for(let dr=-2;dr<=2&&!near;dr++)for(let dc=-2;dc<=2;dc++){const rr=r+dr,cc=c+dc;if(rr>=0&&rr<GMN&&cc>=0&&cc<GMN&&b[rr*GMN+cc]){near=true;break}}if(near)out.push(i)}return any?out:[112]}
add(boardGame({id:'gomoku',name:'FIVE IN A ROW',c:'--a6',kind:'pl',sides:['Black','White'],desc:'Take turns placing stones. First to line up five in any direction wins.',
  art(c){c.fillStyle='#e2b86b';c.fillRect(0,0,128,96);c.strokeStyle='#8a6a3a';for(let k=0;k<9;k++){c.beginPath();c.moveTo(8+k*14,4);c.lineTo(8+k*14,92);c.stroke();c.beginPath();c.moveTo(4,6+k*11);c.lineTo(124,6+k*11);c.stroke()}[0,1,2,3,4].forEach(k=>{c.fillStyle='#111';c.beginPath();c.arc(22+k*14,72-k*11,5,0,7);c.fill()});c.fillStyle='#f5f5f5';c.beginPath();c.arc(64,72,5,0,7);c.fill();c.beginPath();c.arc(92,61,5,0,7);c.fill()},
  start(){return{b:Array(GMN*GMN).fill(0),t:0,w:0,n:0}},turn:s=>s.t,
  moves(s){if(s.w)return[];const o=[];for(let i=0;i<GMN*GMN;i++)if(!s.b[i])o.push({t:i,k:String(i)});return o},
  play(s,m){const b=s.b.slice(),me=s.t+1;b[m.t]=me;let w=0;for(const[dr,dc]of GMDIR)if(gmLine(b,m.t,dr,dc,me)[0]>=5)w=me;if(!w&&s.n+1>=GMN*GMN)w=3;return{b,t:1-s.t,w,n:s.n+1}},
  end(s){if(s.w===3)return{w:-1,why:'The board is full.'};if(s.w)return{w:s.w-1,why:'Five in a row!'};return null},
  bot(s,lvl){const me=s.t+1,op=3-me,cs=gmCands(s.b).map(i=>({i,a:gmScore(s.b,i,me),d:gmScore(s.b,i,op)}));cs.forEach(c=>c.v=c.a*1.12+c.d*(lvl===0?.55:1)+rnd(0,lvl===0?40:3));cs.sort((x,y)=>y.v-x.v);
    let pickI=cs[0].i;if(lvl===0&&cs[0].a<1e6&&cs[0].d<1e5)pickI=pick(cs.slice(0,5)).i;
    if(lvl===2&&cs[0].a<1e6&&cs[0].d<1e6){let bv=-Infinity;for(const c of cs.slice(0,8)){const b=s.b.slice();b[c.i]=me;let threat=0;for(const j of gmCands(b))threat=Math.max(threat,gmScore(b,j,op)*1.05+gmScore(b,j,me)*.5);const v=c.v-threat*.8;if(v>bv){bv=v;pickI=c.i}}}
    return{t:pickI,k:String(pickI)}},
  view(s,x){const lt=x.last&&x.last.t;return bGrid('gm',GMN,GMN,false,i=>{const v=s.b[i];const r=i/GMN|0,c=i%GMN;let cl=(r===0?' t':'')+(r===GMN-1?' bo':'')+(c===0?' l':'')+(c===GMN-1?' rt':'');
    return bCell(i,cl,v?`<span class="st ${v===1?'b':'w'}${i===lt?' lm':''}"></span>`:'','row '+(r+1)+' column '+(c+1)+(v?(v===1?' black':' white'):''))})}}));

/* MANCALA (Kalah) — pits 0-5 + store 6 for player 1; pits 7-12 + store 13 for player 2 */
function mcPlay(s,m){const p=s.p.slice(),t=s.t;let i=m.t,n=p[i];p[i]=0;const skip=t===0?13:6,store=t===0?6:13;while(n>0){i=(i+1)%14;if(i===skip)continue;p[i]++;n--}
  let nt=1-t;if(i===store)nt=t;else if(p[i]===1&&(t===0?i<6:(i>6&&i<13))&&p[12-i]>0){p[store]+=p[12-i]+1;p[i]=0;p[12-i]=0}
  let over=false;if(p.slice(0,6).every(v=>!v)||p.slice(7,13).every(v=>!v)){for(let k=0;k<6;k++){p[6]+=p[k];p[k]=0;p[13]+=p[k+7];p[k+7]=0}over=true}return{p,t:nt,over}}
add(boardGame({id:'mancala',name:'MANCALA',c:'--a5',kind:'pl',sides:['Blue','Pink'],desc:'Sow seeds around the board. Land in your store for another turn and capture across.',
  art(c){c.fillStyle='#7a4a20';c.fillRect(4,16,120,64);c.fillStyle='#4a2a10';c.beginPath();c.ellipse(14,48,7,24,0,0,7);c.fill();c.beginPath();c.ellipse(114,48,7,24,0,0,7);c.fill();for(let k=0;k<6;k++)for(const y of[34,62]){c.beginPath();c.arc(30+k*14,y,6,0,7);c.fill()}c.fillStyle='#c58bff';[[30,34],[44,62],[72,34],[100,62]].forEach(([x,y])=>{c.beginPath();c.arc(x,y,2.5,0,7);c.fill()})},
  start(){return{p:[4,4,4,4,4,4,0,4,4,4,4,4,4,0],t:0,over:false}},turn:s=>s.t,
  moves(s){if(s.over)return[];const o=[],a=s.t===0?0:7;for(let i=a;i<a+6;i++)if(s.p[i])o.push({t:i,k:String(i)});return o},
  play:(s,m)=>mcPlay(s,m),
  end(s){if(!s.over)return null;const a=s.p[6],b=s.p[13];return{w:a>b?0:b>a?1:-1,why:a+' seeds to '+b+'.'}},
  badge(s){return 'STORES '+s.p[6]+' · '+s.p[13]},
  bot(s,lvl){const ms=this.moves(s);if(ms.length===1)return ms[0];if(lvl===0&&Math.random()<.4)return pick(ms);
    const ev=st=>(st.t===0?1:-1)*((st.p[6]-st.p[13])*3+(st.p.slice(0,6).reduce((a,v)=>a+v,0)-st.p.slice(7,13).reduce((a,v)=>a+v,0))*.25);
    return rootPick(this,s,[2,6,9][lvl],ev,lvl===0?3:.5)},
  view(s,x){const bot=x.vs,top=1-bot,pits=q=>q===0?[0,1,2,3,4,5]:[7,8,9,10,11,12],st=q=>q===0?6:13;
    const pit=i=>{const n=s.p[i];let c='mp';if(x.hint.has(i))c+=' can';if(x.last&&x.last.t===i)c+=' lm';return bCell(i,c,`<b>${n}</b><span class="seeds">${'•'.repeat(Math.min(n,12))}</span>`,'pit with '+n+' seeds')};
    return `<div class="mancala"><div class="mst q${top}"><b>${s.p[st(top)]}</b><small>${esc(this.sides[top])}</small></div>
      <div class="mrow">${pits(top).slice().reverse().map(pit).join('')}</div><div class="mrow">${pits(bot).map(pit).join('')}</div>
      <div class="mst q${bot}"><b>${s.p[st(bot)]}</b><small>${esc(this.sides[bot])}</small></div></div>`}}));

/* CONNECT FOUR — 7 columns x 6 rows */
function c4Drop(b,c){for(let r=5;r>=0;r--)if(!b[r*7+c])return r*7+c;return -1}
function c4Win(b,i,me){const r=i/7|0,c=i%7;for(const[dr,dc]of[[0,1],[1,0],[1,1],[1,-1]]){let n=1;for(const sg of[1,-1]){let rr=r+dr*sg,cc=c+dc*sg;while(rr>=0&&rr<6&&cc>=0&&cc<7&&b[rr*7+cc]===me){n++;rr+=dr*sg;cc+=dc*sg}}if(n>=4)return true}return false}
function c4Eval(b,me){const op=3-me;let s=0;for(let r=0;r<6;r++)if(b[r*7+3]===me)s+=3;else if(b[r*7+3]===op)s-=3;
  for(let r=0;r<6;r++)for(let c=0;c<7;c++)for(const[dr,dc]of[[0,1],[1,0],[1,1],[1,-1]]){const er=r+3*dr,ec=c+3*dc;if(er<0||er>5||ec<0||ec>6)continue;let m=0,o=0;for(let k=0;k<4;k++){const v=b[(r+k*dr)*7+c+k*dc];if(v===me)m++;else if(v===op)o++}
    if(m&&!o)s+=m===3?6:m===2?2:0;else if(o&&!m)s-=o===3?7:o===2?2:0}return s}
add(boardGame({id:'connect4',name:'CONNECT FOUR',c:'--a4',kind:'pl',sides:['Blue','Pink'],desc:'Drop discs into the grid. Four in a row wins, across, down or diagonal.',
  art(c){c.fillStyle='#2c3fa0';c.fillRect(14,14,100,72);for(let r=0;r<4;r++)for(let k=0;k<6;k++){c.fillStyle=(r===3&&k<3)?'#5ab0ff':(r===2&&k===1)?'#ff5d8f':'#0c0a14';c.beginPath();c.arc(26+k*16,26+r*16,6,0,7);c.fill()}},
  start(){return{b:Array(42).fill(0),t:0,w:0,n:0}},turn:s=>s.t,
  moves(s){if(s.w)return[];const o=[];for(const c of[3,2,4,1,5,0,6])if(!s.b[c])o.push({t:c,k:String(c)});return o},
  pickCell(s,ms,i){return ms.find(m=>m.t===i%7)},
  play(s,m){const b=s.b.slice(),me=s.t+1,i=c4Drop(b,m.t);b[i]=me;let w=c4Win(b,i,me)?me:0;if(!w&&s.n+1>=42)w=3;return{b,t:1-s.t,w,n:s.n+1,lc:i}},
  end(s){if(s.w===3)return{w:-1,why:'The grid is full.'};if(s.w)return{w:s.w-1,why:'Four in a row!'};return null},
  bot(s,lvl){const ms=this.moves(s);if(lvl===0&&Math.random()<.3)return pick(ms);return rootPick(this,s,[2,5,7][lvl],st=>c4Eval(st.b,st.t+1),lvl===0?6:lvl===1?1:0)},
  view(s,x){return bGrid('c4',7,6,false,i=>{const v=s.b[i];let c='';if(x.act)c+=' can';return bCell(i,c,`<span class="hole ${v===1?'p1':v===2?'p2':''}${s.lc===i?' lm':''}"></span>`,'column '+(i%7+1))})}}));

/* ULTIMATE TIC-TAC-TOE — your square picks your rival's next board */
const L3=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const UTW=[3,2,3,2,4,2,3,2,3];
function utEval(s){const me=s.t+1,op=3-me;let v=0;for(let B=0;B<9;B++){if(s.w[B]===me)v+=UTW[B]*20;else if(s.w[B]===op)v-=UTW[B]*20;else if(!s.w[B]){for(const l of L3){let m=0,o=0;for(const c of l){const x=s.b[B*9+c];if(x===me)m++;else if(x===op)o++}if(m===2&&!o)v+=4;if(o===2&&!m)v-=4}}}
  for(const l of L3){let m=0,o=0;for(const k of l){if(s.w[k]===me)m++;else if(s.w[k]===op||s.w[k]===3)o+=(s.w[k]===op?1:9)}if(m===2&&!o)v+=60;if(o===2)v-=60}return v}
add(boardGame({id:'uttt',name:'ULTIMATE TIC-TAC-TOE',c:'--a3',kind:'pl',sides:['X','O'],desc:'Nine boards in one. The square you play sends your rival to that board.',
  art(c){c.fillStyle='#2f2948';c.fillRect(16,0,96,96);for(let B=0;B<9;B++){const x=19+(B%3)*31,y=3+(B/3|0)*31;c.fillStyle=B===4?'#3a3360':'#1e1a2e';c.fillRect(x,y,28,28)}c.font='bold 22px monospace';c.fillStyle='#5ab0ff';c.fillText('X',26,25);c.fillStyle='#ff5d8f';c.fillText('O',88,87);c.strokeStyle='#ffb627';c.lineWidth=2;c.strokeRect(50,34,28,28)},
  start(){return{b:Array(81).fill(0),w:Array(9).fill(0),nx:-1,t:0,W:0}},turn:s=>s.t,
  moves(s){if(s.W)return[];const o=[];for(let B=0;B<9;B++){if(s.w[B]||(s.nx>=0&&s.nx!==B))continue;for(let c=0;c<9;c++)if(!s.b[B*9+c])o.push({t:B*9+c,k:String(B*9+c)})}return o},
  play(s,m){const b=s.b.slice(),w=s.w.slice(),me=s.t+1,B=m.t/9|0;b[m.t]=me;if(L3.some(l=>l.every(c=>b[B*9+c]===me)))w[B]=me;else if([0,1,2,3,4,5,6,7,8].every(c=>b[B*9+c]))w[B]=3;
    const tg=m.t%9;let W=0;if(L3.some(l=>l.every(k=>w[k]===me)))W=me;else if(w.every(v=>v))W=3;return{b,w,nx:w[tg]?-1:tg,t:1-s.t,W}},
  end(s){if(s.W===3){const a=s.w.filter(v=>v===1).length,o=s.w.filter(v=>v===2).length;return a===o?{w:-1,why:'No three boards in a row. Boards tied '+a+'-'+o+'.'}:{w:a>o?0:1,why:'No line, so most boards wins: '+Math.max(a,o)+' to '+Math.min(a,o)+'.'}}
    if(s.W)return{w:s.W-1,why:'Three boards in a row!'};return null},
  badge(s){return s.nx>=0?'PLAY IN THE GLOWING BOARD':'PLAY ANYWHERE'},
  bot(s,lvl){const ms=this.moves(s);if(lvl===0&&Math.random()<.35)return pick(ms);let d=[1,3,5][lvl];if(ms.length>20)d=Math.max(1,d-2);else if(ms.length>9)d=Math.max(1,d-1);return rootPick(this,s,d,utEval,lvl===0?30:lvl===1?3:0)},
  view(s,x){let h='<div class="ut">';for(let B=0;B<9;B++){const act=x.act&&!s.W&&!s.w[B]&&(s.nx<0||s.nx===B);h+=`<div class="utb${act?' act':''}${s.w[B]?' won w'+s.w[B]:''}" data-w="${s.w[B]===1?'X':s.w[B]===2?'O':s.w[B]===3?'–':''}">`;
      for(let c=0;c<9;c++){const i=B*9+c,v=s.b[i];h+=bCell(i,(v?'xo'+v:'')+(x.last&&x.last.t===i?' lm':''),v===1?'X':v===2?'O':'','board '+(B+1)+' square '+(c+1)+(v?(v===1?' X':' O'):''))}h+='</div>'}return h+'</div>'}}));
