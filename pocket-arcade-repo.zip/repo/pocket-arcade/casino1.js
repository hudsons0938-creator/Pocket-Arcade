/* GAMBLING — play money only. One shared bankroll for every game in this section. */
let CASH=(()=>{try{const v=parseFloat(localStorage.getItem('pa_cash'));return Number.isFinite(v)&&v>=0?v:1000}catch(e){return 1000}})();
let CBET=(()=>{try{return +localStorage.getItem('pa_cbet')||10}catch(e){return 10}})();
const BETS=[1,2,5,10,25,50,100,250,500,1000,2500,5000,10000,25000,50000,100000];
const money=v=>'$'+(Number.isInteger(v)?v.toLocaleString():v.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}));
function cashSave(){try{localStorage.setItem('pa_cash',CASH);localStorage.setItem('pa_cbet',CBET)}catch(e){}}
function cashUI(){if(cur&&cur.cat==='casino')setScore(money(CASH));document.querySelectorAll('.cashv').forEach(e=>e.textContent=money(CASH))}
function cashAdd(d){CASH=Math.max(0,Math.round((CASH+d)*100)/100);cashSave();cashUI();if(d>0&&typeof lbPost==='function')lbPost('cash',CASH)}
function takeBet(b){if(ADM.freebets)return b>0;if(!(b>0)||b>CASH+1e-9)return false;cashAdd(-b);return true}
function betOK(){return ADM.freebets||CBET<=CASH}
function cTop(){return `<div class="ctop"><span>BANK <b class="cashv">${money(CASH)}</b></span>${CASH<1?'<button class="cb gold" data-a="refill">FREE $500 CHIPS</button>':''}</div>`}
function betH(label='BET'){return `<div class="betbar"><button class="cb sq" data-a="bet-" aria-label="Lower bet">−</button><span>${label} <b>${money(CBET)}</b></span><button class="cb sq" data-a="bet+" aria-label="Raise bet">+</button><button class="cb sq" data-a="betmax">ALL</button></div>`}
function casinoCommon(a){
  if(a==='refill'){if(CASH<1){cashAdd(500);beep(880,.15,'triangle')}return true}
  if(a==='bet+'){const n=BETS.find(b=>b>CBET);CBET=n&&n<=Math.max(1,CASH)?n:CBET;cashSave();return true}
  if(a==='bet-'){const n=[...BETS].reverse().find(b=>b<CBET);CBET=n||1;cashSave();return true}
  if(a==='betmax'){CBET=Math.max(1,Math.floor(CASH));cashSave();return true}
  return false}
function casinoGame(o){return Object.assign({cat:'casino',dom:true,c:'--a1',how:'Play money only. Your bank is shared by every game in the Gambling section.',
  init(){const d=$('dom');d.classList.add('cas');d.onclick=e=>{const b=e.target.closest('[data-a]');if(!b||b.disabled)return;const a=b.dataset.a;if(casinoCommon(a)){this.render();return}this.act(a,b)};
    this.setup&&this.setup();this.render();cashUI()},
  render(){if(cur!==this)return;$('dom').innerHTML='<div class="casino">'+cTop()+this.view()+'</div>';this.after&&this.after()},
  later(f,ms){setTimeout(()=>{if(cur===this&&!$('play').hidden)f()},ms)}},o)}
/* cards */
const SUITS=['♠','♥','♦','♣'],RANKS=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
function newDeck(n=1){const d=[];for(let k=0;k<n;k++)for(let s=0;s<4;s++)for(let r=0;r<13;r++)d.push({r,s});for(let i=d.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[d[i],d[j]]=[d[j],d[i]]}return d}
const cardH=(c,hid,extra='')=>hid?`<div class="pc back ${extra}"></div>`:`<div class="pc ${c.s===1||c.s===2?'red':''} ${extra}"><b>${RANKS[c.r]}</b><i>${SUITS[c.s]}</i></div>`;
const K5=(c,a)=>{let s=c;for(let i=0;i<5;i++)s=s*15+(a[i]||0);return s};
function eval5(cs){const r=cs.map(c=>c.r).sort((a,b)=>b-a),fl=cs.every(c=>c.s===cs[0].s),u=[...new Set(r)];let st=-1;
  if(u.length===5){if(u[0]-u[4]===4)st=u[0];else if(u[0]===12&&u[1]===3)st=3}
  const cnt={};r.forEach(x=>cnt[x]=(cnt[x]||0)+1);const gp=Object.entries(cnt).map(([k,v])=>[v,+k]).sort((a,b)=>b[0]-a[0]||b[1]-a[1]),gr=gp.map(x=>x[1]);
  if(st>=0&&fl)return K5(8,[st]);if(gp[0][0]===4)return K5(7,gr);if(gp[0][0]===3&&gp[1][0]===2)return K5(6,gr);if(fl)return K5(5,r);if(st>=0)return K5(4,[st]);
  if(gp[0][0]===3)return K5(3,gr);if(gp[0][0]===2&&gp[1][0]===2)return K5(2,gr);if(gp[0][0]===2)return K5(1,gr);return K5(0,r)}
const CAT=s=>Math.floor(s/759375);
const HNAME=['High Card','Pair','Two Pair','Three of a Kind','Straight','Flush','Full House','Four of a Kind','Straight Flush'];
const C7=[];for(let a=0;a<7;a++)for(let b=a+1;b<7;b++)C7.push([a,b]);
function handCat(cs){if(cs.length<5)return cs[0].r===cs[1].r?1:0;let best=0;const n=cs.length;for(let a=0;a<n;a++)for(let b=a;b<n;b++){if(n===5&&(a||b))continue;if(n===6&&a!==b)continue;if(n===7&&a===b)continue;const f=cs.filter((_,i)=>n===5?true:n===6?i!==a:(i!==a&&i!==b));const v=eval5(f);if(v>best)best=v}return CAT(best)}
function eval7(cs){let best=0;for(const[a,b]of C7){const f=cs.filter((_,i)=>i!==a&&i!==b);const v=eval5(f);if(v>best)best=v}return best}

/* Blackjack */
add(casinoGame({id:'bj',name:'BLACKJACK',c:'--a2',desc:'Beat the dealer to 21 without going bust. Blackjack pays 3 to 2.',art(c){c.fillStyle='#14532d';c.fillRect(0,0,128,96);[['A','♠',30,'#111'],['K','♥',62,'#d22']].forEach(([r,s,x,col])=>{c.fillStyle='#fff';c.fillRect(x,22,34,48);c.fillStyle=col;c.font='bold 14px sans-serif';c.fillText(r,x+5,40);c.fillText(s,x+16,62)})},
  setup(){this.ph='bet';this.p=[];this.d=[];this.msg='Place your bet and deal.';if(!this.shoe||this.shoe.length<60)this.shoe=newDeck(6)},
  val(h){let t=0,a=0;for(const c of h){t+=c.r===12?11:c.r>=8?10:c.r+2;if(c.r===12)a++}while(t>21&&a){t-=10;a--}return t},
  draw(){if(this.shoe.length<20)this.shoe=newDeck(6);return this.shoe.pop()},
  view(){const hide=this.ph==='play'&&!ADM.xray;const dv=hide?'?':this.val(this.d);
    return `<div class="felt"><div class="lbl">DEALER ${this.d.length?dv:''}</div><div class="hand">${this.d.map((c,i)=>cardH(c,hide&&i===1)).join('')}</div>
      <div class="lbl">YOU ${this.p.length?this.val(this.p):''}${this.bet&&this.ph!=='bet'?' · BET '+money(this.bet):''}</div><div class="hand">${this.p.map(c=>cardH(c)).join('')}</div></div>
      <div class="cmsg">${this.msg}</div>`+(this.ph==='play'?`<div class="crow"><button class="cb" data-a="hit">HIT</button><button class="cb" data-a="stand">STAND</button><button class="cb" data-a="dbl" ${this.p.length===2&&CASH>=this.bet?'':'disabled'}>DOUBLE</button></div>`
      :betH()+`<div class="crow"><button class="cb gold" data-a="deal" ${betOK()?'':'disabled'}>DEAL</button></div>`)},
  act(a){if(a==='deal'){if(!takeBet(CBET))return;this.bet=CBET;this.p=[this.draw(),this.draw()];this.d=[this.draw(),this.draw()];if(ADM.luck)this.p=[{r:12,s:0},{r:11,s:1}];this.ph='play';this.msg='Hit or stand?';beep(500,.05);
      const pb=this.val(this.p)===21,db=this.val(this.d)===21;if(pb||db){if(pb&&db)return this.end(1,'Both have blackjack. Push.');if(pb)return this.end(2.5,'BLACKJACK! You win '+money(this.bet*1.5)+'.');return this.end(0,'Dealer has blackjack.')}}
    else if(a==='hit'){this.p.push(this.draw());beep(450,.04);const v=this.val(this.p);if(v>21)return this.end(0,'Bust with '+v+'.');if(v===21)return this.stand()}
    else if(a==='stand')return this.stand();
    else if(a==='dbl'){if(!takeBet(this.bet))return;this.bet*=2;this.p.push(this.draw());const v=this.val(this.p);if(v>21)return this.end(0,'Bust with '+v+' on the double.');return this.stand()}
    this.render()},
  stand(){while(this.val(this.d)<17)this.d.push(this.draw());const p=this.val(this.p),d=this.val(this.d);
    if(d>21)return this.end(2,'Dealer busts with '+d+'. You win '+money(this.bet)+'!');if(p>d)return this.end(2,p+' beats '+d+'. You win '+money(this.bet)+'!');if(p===d)return this.end(1,'Push at '+p+'.');this.end(0,'Dealer wins, '+d+' to '+p+'.')},
  end(mult,m){this.ph='done';this.msg=m;if(mult)cashAdd(this.bet*mult);beep(mult>1?880:mult?500:180,.15,'triangle');this.render()}}));

/* Baccarat */
const bv=c=>c.r>=8&&c.r<=11?0:c.r===12?1:c.r+2;
add(casinoGame({id:'bacc',name:'BACCARAT',c:'--a5',desc:'Bet on Player, Banker or a Tie. Closest to 9 wins.',art(c){c.fillStyle='#3b0d2e';c.fillRect(0,0,128,96);c.fillStyle='#c58bff';c.font='bold 12px monospace';c.fillText('PLAYER',8,30);c.fillText('BANKER',70,30);c.fillStyle='#fff';c.fillRect(14,40,22,32);c.fillRect(80,40,22,32);c.fillStyle='#111';c.fillText('9',20,62);c.fillText('7',86,62)},
  setup(){this.P=[];this.B=[];this.msg='Pick a side. Player pays 1:1, Banker 0.95:1, Tie 8:1.';this.hist=this.hist||[]},
  tot(h){return h.reduce((s,c)=>s+bv(c),0)%10},
  view(){return `<div class="felt"><div class="bac"><div><div class="lbl">PLAYER ${this.P.length?this.tot(this.P):''}</div><div class="hand">${this.P.map(c=>cardH(c)).join('')}</div></div>
      <div><div class="lbl">BANKER ${this.B.length?this.tot(this.B):''}</div><div class="hand">${this.B.map(c=>cardH(c)).join('')}</div></div></div></div>
      <div class="cmsg">${this.msg}</div><div class="hist">${this.hist.map(h=>`<span class="hb ${h}">${h}</span>`).join('')}</div>`+betH()+
      `<div class="crow"><button class="cb blue" data-a="P" ${betOK()&&!this.busy?'':'disabled'}>PLAYER</button><button class="cb gold" data-a="T" ${betOK()&&!this.busy?'':'disabled'}>TIE</button><button class="cb red" data-a="B" ${betOK()&&!this.busy?'':'disabled'}>BANKER</button></div>`},
  act(a){if(this.busy||!takeBet(CBET))return;const bet=CBET,want=ADM.take('bacc')||(ADM.luck?a:null);let d,P,B,p3,tries=0;do{d=newDeck(1);P=[d.pop(),d.pop()];B=[d.pop(),d.pop()];p3=null;
    const pt=this.tot(P),bt=this.tot(B);
    if(pt<8&&bt<8){if(pt<=5){p3=d.pop();P.push(p3)}const b=this.tot(B);let draw;
      if(!p3)draw=b<=5;else{const v=bv(p3);draw=b<=2||(b===3&&v!==8)||(b===4&&v>=2&&v<=7)||(b===5&&v>=4&&v<=7)||(b===6&&(v===6||v===7))}if(draw)B.push(d.pop())}}while(want&&tries++<800&&(this.tot(P)>this.tot(B)?'P':this.tot(B)>this.tot(P)?'B':'T')!==want);
    this.P=[];this.B=[];this.busy=1;this.msg='Dealing…';const seq=[['P',P[0]],['B',B[0]],['P',P[1]],['B',B[1]]];if(P[2])seq.push(['P',P[2]]);if(B[2])seq.push(['B',B[2]]);
    seq.forEach(([w,c],i)=>this.later(()=>{this[w].push(c);beep(420,.04);this.render()},350*(i+1)));
    this.later(()=>{const p=this.tot(P),b=this.tot(B),res=p>b?'P':b>p?'B':'T';let win=0;
      if(res==='T')win=a==='T'?bet*9:bet;else if(res===a)win=a==='P'?bet*2:bet*1.95;if(win)cashAdd(win);
      this.hist.unshift(res);this.hist=this.hist.slice(0,14);this.busy=0;
      this.msg=(res==='T'?'Tie at '+p:(res==='P'?'Player':'Banker')+' wins '+Math.max(p,b)+' to '+Math.min(p,b))+'. '+(win>bet?'You win '+money(win-bet)+'!':win===bet?'Your bet is returned.':'You lose '+money(bet)+'.');
      beep(win>bet?880:200,.15,'triangle');this.render()},350*(seq.length+1));this.render()}}));

/* Video Poker (Jacks or Better) */
const VP=[['Royal Flush',250],['Straight Flush',50],['Four of a Kind',25],['Full House',9],['Flush',6],['Straight',4],['Three of a Kind',3],['Two Pair',2],['Jacks or Better',1]];
function vpRank(cs){const s=eval5(cs),c=CAT(s);if(c===8)return Math.floor(s/50625)%15===12?0:1;if(c===7)return 2;if(c===6)return 3;if(c===5)return 4;if(c===4)return 5;if(c===3)return 6;if(c===2)return 7;
  if(c===1){const pr=Math.floor(s/50625)%15;return pr>=9?8:-1}return -1}
add(casinoGame({id:'vpoker',name:'VIDEO POKER',c:'--a4',desc:'Jacks or Better. Hold your best cards and draw for a winning hand.',art(c){c.fillStyle='#0a1a3a';c.fillRect(0,0,128,96);for(let i=0;i<5;i++){c.fillStyle='#fff';c.fillRect(6+i*24,30,20,30);c.fillStyle=i%2?'#d22':'#111';c.font='bold 11px sans-serif';c.fillText(['A','K','Q','J','10'][i],9+i*24,48)}c.fillStyle='#ffb627';c.fillRect(6,68,116,8)},
  setup(){this.h=[];this.held=[0,0,0,0,0];this.ph='bet';this.msg='Deal five cards. Tap cards to hold them, then draw.'},
  view(){const r=this.h.length?vpRank(this.h):-1;
    return `<div class="paytab">${VP.map(([n,m],i)=>`<div class="${this.ph!=='bet'&&r===i?'hit':''}"><span>${n}</span><b>${m}x</b></div>`).join('')}</div>
      <div class="felt"><div class="hand vp">${this.h.map((c,i)=>`<button class="hold ${this.held[i]?'on':''}" data-a="h${i}" ${this.ph==='draw'?'':'disabled'}>${cardH(c)}<small>${this.held[i]?'HELD':'&nbsp;'}</small></button>`).join('')}</div></div>
      <div class="cmsg">${this.msg}</div>`+(this.ph==='draw'?`<div class="crow"><button class="cb gold" data-a="draw">DRAW</button></div>`:betH()+`<div class="crow"><button class="cb gold" data-a="deal" ${betOK()?'':'disabled'}>DEAL</button></div>`)},
  act(a){if(a==='deal'){if(!takeBet(CBET))return;this.bet=CBET;this.dk=newDeck(1);this.h=[0,1,2,3,4].map(()=>this.dk.pop());if(ADM.luck)this.h=[8,9,10,11,12].map(r=>({r,s:0})).sort(()=>Math.random()-.5);this.held=[0,0,0,0,0];this.ph='draw';const r=vpRank(this.h);this.msg=r>=0?'You have '+VP[r][0]+'. Hold and draw.':'Tap cards to hold, then draw.';beep(500,.05)}
    else if(a[0]==='h'){const i=+a[1];this.held[i]^=1;beep(600,.02)}
    else if(a==='draw'){this.h=this.h.map((c,i)=>this.held[i]?c:this.dk.pop());const r=vpRank(this.h);this.ph='bet';
      if(r>=0){const w=this.bet*VP[r][1];cashAdd(w);this.msg=VP[r][0]+'! You win '+money(w)+'.';beep(880,.2,'triangle')}else{this.msg='No win this time.';beep(200,.1)}}
    this.render()}}));

/* Hi-Lo */
add(casinoGame({id:'hilo',name:'HI-LO',c:'--a6',desc:'Guess if the next card is higher or lower. Build a streak, then cash out.',art(c){c.fillStyle='#2a1a0a';c.fillRect(0,0,128,96);c.fillStyle='#fff';c.fillRect(46,20,36,52);c.fillStyle='#111';c.font='bold 18px sans-serif';c.fillText('7',58,52);c.fillStyle='#3ddc97';c.fillText('▲',16,40);c.fillStyle='#ff5d8f';c.fillText('▼',96,70)},
  setup(){this.ph='bet';this.c=null;this.mult=1;this.trail=[];this.msg='Start a run. Aces are high. Ties keep your streak alive.'},
  pH(){return(12-this.c.r)/13},pL(){return this.c.r/13},
  view(){const run=this.ph==='run';const mh=run?this.mult*Math.min(50,.97/Math.max(this.pH(),1/13)):0,ml=run?this.mult*Math.min(50,.97/Math.max(this.pL(),1/13)):0;
    return `<div class="felt"><div class="hand">${this.trail.slice(-4).map(c=>cardH(c,0,'dim')).join('')}${this.c?cardH(this.c,0,'big'):cardH(null,1,'big')}</div>
      ${ADM.xray&&run?'<div class="lbl c">ADMIN PEEK · NEXT CARD '+RANKS[this.dk[this.dk.length-1].r]+'</div>':''}<div class="lbl">${run?'RUN '+this.mult.toFixed(2)+'x · CASH OUT '+money(Math.floor(this.bet*this.mult*100)/100):''}</div></div><div class="cmsg">${this.msg}</div>`+
      (run?`<div class="crow"><button class="cb blue" data-a="hi" ${this.c.r<12?'':'disabled'}>HIGHER ${mh.toFixed(2)}x</button><button class="cb red" data-a="lo" ${this.c.r>0?'':'disabled'}>LOWER ${ml.toFixed(2)}x</button></div><div class="crow"><button class="cb gold" data-a="cash" ${this.trail.length?'':'disabled'}>CASH OUT</button></div>`
      :betH()+`<div class="crow"><button class="cb gold" data-a="go" ${betOK()?'':'disabled'}>START RUN</button></div>`)},
  act(a){if(a==='go'){if(!takeBet(CBET))return;this.bet=CBET;this.dk=newDeck(2);this.c=this.dk.pop();this.trail=[];this.mult=1;this.ph='run';this.msg='Higher or lower?'}
    else if(a==='hi'||a==='lo'){const p=a==='hi'?this.pH():this.pL(),old=this.c;let n=this.dk.pop();if(ADM.luck){const ok=c=>a==='hi'?c.r>old.r:c.r<old.r;if(!ok(n)){const j=this.dk.findIndex(ok);if(j>=0){const t=this.dk[j];this.dk[j]=n;n=t}}}this.trail.push(old);this.c=n;
      if(n.r===old.r){this.msg='Same rank. Streak safe.';beep(500,.05)}
      else if((a==='hi')===(n.r>old.r)){this.mult*=Math.min(50,.97/Math.max(p,1/13));this.msg='Correct! '+this.mult.toFixed(2)+'x';beep(700+this.trail.length*40,.06)}
      else{this.ph='bet';this.msg='Wrong. You lose '+money(this.bet)+'.';beep(160,.2,'sawtooth')}}
    else if(a==='cash'){const w=Math.floor(this.bet*this.mult*100)/100;cashAdd(w);this.ph='bet';this.msg='Cashed out '+money(w)+'!';beep(880,.2,'triangle')}
    this.render()}}));

/* Texas Hold'em vs 3 bots */
function equity(hand,board,nOpp,sims=120){const known=new Set(hand.concat(board).map(c=>c.r*4+c.s));const base=[];for(let s=0;s<4;s++)for(let r=0;r<13;r++)if(!known.has(r*4+s))base.push({r,s});
  const need=5-board.length+nOpp*2;let w=0;
  for(let k=0;k<sims;k++){for(let i=0;i<need;i++){const j=i+(Math.random()*(base.length-i)|0);[base[i],base[j]]=[base[j],base[i]]}
    const b=board.concat(base.slice(0,5-board.length));const me=eval7(hand.concat(b));let best=0;
    for(let o=0;o<nOpp;o++){const oh=base.slice(5-board.length+o*2,5-board.length+o*2+2);const v=eval7(oh.concat(b));if(v>best)best=v}
    w+=me>best?1:me===best?.5:0}return w/sims}
add(casinoGame({id:'holdem',name:"TEXAS HOLD'EM",c:'--a3',desc:'Poker against three bots. Ante up, then check, raise or fold each street.',art(c){c.fillStyle='#14532d';c.beginPath();c.ellipse(64,48,60,38,0,0,7);c.fill();c.fillStyle='#fff';for(let i=0;i<5;i++)c.fillRect(24+i*17,38,14,20);c.fillStyle='#ffb627';c.beginPath();c.arc(64,76,6,0,7);c.fill()},
  setup(){this.ph='bet';this.me=[];this.board=[];this.bots=[{n:'ACE'},{n:'VIPER'},{n:'LUCKY'}];this.st=0;this.pot=0;this.msg='Your bet is the ante. A raise costs the same again.'},
  shown(){return this.board.slice(0,[0,3,4,5][this.st])},
  view(){const sd=this.reveal;
    return `<div class="felt"><div class="bots">${this.bots.map(b=>`<div class="bot ${b.live===false?'out':''} ${b.win?'win':''}"><b>${b.n}</b><div class="hand sm">${(b.h||[]).map(c=>cardH(c,!(ADM.xray||sd&&b.live!==false))).join('')}</div><small>${b.say||''}</small></div>`).join('')}</div>
      <div class="lbl">POT ${money(this.pot)}</div><div class="hand">${this.shown().map(c=>cardH(c)).join('')}${'<div class="pc slot"></div>'.repeat(5-this.shown().length)}</div>
      <div class="lbl">YOU ${this.me.length?'· '+HNAME[handCat(this.me.concat(this.shown()))]:''}</div><div class="hand">${this.me.map(c=>cardH(c)).join('')}</div></div>
      <div class="cmsg">${this.msg}</div>`+
      (this.ph==='act'?`<div class="crow"><button class="cb" data-a="check">CHECK</button><button class="cb gold" data-a="raise" ${CASH>=this.ante?'':'disabled'}>RAISE ${money(this.ante)}</button><button class="cb red" data-a="fold">FOLD</button></div>`
      :this.ph==='face'?`<div class="crow"><button class="cb gold" data-a="call" ${CASH>=this.ante?'':'disabled'}>CALL ${money(this.ante)}</button><button class="cb red" data-a="fold">FOLD</button></div>`
      :betH('ANTE')+`<div class="crow"><button class="cb gold" data-a="deal" ${betOK()?'':'disabled'}>DEAL HAND</button></div>`)},
  live(){return this.bots.filter(b=>b.live)},
  decide(b,toCall){const n=this.live().length,eq=equity(b.h,this.shown(),n,90);
    if(!toCall){if(eq>1.5/(n+1)&&Math.random()<.65||Math.random()<.05)return'raise';return'check'}
    const odds=toCall/(this.pot+toCall);return eq>odds*1.1||Math.random()<.08?'call':'fold'},
  act(a){const r=this.ante;
    if(a==='deal'){if(!takeBet(CBET))return;this.ante=CBET;let d=newDeck(1);if(ADM.luck){const RF=[12,11,10,9,8].map(r=>({r,s:0}));d=d.filter(c=>!(c.s===0&&c.r>=8));this.me=RF.slice(0,2);this.board=RF.slice(2).concat([d.pop(),d.pop()]).sort(()=>Math.random()-.5)}else{this.me=[d.pop(),d.pop()];this.board=[0,1,2,3,4].map(()=>d.pop())}
      this.reveal=0;this.bots.forEach(b=>{b.h=[d.pop(),d.pop()];b.live=true;b.say='';b.win=0});this.pot=this.ante*4;this.st=0;this.ph='act';this.msg='Pre-flop. Your move.';beep(500,.05)}
    else if(a==='fold'){this.ph='bet';this.bots.forEach(b=>b.say=b.live?'wins':b.say);this.msg='You folded.';beep(200,.1)}
    else if(a==='raise'){if(!takeBet(r))return;this.pot+=r;for(const b of this.live()){const d=this.decide(b,r);if(d==='fold'){b.live=false;b.say='folds'}else{this.pot+=r;b.say='calls'}}return this.next()}
    else if(a==='check'){let raiser=null;for(const b of this.live()){if(raiser)break;const d=this.decide(b,0);if(d==='raise'){raiser=b;b.say='raises';this.pot+=r}else b.say='checks'}
      if(raiser){for(const b of this.live())if(b!==raiser){const d=this.decide(b,r);if(d==='fold'){b.live=false;b.say='folds'}else{this.pot+=r;b.say='calls'}}this.ph='face';this.msg=raiser.n+' raises '+money(r)+'. Call or fold?';beep(330,.06);return this.render()}
      return this.next()}
    else if(a==='call'){if(!takeBet(r))return;this.pot+=r;return this.next()}
    this.render()},
  next(){if(!this.live().length){cashAdd(this.pot);this.ph='bet';this.msg='Everyone folded. You win '+money(this.pot)+'!';beep(880,.2,'triangle');return this.render()}
    if(this.st<3){this.st++;this.ph='act';this.msg=['','Flop','Turn','River'][this.st]+'. Your move.';beep(450,.04);return this.render()}
    const all=[{n:'YOU',v:eval7(this.me.concat(this.board)),me:1}].concat(this.live().map(b=>({n:b.n,v:eval7(b.h.concat(this.board)),b})));const top=Math.max(...all.map(x=>x.v)),wins=all.filter(x=>x.v===top);
    wins.forEach(w=>w.b&&(w.b.win=1));const share=Math.round(this.pot/wins.length*100)/100;const iw=wins.some(w=>w.me);if(iw)cashAdd(share);
    this.ph='bet';this.reveal=1;this.msg=(iw?(wins.length>1?'Split pot! You win '+money(share):'You win '+money(this.pot)+'!'):wins.map(w=>w.n).join(' & ')+' win'+(wins.length>1?'':'s'))+' with '+HNAME[CAT(top)]+'.';beep(iw?880:200,.2,'triangle');
    this.render()}}));
