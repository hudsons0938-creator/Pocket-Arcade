/* GAMBLING — wheels, slots and instant games (play money) */
function drawWheel(cv,segs,rot){if(!cv)return;const x=cv.getContext('2d'),S=cv.width,c=S/2,R=c-8,a=Math.PI*2/segs.length;x.clearRect(0,0,S,S);
  x.fillStyle='#3a2a10';x.beginPath();x.arc(c,c,R+6,0,7);x.fill();
  segs.forEach((s,i)=>{x.beginPath();x.moveTo(c,c);x.arc(c,c,R,rot+i*a,rot+(i+1)*a);x.closePath();x.fillStyle=s.c;x.fill();x.strokeStyle='#0006';x.lineWidth=1;x.stroke();
    x.save();x.translate(c,c);x.rotate(rot+(i+.5)*a);x.fillStyle=s.t||'#fff';x.font=`bold ${s.fs||12}px Rubik,sans-serif`;x.textAlign='right';x.fillText(s.l,R-6,4);x.restore()});
  x.fillStyle='#1e1a2e';x.beginPath();x.arc(c,c,R*.28,0,7);x.fill();x.fillStyle='#ffb627';x.beginPath();x.moveTo(c-9,2);x.lineTo(c+9,2);x.lineTo(c,20);x.fill()}
function spinWheel(gm,segs,idx,ms,done){const a=Math.PI*2/segs.length,from=gm.rot||0;let to=-Math.PI/2-(idx+.5)*a+(Math.random()-.5)*a*.6;
  while(to>from-Math.PI*8)to-=Math.PI*2;const t0=performance.now();gm.spinning=1;
  const step=t=>{if(cur!==gm||$('play').hidden){gm.spinning=0;return}const k=Math.min(1,(t-t0)/ms),e=1-Math.pow(1-k,4);gm.rot=from+(to-from)*e;drawWheel($('wcv'),segs,gm.rot);
    if(k<1)requestAnimationFrame(step);else{gm.rot=to%(Math.PI*2);gm.spinning=0;done()}};requestAnimationFrame(step)}

/* Roulette (European, single zero) */
const RW=[0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
const REDS=new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
const rcol=n=>n===0?'#1f8a4c':REDS.has(n)?'#c8283c':'#1a1a22';
const RSEG=RW.map(n=>({c:rcol(n),l:String(n),fs:9}));
function rPay(k,n){if(k[0]==='n')return +k.slice(1)===n?36:0;if(n===0)return 0;
  return {red:REDS.has(n),black:!REDS.has(n),odd:n%2===1,even:n%2===0,low:n<=18,high:n>=19}[k]?2:{d1:n<=12,d2:n>12&&n<=24,d3:n>24,c1:n%3===1,c2:n%3===2,c3:n%3===0}[k]?3:0}
add(casinoGame({id:'roul',name:'ROULETTE',c:'--a3',desc:'Place chips on numbers, colors or groups, then spin the wheel.',art(c){c.fillStyle='#14532d';c.fillRect(0,0,128,96);for(let i=0;i<18;i++){c.fillStyle=i%2?'#c8283c':'#1a1a22';c.beginPath();c.moveTo(64,48);c.arc(64,48,40,i/18*6.283,(i+1)/18*6.283);c.fill()}c.fillStyle='#ffb627';c.beginPath();c.arc(64,48,10,0,7);c.fill()},
  setup(){this.bets=this.bets||{};this.hist=this.hist||[];this.msg=this.msg||'Tap the table to place chips at your chip value.';this.rot=this.rot||0},
  chip(k){const v=this.bets[k];return v?`<em>${v>=1000?Math.round(v/100)/10+'k':v}</em>`:''},
  view(){const tot=Object.values(this.bets).reduce((a,b)=>a+b,0);let grid='';
    for(let r=0;r<12;r++)for(let c=1;c<=3;c++){const n=r*3+c;grid+=`<button class="rn" style="background:${rcol(n)}" data-a="n${n}">${n}${this.chip('n'+n)}</button>`}
    const ob=(k,l,bg='')=>`<button class="ro" ${bg?`style="background:${bg}"`:''} data-a="${k}">${l}${this.chip(k)}</button>`;
    return `<div class="wheelbox"><canvas id="wcv" width="230" height="230"></canvas><div class="hist">${this.hist.map(n=>`<span class="hb" style="background:${rcol(n)}">${n}</span>`).join('')}</div></div>
      <div class="cmsg">${this.msg}</div>`+betH('CHIP')+
      `<div class="rtab"><button class="rn zero" style="background:${rcol(0)}" data-a="n0">0${this.chip('n0')}</button><div class="rgrid">${grid}</div>
      <div class="rgrid">${ob('c1','2:1')}${ob('c2','2:1')}${ob('c3','2:1')}</div>
      <div class="rgrid">${ob('d1','1-12')}${ob('d2','13-24')}${ob('d3','25-36')}</div>
      <div class="rgrid six">${ob('low','1-18')}${ob('even','EVEN')}${ob('red','RED','#c8283c')}${ob('black','BLACK','#1a1a22')}${ob('odd','ODD')}${ob('high','19-36')}</div></div>
      <div class="crow"><button class="cb red" data-a="clear" ${tot&&!this.spinning?'':'disabled'}>CLEAR</button><button class="cb" data-a="rebet" ${!tot&&this.last&&!this.spinning?'':'disabled'}>REBET</button><button class="cb gold" data-a="spin" ${tot&&!this.spinning?'':'disabled'}>SPIN ${tot?money(tot):''}</button></div>`},
  after(){drawWheel($('wcv'),RSEG,this.rot)},
  act(a){if(this.spinning)return;
    if(a==='clear'){cashAdd(Object.values(this.bets).reduce((s,v)=>s+v,0));this.bets={};this.msg='Chips returned.'}
    else if(a==='rebet'){const t=Object.values(this.last).reduce((s,v)=>s+v,0);if(t>CASH){this.msg='Not enough in the bank to repeat that.';return this.render()}cashAdd(-t);this.bets={...this.last};this.msg='Same bets placed.'}
    else if(a==='spin'){const fn=ADM.take('roul'),n=fn!=null?fn:ADM.luck?bestRoul(this.bets):RW[Math.random()*37|0];this.last={...this.bets};this.msg='No more bets…';this.render();beep(300,.1);
      spinWheel(this,RSEG,RW.indexOf(n),3800,()=>{let win=0;for(const k in this.bets)win+=this.bets[k]*rPay(k,n);const tot=Object.values(this.bets).reduce((s,v)=>s+v,0);if(win)cashAdd(win);
        this.hist.unshift(n);this.hist=this.hist.slice(0,12);this.bets={};this.msg=`${n} ${n===0?'GREEN':REDS.has(n)?'RED':'BLACK'}. `+(win?`You win ${money(win)}${win>tot?' (+'+money(win-tot)+')':''}!`:'No win.');beep(win?880:200,.2,'triangle');this.render()});return}
    else{if(!takeBet(CBET)){this.msg='Not enough in the bank for that chip.';return this.render()}this.bets[a]=(this.bets[a]||0)+CBET;beep(600,.02)}
    this.render()}}));

/* Prize Wheel */
const PW=[0,1.5,0,.5,0,2,0,3,0,.5,0,1.5,0,7,0,2,.5,0,0,0].map(m=>({m,c:m===0?'#2f2948':m>=7?'#ffb627':m>=2?'#ff5d8f':m>=1.5?'#5ab0ff':'#3ddc97',l:m?m+'x':'✕',t:m>=7?'#111':'#fff',fs:13}));
add(casinoGame({id:'pwheel',name:'PRIZE WHEEL',c:'--a1',desc:'Spin the big wheel. Land on a multiplier, or hit the 7x jackpot.',art(c){const cols=['#2f2948','#ff5d8f','#5ab0ff','#ffb627','#3ddc97'];for(let i=0;i<10;i++){c.fillStyle=cols[i%5];c.beginPath();c.moveTo(64,52);c.arc(64,52,40,i/10*6.283,(i+1)/10*6.283);c.fill()}c.fillStyle='#ffb627';c.beginPath();c.moveTo(56,6);c.lineTo(72,6);c.lineTo(64,18);c.fill()},
  setup(){this.msg='Your bet is multiplied by wherever the pointer lands.';this.rot=this.rot||0},
  view(){return `<div class="wheelbox"><canvas id="wcv" width="260" height="260"></canvas></div><div class="cmsg">${this.msg}</div>`+betH()+`<div class="crow"><button class="cb gold" data-a="spin" ${betOK()&&!this.spinning?'':'disabled'}>SPIN</button></div>`},
  after(){drawWheel($('wcv'),PW,this.rot)},
  act(a){if(this.spinning||!takeBet(CBET))return;const bet=CBET,fi=ADM.take('pwheel')??(ADM.luck?13:null),i=fi!=null?fi:Math.random()*PW.length|0;this.msg='Spinning…';this.render();
    spinWheel(this,PW,i,4200,()=>{const m=PW[i].m,w=Math.round(bet*m*100)/100;if(w)cashAdd(w);this.msg=m?`${m}x! You get ${money(w)}.`:'Nothing this time.';beep(m>1?880:200,.2,'triangle');this.render()})}}));

/* Slot machines */
const SLOTS=[{id:'s_fruit',name:'FRUIT FIESTA',c:'--a2',reels:3,bg:'#0f3d2a',desc:'Classic three-reel fruit machine. Two cherries pay too.',sy:[['🍒',6,[2,19]],['🍋',7,[0,19]],['🍊',7,[0,19]],['🍇',5,[0,37]],['🔔',3,[0,74]],['⭐',2,[0,148]],['7️⃣',1,[0,556]]]},{id:'s_sevens',name:'LUCKY SEVENS',c:'--a3',reels:3,bg:'#3d0f1a',desc:'Bars, bells and sevens on a retro three-reeler.',sy:[['BAR',8,[0,11]],['BB',5,[0,22]],['BBB',3,[0,44]],['🔔',5,[0,17]],['7️⃣',2,[0,111]],['💎',1,[0,556]]]},{id:'s_ocean',name:'OCEAN TREASURE',c:'--a4',reels:3,bg:'#0a2a4a',desc:'Dive for shells, sharks and a sunken chest of gold.',sy:[['🐚',8,[1,8]],['🐠',7,[0,10]],['🐙',5,[0,21]],['🦈',3,[0,52]],['💰',1,[0,413]]]},{id:'s_space',name:'SPACE GEMS',c:'--a5',reels:5,bg:'#1a0f3d',desc:'Five reels of planets and rockets. Line up 3, 4 or 5 from the left.',sy:[['🪐',6,[0,0,5,14,47]],['🚀',5,[0,0,8,24,76]],['👽',4,[0,0,9,38,142]],['🌟',3,[0,0,19,76,284]],['💎',1,[0,0,47,237,947]]]},{id:'s_dragon',name:'DRAGON GOLD',c:'--a1',reels:5,bg:'#3d1a0a',desc:'Lanterns, coins and a dragon worth up to 1,891x your bet.',sy:[['🎋',6,[0,0,5,14,47]],['🏮',5,[0,0,8,24,76]],['🧧',4,[0,0,9,38,142]],['🪙',3,[0,0,19,76,284]],['🐉',1,[0,0,57,284,1891]]]},{id:'s_candy',name:'CANDY RUSH',c:'--a6',reels:5,bg:'#3d0f33',desc:'A sugary five-reeler with sweet multipliers.',sy:[['🍬',6,[0,0,5,14,47]],['🍭',5,[0,0,8,24,76]],['🧁',4,[0,0,9,38,142]],['🍩',3,[0,0,19,76,284]],['🍫',1,[0,0,47,237,947]]]}];
function slotPay(m,line){const s=line[0];let k=1;while(k<line.length&&line[k]===s)k++;if(m.reels===3&&k<3){if(k===2){const e=m.sy.find(q=>q[0]===s);return e[2][0]||0}return 0}
  const e=m.sy.find(q=>q[0]===s);return m.reels===3?e[2][1]:(k>=3?e[2][k-1]:0)}
function slotRoll(m){const tot=m.sy.reduce((a,q)=>a+q[1],0);let r=Math.random()*tot;for(const q of m.sy){r-=q[1];if(r<0)return q[0]}return m.sy[0][0]}
SLOTS.forEach(m=>add(casinoGame({id:m.id,name:m.name,c:m.c,desc:m.desc,
  art(c){c.fillStyle=m.bg;c.fillRect(0,0,128,96);c.fillStyle='#f1eefa';const n=m.reels,w=n===3?30:20;for(let i=0;i<n;i++)c.fillRect(64-(n*(w+3))/2+i*(w+3),30,w,36);c.font=(n===3?20:14)+'px sans-serif';c.textAlign='center';
    for(let i=0;i<n;i++)c.fillText(m.sy[(i*2+1)%m.sy.length][0].length>2?'7':m.sy[(i*2+1)%m.sy.length][0],64-(n*(w+3))/2+i*(w+3)+w/2,55);c.textAlign='start';c.fillStyle='#ffb627';c.fillRect(8,74,112,6)},
  setup(){if(!this.grid)this.grid=Array.from({length:m.reels},()=>[slotRoll(m),slotRoll(m),slotRoll(m)]);this.msg=this.msg||'Match symbols on the middle line, starting from the left reel.'},
  sym(s){return s.length>2&&!/\p{Emoji_Presentation}/u.test(s)?`<span class="bar">${s}</span>`:s},
  view(){return `<div class="slot" style="--sb:${m.bg}"><div class="reels r${m.reels}">${this.grid.map((col,i)=>`<div class="reel" id="reel${i}">${col.map((s,j)=>`<div class="${j===1?'mid':''}">${this.sym(s)}</div>`).join('')}</div>`).join('')}</div><div class="payline"></div></div>
      <div class="cmsg">${this.msg}</div><details class="pays"><summary>PAYTABLE</summary>${m.sy.slice().reverse().map(q=>`<div><span>${this.sym(q[0]).repeat(1)}</span><b>${m.reels===3?(q[2][0]?'×2 = '+q[2][0]+'x · ':'')+'×3 = '+q[2][1]+'x':'×3 '+q[2][2]+'x · ×4 '+q[2][3]+'x · ×5 '+q[2][4]+'x'}</b></div>`).join('')}</details>`+betH()+
      `<div class="crow"><button class="cb gold" data-a="spin" ${betOK()&&!this.busy?'':'disabled'}>SPIN</button></div>`},
  act(a){if(this.busy||!takeBet(CBET))return;const bet=CBET;this.busy=1;const res=Array.from({length:m.reels},()=>[slotRoll(m),slotRoll(m),slotRoll(m)]);if(ADM.take('slots')||ADM.luck){const top=m.sy[m.sy.length-1][0];res.forEach(c=>c[1]=top)}this.msg='Good luck!';this.render();
    const els=[...document.querySelectorAll('.reel')],stopped=[];const iv=setInterval(()=>{if(cur!==this){clearInterval(iv);return}els.forEach((e,i)=>{if(!stopped[i])e.innerHTML=[0,1,2].map(j=>`<div class="${j===1?'mid':''} blur">${this.sym(slotRoll(m))}</div>`).join('')})},70);
    res.forEach((col,i)=>this.later(()=>{stopped[i]=1;this.grid[i]=col;const e=$('reel'+i);if(e)e.innerHTML=col.map((s,j)=>`<div class="${j===1?'mid':''}">${this.sym(s)}</div>`).join('');beep(300+i*60,.05)},650+i*330));
    this.later(()=>{clearInterval(iv);this.busy=0;const mult=slotPay(m,res.map(c=>c[1])),w=bet*mult;if(w){cashAdd(w);this.msg=(mult>=50?'🎉 BIG WIN! ':'')+mult+'x · You win '+money(w)+'!';beep(mult>=50?1200:880,.3,'triangle')}else this.msg='No match. Spin again!';this.render()},650+m.reels*330+80)}})));

/* Street Craps (play money). Kept the id 'dice' so the admin "next total" tool still works. */
const DF=['⚀','⚁','⚂','⚃','⚄','⚅'];
const CR_ODDS={4:2,10:2,5:1.5,9:1.5,6:1.2,8:1.2};
const CR_P=[{n:'YOU',av:'🙂'},{n:'DEE',av:'🧢'},{n:'MARCO',av:'🕶️'},{n:'TASHA',av:'🎧'}];
add(casinoGame({id:'dice',name:'STREET CRAPS',c:'--a2',desc:'Roll the bones with the crew. Bet with or against the shooter.',art(c){c.fillStyle='#3a3f47';c.fillRect(0,0,128,96);c.fillStyle='#2e3238';for(let i=0;i<6;i++)c.fillRect(0,i*16,128,1);
    c.fillStyle='#fff';c.fillRect(30,34,30,30);c.fillRect(70,40,30,30);c.fillStyle='#111';[[38,42],[52,56],[45,49],[78,48],[92,62],[78,62],[92,48]].forEach(([x,y])=>{c.beginPath();c.arc(x,y,3,0,7);c.fill()});c.fillStyle='#ffb627';c.font='bold 9px monospace';c.fillText('7 11',46,88)},
  setup(){this.d=this.d||[2,4];this.point=this.point||null;this.sh=this.sh??1;this.side=this.side||null;this.bet=this.bet||0;this.odds=this.odds||0;this.log=this.log||[];this.say=this.say||{};
    this.msg=this.msg||'Pick a side to bet on the next come-out roll. 7 or 11 wins for the shooter. 2, 3 or 12 is craps.'},
  view(){const me=this.sh===0,inRound=!!this.bet,coming=this.point===null,dis=this.busy?'disabled':'';
    const seats=CR_P.map((p,i)=>`<div class="bot ${i===this.sh?'win':''}"><span style="font-size:22px">${p.av}</span><b>${p.n}${i===this.sh?' 🎲':''}</b><small>${this.say[i]||''}</small></div>`).join('');
    const pts=[4,5,6,8,9,10].map(n=>`<span class="hb ${this.point===n?'hi':''}" style="font-size:9px;padding:6px 7px">${n}${this.point===n?' ON':''}</span>`).join('');
    let btns='';
    if(!inRound&&coming){btns=me?`<button class="cb gold big" data-a="with" ${betOK()&&!this.busy?'':'disabled'}>🎲 BET & SHOOT</button>`
        :`<button class="cb blue" data-a="with" ${betOK()&&!this.busy?'':'disabled'}>WITH ${CR_P[this.sh].n} · 1:1</button><button class="cb red" data-a="against" ${betOK()&&!this.busy?'':'disabled'}>AGAINST · 1:1</button><button class="cb" data-a="watch" ${dis}>JUST WATCH</button>`}
    else{btns=`<button class="cb gold big" data-a="roll" ${dis}>🎲 ${me?'ROLL':'NEXT ROLL'}</button>`+(inRound&&!coming?`<button class="cb" data-a="odds" ${!this.busy&&betOK()&&this.odds+CBET<=this.bet*3?'':'disabled'}>+ ODDS ${money(CBET)} · pays ${CR_ODDS[this.point]===1.2?'6:5':CR_ODDS[this.point]===1.5?'3:2':'2:1'}</button>`:'')}
    return `<div class="felt" style="background:radial-gradient(ellipse at 50% 30%,#4a5058,#2a2e34)"><div class="bots" style="grid-template-columns:repeat(4,1fr)">${seats}</div>
      <div class="hist">${pts}</div><div class="dice">${this.d.map(v=>`<span>${DF[v]}</span>`).join('')}</div><div class="lbl">${this.point?'POINT IS '+this.point+' · HIT IT BEFORE A 7':'COME-OUT ROLL'} · TOTAL ${this.d[0]+this.d[1]+2}</div></div>
      <div class="cmsg">${this.msg}${inRound?`<br><small>Your bet: ${money(this.bet)} ${this.side==='with'?'with':'against'} the shooter${this.odds?' + '+money(this.odds)+' odds':''}</small>`:''}</div>`+
      (inRound&&coming?'':betH())+`<div class="crow">${btns}</div><div class="hist">${this.log.map(l=>`<span class="hb">${l}</span>`).join('')}</div>
      <details class="pays"><summary>HOW STREET CRAPS WORKS</summary><div>One player is the shooter. Bet WITH them (they make it) or AGAINST them (they crap out or seven out). Even money.</div>
      <div>Come-out roll: 7 or 11 wins for the shooter. 2, 3 or 12 is craps, a loss. Anything else becomes the point.</div><div>After that the shooter keeps rolling. The point again wins, a 7 loses. When the shooter sevens out, the dice pass to the next player.</div>
      <div>Once a point is set you can add odds on your side, up to 3× your bet, paid at true odds.</div></details>`},
  pickRoll(){const ft=ADM.take('dice');if(ft!=null){const a=Math.max(1,Math.min(6,ft-1)),b=ft-a;return[a-1,b-1]}
    if(ADM.luck&&this.bet){const shooterWin=this.side==='with',want=this.point===null?(shooterWin?7:2):(shooterWin?this.point:7);const a=Math.max(1,Math.min(6,want-1));return[a-1,want-a-1]}
    return[ri(0,5),ri(0,5)]},
  act(a){if(this.busy)return;const me=this.sh===0;
    if(a==='with'||a==='against'){if(this.bet||this.point!==null)return;if(!takeBet(CBET))return;this.bet=CBET;this.side=me?'with':a;this.odds=0;return this.roll()}
    if(a==='watch'){if(this.bet)return;return this.roll()}
    if(a==='odds'){if(!this.bet||this.point===null||this.odds+CBET>this.bet*3||!takeBet(CBET))return;this.odds+=CBET;this.msg='Odds added. Roll on!';beep(600,.05);return this.render()}
    if(a==='roll')return this.roll()},
  roll(){this.busy=1;const fin=this.pickRoll();if(this.point===null){this.say={};for(let i=1;i<4;i++)if(i!==this.sh&&Math.random()<.6)this.say[i]=Math.random()<.5?'With you!':'Fading you'}
    if(this.sh!==0)this.say[this.sh]=pick(['Come on seven!','Baby needs shoes!','Let it ride!','Here we go!','Daddy needs a 6!']);
    for(let i=0;i<9;i++)this.later(()=>{this.d=[ri(0,5),ri(0,5)];beep(180+i*30,.02);this.render()},i*70);
    this.later(()=>{this.d=fin;const t=fin[0]+fin[1]+2,name=CR_P[this.sh].n;let out=null;
      if(this.point===null){if(t===7||t===11){out='win';this.msg=`${t} on the come-out. ${name} wins with a natural!`}else if(t===2||t===3||t===12){out='lose';this.msg=`${t}. Craps! ${name} loses.`}
        else{this.point=t;this.msg=`${t}. The point is ${t}.`}}
      else{if(t===this.point){out='win';this.msg=`${t}! ${name} made the point!`}else if(t===7){out='seven';this.msg=`7. ${name} sevens out.`}else this.msg=`${t}. Roll again, still looking for ${this.point}.`}
      this.log.unshift(String(t));this.log=this.log.slice(0,12);
      if(out){const shooterWon=out==='win',mine=this.side==='with'?shooterWon:!shooterWon;
        if(this.bet){if(mine){const pay=this.bet*2+(this.odds?this.odds+this.odds*CR_ODDS[this.point]:0);cashAdd(pay);this.msg+=` You win ${money(pay-this.bet-this.odds)}!`;beep(880,.2,'triangle')}
          else{this.msg+=` You lose ${money(this.bet+this.odds)}.`;beep(200,.12)}}
        this.say[this.sh]=shooterWon?'YES! 🔥':'Aw man…';this.bet=0;this.odds=0;this.point=null;this.side=null;
        if(out==='seven'||(out==='lose'&&Math.random()<.35)){this.sh=(this.sh+1)%4;this.msg+=this.sh===0?' The dice are yours. Your turn to shoot!':` Dice pass to ${CR_P[this.sh].n}.`}}
      this.busy=0;this.render()},700)}}));

/* Plinko */
const PLM=[16,5,2,1.4,1.1,.8,.5,.8,1.1,1.4,2,5,16];
add(casinoGame({id:'plinko',name:'PLINKO',c:'--a5',desc:'Drop balls through the pegs. The edges pay up to 16x.',art(c){c.fillStyle='#1a1030';c.fillRect(0,0,128,96);c.fillStyle='#9a93b5';for(let r=0;r<6;r++)for(let j=0;j<=r+2;j++)c.fillRect(64+(j-(r+2)/2)*12-1,10+r*11,3,3);c.fillStyle='#ff5d8f';c.beginPath();c.arc(70,30,4,0,7);c.fill();['#ffb627','#c58bff','#5ab0ff','#3ddc97','#5ab0ff','#c58bff','#ffb627'].forEach((col,i)=>{c.fillStyle=col;c.fillRect(22+i*12,80,10,8)})},
  setup(){this.balls=[];this.msg='Each ball costs your bet. Drop as many as you like.'},
  view(){return `<div class="felt"><canvas id="pcv" width="300" height="330"></canvas></div><div class="cmsg" id="pmsg">${this.msg}</div>`+betH()+`<div class="crow"><button class="cb gold" data-a="drop" ${betOK()?'':'disabled'}>DROP BALL</button></div>`},
  after(){this.drawP()},
  drawP(){const cv=$('pcv');if(!cv)return;const x=cv.getContext('2d'),sp=22,cx=150;x.clearRect(0,0,300,330);
    for(let r=0;r<12;r++)for(let j=0;j<=r+2;j++){x.fillStyle='#c8c3dc';x.beginPath();x.arc(cx+(j-(r+2)/2)*sp,20+r*22,3,0,7);x.fill()}
    PLM.forEach((m,i)=>{x.fillStyle=m>=5?'#ff5d8f':m>=1.4?'#ffb627':m>=1?'#3ddc97':'#5ab0ff';x.fillRect(cx+(i-6)*sp-10,292,20,26);x.fillStyle='#111';x.font='bold 8px sans-serif';x.textAlign='center';x.fillText(m+'x',cx+(i-6)*sp,309)});
    for(const b of this.balls){x.fillStyle='#ff5d8f';x.beginPath();x.arc(b.x,b.y,6,0,7);x.fill()}},
  act(a){if(!takeBet(CBET))return;const bet=CBET,path=ADM.take('plinko')||ADM.luck?Array(12).fill(Math.random()<.5?0:1):Array.from({length:12},()=>Math.random()<.5?1:0);this.balls.push({path,bet,i:0,f:0,k:0,x:150,y:0});beep(500,.03);
    if(!this.loop){this.loop=1;const step=()=>{if(cur!==this||$('play').hidden){this.loop=0;this.balls=[];return}
      for(const b of this.balls){b.f++;const F=7;if(b.i<12){const k0=b.k,k1=b.k+b.path[b.i],t=b.f/F;const x0=150+(k0-b.i/2)*22,x1=150+(k1-(b.i+1)/2)*22;b.x=x0+(x1-x0)*t;b.y=9+b.i*22+22*t-Math.sin(t*Math.PI)*8;
        if(b.f>=F){b.k=k1;b.i++;b.f=0;beep(900+Math.random()*300,.01,'sine',.02)}}else{b.y+=4;if(b.y>300){b.done=1;const m=PLM[b.k],w=Math.round(b.bet*m*100)/100;cashAdd(w);const e=$('pmsg');this.msg=`${m}x · ${money(w)}`;if(e)e.textContent=this.msg;beep(m>=2?880:400,.1,'triangle')}}}
      this.balls=this.balls.filter(b=>!b.done);this.drawP();if(this.balls.length)requestAnimationFrame(step);else{this.loop=0;this.render()}};requestAnimationFrame(step)}}}));

/* Rocket Crash */
add(casinoGame({id:'crash',name:'ROCKET CRASH',c:'--a3',desc:'The multiplier climbs until the rocket blows. Cash out before it does.',art(c){c.fillStyle='#0a0a1a';c.fillRect(0,0,128,96);c.strokeStyle='#3ddc97';c.lineWidth=3;c.beginPath();c.moveTo(8,88);c.quadraticCurveTo(80,84,110,20);c.stroke();c.font='18px sans-serif';c.fillText('🚀',100,24);c.fillStyle='#fff';c.font='bold 12px monospace';c.fillText('2.47x',14,24)},
  setup(){this.ph='bet';this.m=1;this.msg='Launch, then tap CASH OUT before the crash.';this.hist=this.hist||[]},
  view(){const fly=this.ph==='fly';return `<div class="felt"><canvas id="ccv" width="300" height="190"></canvas><div class="crashm" id="cm">${this.m.toFixed(2)}x</div><div class="hist">${this.hist.map(v=>`<span class="hb ${v<2?'lo':'hi'}">${v.toFixed(2)}x</span>`).join('')}</div></div>
    <div class="cmsg">${this.msg}</div>`+(fly?`<div class="crow"><button class="cb gold big" data-a="cash" id="cbtn">CASH OUT ${money(Math.floor(this.bet*this.m*100)/100)}</button></div>`:betH()+`<div class="crow"><button class="cb gold" data-a="go" ${betOK()?'':'disabled'}>LAUNCH</button></div>`)},
  after(){this.drawC()},
  drawC(){const cv=$('ccv');if(!cv)return;const x=cv.getContext('2d');x.clearRect(0,0,300,190);x.strokeStyle='#2f2948';for(let i=1;i<4;i++){x.beginPath();x.moveTo(0,i*47);x.lineTo(300,i*47);x.stroke()}
    if(this.ph==='bet'&&!this.cp)return;const T=Math.max(4000,this.t||0),pts=[];for(let s=0;s<=60;s++){const tt=(this.t||0)*s/60,m=Math.exp(.00012*tt);pts.push([10+tt/T*270,180-Math.min(170,(m-1)/Math.max(1,Math.exp(.00012*T)-1)*170)])}
    x.strokeStyle=this.ph==='boom'?'#ff5d8f':'#3ddc97';x.lineWidth=3;x.beginPath();pts.forEach((p,i)=>i?x.lineTo(...p):x.moveTo(...p));x.stroke();const e=pts[pts.length-1];x.font='22px sans-serif';x.textAlign='center';x.fillText(this.ph==='boom'?'💥':'🚀',e[0],e[1])},
  act(a){if(a==='go'){if(!takeBet(CBET))return;this.bet=CBET;const u=Math.random();this.cp=Math.max(1,Math.floor(97/(1-u))/100);const fc=ADM.take('crash')??(ADM.luck?100:null);if(fc!=null)this.cp=fc;this.ph='fly';this.m=1;this.t=0;this.msg='Climbing…';this.render();beep(300,.1);
      const t0=performance.now();const step=now=>{if(cur!==this||$('play').hidden)return;if(this.ph!=='fly'&&this.ph!=='out')return;this.t=now-t0;this.m=Math.exp(.00012*this.t);
        if(this.m>=this.cp){this.m=this.cp;const was=this.ph;this.ph='boom';this.hist.unshift(this.cp);this.hist=this.hist.slice(0,10);if(was==='fly'){this.msg=`Crashed at ${this.cp.toFixed(2)}x. You lose ${money(this.bet)}.`;beep(120,.3,'sawtooth')}this.render();this.ph='bet';return}
        const cm=$('cm');if(cm)cm.textContent=this.m.toFixed(2)+'x';const cb=$('cbtn');if(cb)cb.textContent='CASH OUT '+money(Math.floor(this.bet*this.m*100)/100);this.drawC();requestAnimationFrame(step)};requestAnimationFrame(step)}
    else if(a==='cash'&&this.ph==='fly'){const w=Math.floor(this.bet*this.m*100)/100;cashAdd(w);this.ph='out';this.msg=`Cashed out at ${this.m.toFixed(2)}x for ${money(w)}! Watching where it would have crashed…`;beep(880,.2,'triangle');
      const cb=$('cbtn');if(cb){cb.disabled=true;cb.textContent='CASHED OUT ✓'}const e=document.querySelector('.casino .cmsg');if(e)e.textContent=this.msg}}}));

/* Scratch Cards */
const SCR=[['💰',50,.005],['💎',10,.02],['⭐',5,.04],['🍀',2,.1],['🎁',1,.12]];
add(casinoGame({id:'scratch',name:'SCRATCH CARDS',c:'--a2',desc:'Buy a card and scratch nine spots. Three matching symbols win.',art(c){c.fillStyle='#ffb627';c.fillRect(14,10,100,76);c.fillStyle='#9a93b5';for(let i=0;i<9;i++)c.fillRect(22+(i%3)*30,18+(i/3|0)*22,26,18);c.font='14px sans-serif';c.fillText('💎',24,32);c.fillText('💎',54,54)},
  setup(){this.ph='bet';this.msg='Card price is your bet. Prizes: 💰 50x · 💎 10x · ⭐ 5x · 🍀 2x · 🎁 1x'},
  view(){return `<div class="scard ${this.ph==='bet'&&!this.t?'blank':''}">${(this.t||Array(9).fill('?')).map((s,i)=>`<button class="sc ${this.o&&this.o[i]?'open':''} ${this.win&&this.o&&this.o[i]&&s===this.win?'won':''}" data-a="s${i}" ${this.ph==='play'&&!this.o[i]?'':'disabled'}>${this.o&&this.o[i]?s:''}</button>`).join('')}</div>
    <div class="cmsg">${this.msg}</div>`+(this.ph==='play'?`<div class="crow"><button class="cb" data-a="all">SCRATCH ALL</button></div>`:betH('CARD')+`<div class="crow"><button class="cb gold" data-a="buy" ${betOK()?'':'disabled'}>BUY CARD</button></div>`)},
  act(a){if(a==='buy'){if(!takeBet(CBET))return;this.bet=CBET;let r=ADM.take('scratch')||ADM.luck?0:Math.random(),win=null;for(const s of SCR){r-=s[2];if(r<0){win=s;break}}
      const pool=[];const syms=SCR.map(s=>s[0]).filter(s=>!win||s!==win[0]);syms.forEach(s=>pool.push(s,s));for(let i=pool.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[pool[i],pool[j]]=[pool[j],pool[i]]}
      const t=(win?[win[0],win[0],win[0]]:[]).concat(pool.slice(0,win?6:9));for(let i=8;i>0;i--){const j=Math.random()*(i+1)|0;[t[i],t[j]]=[t[j],t[i]]}
      this.t=t;this.o=Array(9).fill(0);this.win=win?win[0]:null;this.prize=win?win[1]:0;this.ph='play';this.msg='Tap to scratch!';beep(500,.05)}
    else if(a==='all'||a[0]==='s'){if(a==='all')this.o.fill(1);else{this.o[+a.slice(1)]=1;beep(700,.02)}
      if(this.o.every(v=>v)){this.ph='bet';if(this.win){const w=this.bet*this.prize;cashAdd(w);this.msg=`Three ${this.win}! You win ${money(w)}!`;beep(880,.25,'triangle')}else{this.msg='No three of a kind. Try another card!';beep(200,.1)}}}
    this.render()}}));

/* Gem Mines */
function mineMult(k,m){let x=.97;for(let j=0;j<k;j++)x*=(25-j)/(25-m-j);return x}
add(casinoGame({id:'gmines',name:'GEM MINES',c:'--a6',desc:'Flip tiles for gems. Each gem raises your payout. Hit a mine and lose it all.',art(c){c.fillStyle='#1a1430';c.fillRect(0,0,128,96);for(let i=0;i<15;i++){c.fillStyle=i===7?'#ff5d8f':[2,4,11].includes(i)?'#3ddc97':'#2f2948';c.fillRect(16+(i%5)*20,14+(i/5|0)*24,17,20)}},
  setup(){this.ph='bet';this.nm=this.nm||3;this.msg='Pick how many mines, then start. More mines means bigger multipliers.'},
  view(){const p=this.ph==='play',k=p?this.o.filter((v,i)=>v&&!this.mn[i]).length:0;
    return `<div class="mgrid">${Array.from({length:25},(_,i)=>{const o=this.o&&this.o[i];const s=o?(this.mn[i]?'💣':'💎'):(ADM.xray&&p&&this.mn[i]?'<span style="opacity:.4">💣</span>':'');return `<button class="mt ${o?(this.mn[i]?'boom':'gem'):''}" data-a="t${i}" ${p&&!o?'':'disabled'}>${s}</button>`}).join('')}</div>
      <div class="cmsg">${this.msg}</div>`+(p?`<div class="lbl c">NEXT GEM ${mineMult(k+1,this.nm).toFixed(2)}x</div><div class="crow"><button class="cb gold" data-a="cash" ${k?'':'disabled'}>CASH OUT ${money(Math.floor(this.bet*mineMult(k,this.nm)*100)/100)}</button></div>`
      :`<div class="crow">${[1,3,5,10].map(n=>`<button class="cb sq ${this.nm===n?'gold':''}" data-a="m${n}">${n} 💣</button>`).join('')}</div>`+betH()+`<div class="crow"><button class="cb gold" data-a="go" ${betOK()?'':'disabled'}>START</button></div>`)},
  act(a){if(a[0]==='m'){this.nm=+a.slice(1)}
    else if(a==='go'){if(!takeBet(CBET))return;this.bet=CBET;this.mn=Array(25).fill(0);let k=0;while(k<this.nm){const i=ri(0,24);if(!this.mn[i]){this.mn[i]=1;k++}}this.o=Array(25).fill(0);this.ph='play';this.msg='Find the gems!'}
    else if(a[0]==='t'){const i=+a.slice(1);if(ADM.luck&&this.mn[i]){this.mn[i]=0;const e=this.mn.map((v,j)=>!v&&!this.o[j]&&j!==i?j:-1).filter(j=>j>=0);if(e.length)this.mn[pick(e)]=1}this.o[i]=1;if(this.mn[i]){this.ph='bet';this.o=this.o.map((v,j)=>v||this.mn[j]);this.msg='💥 Mine! You lose '+money(this.bet)+'.';beep(110,.3,'sawtooth')}else beep(700+this.o.filter(v=>v).length*30,.05)}
    else if(a==='cash'){const k=this.o.filter((v,i)=>v&&!this.mn[i]).length,w=Math.floor(this.bet*mineMult(k,this.nm)*100)/100;cashAdd(w);this.ph='bet';this.o=this.o.map((v,j)=>v||this.mn[j]);this.msg='Cashed out '+money(w)+'!';beep(880,.2,'triangle')}
    this.render()}}));
