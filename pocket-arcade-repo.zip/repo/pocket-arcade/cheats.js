/* Cheat pack: always-on toggles (ADMT, run every frame) and one-tap tools (ADMX) for every game */
const ADMT={};
const T_=(id,list)=>{ADMT[id]=(ADMT[id]||[]).concat(list)};
const X_=(id,list)=>{ADMX[id]=(ADMX[id]||[]).concat(list)};
ADM.tg=new Set();
ADM.tick=g=>{const L=ADMT[g.id];if(!L)return;for(const[k,,f]of L)if(ADM.tg.has(g.id+':'+k)){try{f(g)}catch(e){}}};
const near=(a,b,k)=>a+(b-a)*k;
const angD=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));

/* ---------- original games ---------- */
const snakeStep=g=>g.t+1>=Math.max(4,9-Math.floor(score/5));
T_('snake',[['wrap','Walls wrap around',g=>{if(!snakeStep(g))return;const h=g.body[0],nx=h[0]+g.nd[0],ny=h[1]+g.nd[1];if(nx<0)h[0]=18;if(nx>=18)h[0]=-1;if(ny<0)h[1]=27;if(ny>=27)h[1]=-1}],
  ['auto','Autopilot',g=>{if(!snakeStep(g))return;const h=g.body[0];let best=null,bd=1e9;for(const d of[[0,-1],[0,1],[-1,0],[1,0]]){if(d[0]===-g.d[0]&&d[1]===-g.d[1])continue;const x=h[0]+d[0],y=h[1]+d[1];
    if(x<0||y<0||x>=18||y>=27||g.body.some(b=>b[0]===x&&b[1]===y))continue;const dd=Math.abs(x-g.f[0])+Math.abs(y-g.f[1]);if(dd<bd){bd=dd;best=d}}if(best)g.nd=best}],
  ['turbo','Turbo speed',g=>{g.t+=2}]]);
X_('snake',[['Shrink to 3',g=>{g.body.length=Math.min(g.body.length,3)}],['Food next to my head',g=>{const h=g.body[0];g.f=[clamp(h[0]+g.d[0],0,17),clamp(h[1]+g.d[1],0,26)]}]]);
T_('brick',[['auto','Autopilot paddle',g=>{g.px=clamp(g.bx,36,W-36)}],['slow','Slow ball',g=>{const s=hyp(g.vx,g.vy);if(s>3.2){g.vx*=3.2/s;g.vy*=3.2/s}}]]);
X_('brick',[['Skip level',g=>{g.b.forEach(b=>b.dead=1)}],['+5 lives',g=>{g.lives+=5}]]);
T_('hop',[['auto','Autopilot',g=>{const p=g.p.find(p=>p.x+52>70);const tgt=p?p.gy+80:H/2;if(g.y>tgt&&g.v>-1)g.flap()}]]);
X_('hop',[['Clear towers',g=>{g.p=[]}]]);
X_('pair',[['Match one pair for me',g=>{if(!g.deck||g.lock)return;g.open.forEach(c=>{c.up=0;c.el.classList.remove('up');c.el.textContent=''});g.open=[];const a=g.deck.findIndex(c=>!c.done);if(a<0)return;const b=g.deck.findIndex((c,i)=>i!==a&&!c.done&&c.i===g.deck[a].i);g.deck[a].up=0;g.deck[b].up=0;g.flip(a,g.deck[a].el);g.flip(b,g.deck[b].el)}],
  ['Solve the whole board',g=>{if(!g.deck)return;for(let k=0;k<20;k++){g.lock=false;const a=g.deck.findIndex(c=>!c.done);if(a<0)break;const b=g.deck.findIndex((c,i)=>i!==a&&!c.done&&c.i===g.deck[a].i);g.open=[];g.deck[a].up=0;g.deck[b].up=0;g.flip(a,g.deck[a].el);g.flip(b,g.deck[b].el)}}]]);
X_('ttt',[['Win this round',g=>{if(g.done)return;const l=g.L.find(l=>l.every(i=>g.b[i]!=='O'));if(!l)return;l.forEach(i=>{if(!g.b[i])g.set(i,'X')});g.end()}],['Erase CPU moves',g=>{if(g.done)return;g.b.forEach((v,i)=>{if(v==='O'){g.b[i]='';const c=$('cell'+i);c.textContent='';c.classList.remove('o')}})}]]);
T_('dash',[['auto','Autopilot',g=>{const p=g.p.position;const lane=g.lane;const danger=l=>g.obs.find(o=>o.position.z>-16&&o.position.z<1.5&&Math.abs(o.position.x-l*3)<1.5);const d=danger(lane);
    if(d){const free=[-1,0,1].filter(l=>!danger(l)).sort((a,b)=>Math.abs(a-lane)-Math.abs(b-lane));if(free.length&&Math.abs(free[0]-lane)===1)g.lane=free[0];else if(!d.userData.tall&&d.position.z>-6)g.jump();else if(free.length)g.lane+=Math.sign(free[0]-lane)}}],
  ['mag','Coin magnet',g=>{const p=g.p.position;g.coins.forEach(c=>{if(c.position.z>-25){c.position.x=near(c.position.x,p.x,.15);c.position.y=near(c.position.y,p.y,.15)}})}]]);
X_('dash',[['Clear the track',g=>{g.obs.forEach(o=>g.s.remove(o));g.obs=[]}]]);
T_('rush',[['immune','Hazard immunity',g=>{g.stun=0}]]);

/* ---------- 2D solo ---------- */
T_('puff',[['auto','Autopilot',g=>{const p=g.p.find(p=>p.x+56>68);const tgt=p?p.gp+14:H/2;if(g.y>tgt&&g.vy>-1)g.flap()}],['float','Low gravity',g=>{g.vy-=.2}]]);
X_('puff',[['Clear pipes',g=>{g.p=[]}]]);
T_('swarm',[['rapid','Rapid fire',g=>{if(g.t%3===0)g.b.push({x:g.x-12,y:g.y-10},{x:g.x+12,y:g.y-10},{x:g.x,y:g.y-16})}],['shield','Shield',g=>{g.inv=Math.max(g.inv,3)}]]);
X_('swarm',[['+5 lives',g=>{g.lives+=5}]]);
T_('stacker',[['auto','Auto-perfect drops',g=>{const t=g.s[g.s.length-1];if(Math.abs(g.m.x-t.x)<=g.sp+.5){g.m.x=t.x;g.drop()}}],['slow','Slow slab',g=>{g.sp=Math.min(g.sp,1.6)}]]);
X_('stacker',[['Full-width slab',g=>{const t=g.s[g.s.length-1];t.x=0;t.w=W;g.m.w=W;g.m.x=0}]]);
X_('merge',[['Clear all 2s and 4s',g=>{g.b=g.b.map(v=>v<=4?0:v)}],['Double every tile',g=>{g.b=g.b.map(v=>v*2)}],['Shuffle the board',g=>{g.b.sort(()=>Math.random()-.5)}]]);
T_('bop',[['auto','Auto-bop',g=>{for(const h of g.h)if(h.u&&!h.hit&&!h.bad)g.down({x:h.x,y:h.y})}],['nored','No red bots',g=>{g.h.forEach(h=>h.bad=0)}]]);
X_('bop',[['+30 seconds',g=>{g.time+=30*60}]]);
T_('slice',[['auto','Auto-slice fruit',g=>{for(const o of g.o)if(!o.cut&&!o.bomb&&o.y<H-20&&o.vy>-3){o.cut=1;setScore(score+1);for(let k=0;k<5;k++)g.pc.push({x:o.x,y:o.y,vx:rnd(-3,3),vy:rnd(-5,1),r:rnd(3,7),c:o.c,l:40})}}],['nobomb','No bombs',g=>{g.o=g.o.filter(o=>!o.bomb)}]]);
X_('slice',[['+5 lives',g=>{g.lives+=5}]]);
T_('cliff',[['jumps','Infinite jumps',g=>{g.j=0}],['net','Safety net',g=>{if(g.y>H-40){g.y=180;g.vy=-6}}]]);
T_('drop',[['bars','Only long bars',g=>{g.next='I'}],['nograv','Stop gravity',g=>{g.t=1}]]);
X_('drop',[['Clear the whole board',g=>{g.b=Array.from({length:18},()=>Array(10).fill(0))}]]);
X_('mines',[['Flag every mine',g=>{if(g.placed)g.c.forEach(k=>{if(k.m&&!k.o)k.f=1})}],['Reveal a safe square',g=>{if(!g.placed)g.place(40);const i=g.c.findIndex(k=>!k.m&&!k.o);if(i>=0)g.open(i)}],
  ['Clear the field now',g=>{if(!g.placed)g.place(40);g.c.forEach(k=>{if(!k.m)k.o=1});g.done=1;setScore(Math.max(50,1000-(g.t/60|0)*5));over('FIELD CLEAR!')}]]);
T_('echo',[['hint','Show the answer',g=>{if(g.ph==='input'){g.lit=g.seq[g.ii];g.lt=2}}]]);
X_('echo',[['Skip this round',g=>{setScore(g.seq.length);g.seq.push(ri(0,3));g.ph='show';g.si=0;g.tm=40}]]);
T_('dodge',[['mag','Coin magnet',g=>{g.o.forEach(o=>{if(o.gold)o.x=near(o.x,g.x,.12)})}],['slow','Slow rain',g=>{g.o.forEach(o=>o.vy=Math.min(o.vy,2))}]]);
X_('dodge',[['Clear the sky',g=>{g.o=g.o.filter(o=>o.gold)}]]);
T_('putt',[['mag','Hole magnet',g=>{if(g.vx||g.vy){const L=HOLES[g.hole];g.vx+=(L.h[0]-g.bx)*.004;g.vy+=(L.h[1]-g.by)*.004}}]]);
X_('putt',[['Skip hole (counts as ace)',g=>{g.st=1;g.sink=2}]]);
T_('bounce',[['jet','Jetpack',g=>{g.vy=Math.min(g.vy,-4.5)}],['nofall','Never fall',g=>{if(g.y>H-90)g.vy=-15}]]);
T_('rocks',[['rapid','Rapid fire',g=>{if(g.t%3===0)g.b.push({x:W/2+Math.cos(g.a)*20,y:H/2+Math.sin(g.a)*20,vx:Math.cos(g.a)*9,vy:Math.sin(g.a)*9,l:60})}],
  ['aim','Auto-aim',g=>{let best=null,bd=1e9;for(const r of g.r){const d=hyp(r.x-W/2,r.y-H/2);if(d<bd){bd=d;best=r}}if(best)g.ta=Math.atan2(best.y-H/2,best.x-W/2)}]]);

/* ---------- 2D versus ---------- */
T_('pong',[['ab','Blue autopilot',g=>{g.p[0]=g.bx}],['ap','Pink autopilot',g=>{g.p[1]=g.bx}],['slow','Slow ball',g=>{const s=hyp(g.vx,g.vy);if(s>4.5){g.vx*=4.5/s;g.vy*=4.5/s}}]]);
T_('hockey',[['ab','Blue goalie bot',g=>{const m=g.m[0],pk=g.pk;const t=pk.y>H/2-30?{x:pk.x,y:pk.y+18}:{x:W/2+(pk.x-W/2)*.5,y:H-60};m.x+=clamp(t.x-m.x,-9,9);m.y+=clamp(t.y-m.y,-9,9)}]]);
X_('hockey',[['Goal for Blue',g=>g.goal(0)],['Goal for Pink',g=>g.goal(1)]]);
T_('tanks',[['rapid','Blue rapid fire',g=>{const tk=g.tk[0];if(g.t%12===6&&!g.pause)g.b.push({x:tk.x+Math.cos(tk.a)*20,y:tk.y+Math.sin(tk.a)*20,vx:Math.cos(tk.a)*6,vy:Math.sin(tk.a)*6,n:0,o:0,l:200})}],
  ['shield','Blue shield',g=>{const tk=g.tk[0];g.b.forEach(b=>{if(b.o===1&&hyp(b.x-tk.x,b.y-tk.y)<40)b.l=0})}]]);
X_('four',[['Best move for whoever is up',g=>{for(const p of[g.turn,3-g.turn])for(let c=0;c<7;c++){const r=g.row(g.b,c);if(r<0)continue;g.b[r][c]=p;const w=g.won(g.b,p);g.b[r][c]=0;if(w)return g.play(c)}
    const ok=[3,2,4,1,5,0,6].filter(c=>g.row(g.b,c)>=0);if(ok.length)g.play(ok[0])}],['Undo last disc',g=>{if(!g.last)return;g.b[g.last[0]][g.last[1]]=0;g.last=null;g.turn=3-g.turn;vsScore(g.turn===1?'BLUE':'PINK','TURN')}]]);
const trailAuto=i=>g=>{if((g.t+1)%Math.max(2,4-((g.t+1)/600|0))!==0||g.pause>0)return;const p=g.p[i];const look=(dx,dy)=>{let n=0,x=p.x,y=p.y;while(n<20){x+=dx;y+=dy;if(!g.free(x,y))break;n++}return n};
  const o=[[p.dx,p.dy],[p.dy,-p.dx],[-p.dy,p.dx]].map(d=>({d,v:look(...d)}));if(look(p.dx,p.dy)<4){o.sort((a,b)=>b.v-a.v);p.nd=o[0].d}};
T_('trails',[['ab','Blue autopilot',trailAuto(0)],['ap','Pink autopilot',trailAuto(1)]]);
X_('trails',[['Erase all trails',g=>{g.gr.fill(0);g.p.forEach((p,i)=>{if(g.free(p.x,p.y))g.gr[p.y*60+p.x]=i+1})}]]);
T_('tug',[['ab','Blue auto-mash',g=>{if(!g.cd&&Math.random()<.25){g.r+=.028;g.tp[0]++}}],['ap','Pink auto-mash',g=>{if(!g.cd&&Math.random()<.25){g.r-=.028;g.tp[1]++}}]]);
T_('draw',[['ab','Blue instant reflexes',g=>{if(g.st==='draw')g.down({ny:.9})}],['ap','Pink instant reflexes',g=>{if(g.st==='draw')g.down({ny:.1})}]]);
X_('boxes',[['Smart move for whoever is up',g=>{const l=g.ai();if(l)g.take(...l)}],['Play out the whole game',g=>{for(let k=0;k<60&&running;k++){const l=g.ai();if(!l)break;g.take(...l)}}]]);

/* ---------- 3D solo ---------- */
T_('maze',[['clock','Freeze the clock',g=>{g.time=Math.max(g.time,90*60)}],['turbo','Turbo marble',g=>{g.v.x*=1.04;g.v.z*=1.04}]]);
X_('maze',[['Skip to next maze',g=>{g.lv++;setScore(g.lv);g.time+=25*60;g.build()}]]);
T_('rings',[['auto','Autopilot',g=>{const p=g.pl.position;const r=g.r.filter(r=>r.position.z<0&&!r.userData.done).sort((a,b)=>b.position.z-a.position.z)[0];if(r){p.x=near(p.x,r.position.x,.08);p.y=near(p.y,r.position.y,.08)}}],
  ['mag','Ring magnet',g=>{const p=g.pl.position;g.r.forEach(r=>{if(r.position.z<-3&&!r.userData.done){r.position.x=near(r.position.x,p.x,.04);r.position.y=near(r.position.y,p.y,.04)}})}]]);
T_('stack3',[['auto','Auto-perfect drops',g=>{const t=g.bl[g.bl.length-1];if(Math.abs(g.mv[g.ax]-t[g.ax])<.16){g.mv[g.ax]=t[g.ax];g.drop()}}]]);
X_('stack3',[['Add 10 perfect floors',g=>{for(let k=0;k<10&&running;k++){g.mv[g.ax]=g.bl[g.bl.length-1][g.ax];g.drop()}}]]);
T_('bowl',[['bump','Gutter bumpers',g=>{const b=g.ball.position;if(g.st==='roll'&&Math.abs(b.x)>1.25){b.x=Math.sign(b.x)*1.25;g.bv.x=-g.bv.x;g.gut=0}}],['aim','Auto-aim center',g=>{if(g.st==='roll'){g.bv.x=0;g.ball.position.x=near(g.ball.position.x,0,.2)}}]]);
T_('tunnel',[['auto','Autopilot',g=>{const obs=g.ob.filter(o=>o.position.z>-22&&o.position.z<1.5);if(!obs.length)return;let best=null,bd=9;
    for(let k=0;k<72;k++){const a=g.th+angD(k/72*Math.PI*2,0);if(obs.every(o=>Math.abs(angD(o.userData.a,a))>o.userData.hw+.25)){const d=Math.abs(angD(a,g.th));if(d<bd){bd=d;best=a}}}
    if(best!=null)g.th+=clamp(angD(best,g.th),-.14,.14)}]]);
X_('tunnel',[['Clear the walls',g=>{g.ob.forEach(o=>g.s.remove(o));g.ob=[]}]]);
T_('hoops',[['auto','Auto swish',g=>{if(g.st==='ready')g.shoot(g.hx/45/.25,.38)}],['still','Freeze the hoop',g=>{g.t=Math.max(0,g.t-1)}]]);
T_('hopx',[['stop','Stop all traffic',g=>{g.rows.forEach(r=>{if(r&&r.type==='r')r.sp=0})}],
  ['auto','Auto-hop',g=>{if(g.hop)return;const row=g.rows[g.pr+1];const safe=x=>!row||(row.type==='r'?row.cars.every(c=>Math.abs(c.position.x-x)>2.8):!row.trees.has(x));
    if(safe(g.px))g.go(0,1);else if(row&&row.type!=='r'){for(const dx of[1,-1])if(g.px+dx>=-4&&g.px+dx<=4&&!(g.rows[g.pr]&&g.rows[g.pr].trees.has(g.px+dx))&&safe(g.px+dx)){g.go(dx,0);break}}}]]);
X_('hopx',[['Jump ahead 10 rows',g=>{if(g.hop)return;g.pr+=10;g.best=Math.max(g.best,g.pr);g.pl.position.z=-g.pr;g.pl.position.x=g.px;const r=g.rows[g.pr];if(r)r.trees.delete(g.px);setScore(g.best)}]]);

/* ---------- 3D co-op & versus ---------- */
T_('guard',[['od','Turret overdrive',g=>{g.pl.forEach(p=>p.userData.cd=Math.min(p.userData.cd,4))}],['wall','Unbreakable crystal',g=>{g.hp=Math.max(g.hp,20)}]]);
X_('guard',[['Skip to next wave',g=>{g.en.forEach(e=>e.userData.hp=0);g.left=0;g.pause=1}]]);
T_('lava',[['solid','Solid floor',g=>g.ti.forEach(t=>{if(t.st){t.st=0;t.t=0;t.m.visible=true;t.m.material.color.setHex(0x4a4258)}})],
  ['mag','Coin magnet',g=>{const p=g.pl.find(p=>p.visible&&!p.userData.dead);if(p){g.coin.position.x=near(g.coin.position.x,p.position.x,.06);g.coin.position.z=near(g.coin.position.z,p.position.z,.06)}}]]);
T_('raid',[['tri','Triple shot forever',g=>g.pl.forEach(p=>p.userData.tri=999)],['ff','Force field',g=>g.pl.forEach(p=>p.userData.inv=Math.max(p.userData.inv,3))]]);
X_('raid',[['+5 lives',g=>{g.lives+=5}]]);
const sumoLock=i=>g=>{if(g.fall[i])return;const b=g.b[i].position,r=hyp(b.x,b.z);if(r>6.5){b.x*=6.5/r;b.z*=6.5/r;const v=g.v[i],out=(v.x*b.x+v.z*b.z)/6.5;if(out>0){v.x-=out*b.x/6.5*1.5;v.z-=out*b.z/6.5*1.5}}};
T_('sumo',[['lb','Blue can\'t fall',sumoLock(0)],['lp','Pink can\'t fall',sumoLock(1)],['tb','Blue turbo',g=>{const v=g.v[0];const s=hyp(v.x,v.z);if(s<.45){v.x*=1.03;v.z*=1.03}}]]);

/* ---------- casino ---------- */
X_('bj',[['Make the dealer bust',g=>{if(g.ph!=='play')return;g.d=[{r:8,s:0},{r:4,s:1}];g.shoe.push({r:11,s:2})}],['Give me 21',g=>{if(g.ph!=='play')return;g.p=[{r:12,s:0},{r:7,s:2},{r:0,s:1}];g.stand()}]]);
X_('bacc',[['Next hand: Player wins',()=>{ADM.forced.bacc='P'}],['Next hand: Banker wins',()=>{ADM.forced.bacc='B'}],['Next hand: Tie',()=>{ADM.forced.bacc='T'}]]);
X_('vpoker',[['Royal flush now',g=>{if(g.ph!=='draw')return;g.h=[8,9,10,11,12].map(r=>({r,s:2}));g.held=[1,1,1,1,1]}]]);
X_('holdem',[['All bots fold',g=>{if(g.ph!=='act'&&g.ph!=='face')return;g.bots.forEach(b=>{b.live=false;b.say='folds'});g.next()}],['Royal flush for me',g=>{if(g.ph!=='act'&&g.ph!=='face')return;const RF=[12,11,10,9,8].map(r=>({r,s:3}));g.me=RF.slice(0,2);g.board=RF.slice(2).concat(g.board.slice(3).filter(c=>!(c.s===3&&c.r>=8)).concat([{r:0,s:0},{r:1,s:1}]).slice(0,2));g.bots.forEach(b=>b.h=b.h.map(c=>c.s===3&&c.r>=8?{r:2,s:0}:c))}]]);
X_('hilo',[['Double my streak',g=>{if(g.ph==='run')g.mult*=2}]]);
X_('roul',[['Next spin hits my best number',g=>{ADM.forced.roul=bestRoul(g.bets);bankTaint()}]]);
X_('pwheel',[['Next spin lands 3x',()=>{ADM.forced.pwheel=7}]]);
X_('plinko',[['Next ball hits 16x',()=>{ADM.forced.plinko=1}]]);
X_('gmines',[['Remove every mine',g=>{if(g.ph==='play')g.mn.fill(0)}]]);
X_('crash',[['Next rocket flies to 1,000x',()=>{ADM.forced.crash=1000}]]);
function bestRoul(bets){let best=0,bv=-1;for(let n=0;n<=36;n++){let w=0;for(const k in bets)w+=bets[k]*rPay(k,n);if(w>bv){bv=w;best=n}}return best}

/* ---------- board games ---------- */
GAMES.filter(g=>g.cat==='board').forEach(g=>X_(g.id,[
  ['Play the best move for me',b=>{if(!b.S||b.done||!b.canAct())return;const m=b.bot(b.S,2);if(m)b.doMove(m)}],
  ['Bot plays badly (easy mode now)',b=>{if(b.pm==='bot')b.lvl=0}],
  ['Win this game now',b=>{if(b.pm==='net'||!b.S||b.done)return;b.tok++;b.think=false;b.done={w:b.pm==='bot'?b.me:b.turn(b.S),why:'Admin win.'};if(b.pm==='bot')BW.inc(b.id);b.render()}],
  ['Take back 5 moves',b=>{if(b.pm==='net'||!b.hist||b.ui!=='play')return;for(let k=0;k<5&&b.hist.length;k++)b.S=b.hist.pop();b.done=null;b.tok++;b.think=false;b.render();b.maybeBot()}],
  ['Skip the bot\'s turn',b=>{if(b.pm!=='bot'||!b.think)return;b.tok++;b.think=false;const s=b.S;if(b.id==='chess')b.S=Object.assign({},s,{t:1-s.t,ep:-1});else if('t' in s)b.S=Object.assign({},s,{t:1-s.t});b.render()}]]));
