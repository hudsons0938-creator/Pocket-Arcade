/* 3D CO-OP & VERSUS — two players on one screen: P1 left half (WASD), P2 right half (arrows). */
const COOP=['CO-OP · 2 PLAYERS','SOLO'];
function hero(c){const g2=new THREE.Group();const b=new THREE.Mesh(new THREE.CylinderGeometry(.45,.5,.9,16),lam(c));b.position.y=.45;const h=orb(.32,c);h.position.y=1.1;const e=box(.4,.12,.1,0x111111);e.position.set(0,1.15,.28);g2.add(b,h,e);return g2}
const live=gm=>gm.solo?[gm.pl[0]]:gm.pl;

/* Crystal Guard */
add({id:'guard',name:'CRYSTAL GUARD',c:'--a5',cat:'3dc',modes:COOP,three:true,sticks:true,desc:'Team up to defend a glowing crystal from waves of crawlers.',how:'Each player drags on their half of the screen to move (P1 left, P2 right; WASD and arrows). You fire at the nearest crawler automatically. Stand in their path to block them.',
  init(){const s=this.s=scene3(0x0d1220,22,50);this.cam=cam3(55);this.cam.position.set(0,17,13);this.cam.lookAt(0,0,1);
    const fl=new THREE.Mesh(new THREE.CylinderGeometry(12.5,12.5,.4,48),lam(0x1e1a2e));fl.position.y=-.2;s.add(fl);
    const ring=new THREE.Mesh(new THREE.RingGeometry(1.6,1.8,32),new THREE.MeshBasicMaterial({color:0xc58bff,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.02;s.add(ring);
    this.cr=new THREE.Mesh(new THREE.OctahedronGeometry(1.2),lam(0xc58bff,0x4a1a7a));this.cr.position.y=1.6;s.add(this.cr);
    this.pl=[hero(0x5ab0ff),hero(0xff5d8f)];this.pl[0].position.set(-2.5,0,3);this.pl[1].position.set(2.5,0,3);this.pl.forEach((p,i)=>{p.userData={cd:i*9};s.add(p)});if(this.solo)this.pl[1].visible=false;
    this.en=[];this.bl=[];this.hp=20;this.wave=0;this.left=0;this.pause=90;this.t=0;setScore(0)},
  update(){this.t++;this.cr.rotation.y+=.02;this.cr.position.y=1.6+Math.sin(this.t*.05)*.15;
    live(this).forEach((p,i)=>{const pd=padLR(i);p.position.x+=pd.x*.17;p.position.z+=pd.y*.17;const r=hyp(p.position.x,p.position.z);if(r>11.5){p.position.x*=11.5/r;p.position.z*=11.5/r}
      if(hyp(pd.x,pd.y)>.1)p.rotation.y=Math.atan2(pd.x,pd.y);
      if(--p.userData.cd<=0){let best=null,bd=9;for(const e of this.en){const d=hyp(e.position.x-p.position.x,e.position.z-p.position.z);if(d<bd){bd=d;best=e}}
        if(best){const dx=best.position.x-p.position.x,dz=best.position.z-p.position.z,d=hyp(dx,dz);const b=orb(.16,i?0xff9ab8:0x9fd2ff,i?0x5a0f26:0x0a2a50);b.position.set(p.position.x,.9,p.position.z);b.userData={vx:dx/d*.55,vz:dz/d*.55,l:30};this.s.add(b);this.bl.push(b);p.userData.cd=16;beep(500+i*120,.02,'square',.02)}}});
    if(this.pause>0){if(--this.pause===0){this.wave++;this.left=4+this.wave*2;this.sp=0}setHud('WAVE '+(this.wave+1)+' INCOMING · CRYSTAL '+this.hp);}
    else{if(this.left>0&&--this.sp<=0){this.left--;this.sp=Math.max(14,42-this.wave*3);const a=rnd(0,7),big=this.wave>1&&Math.random()<.2;
        const e=big?box(1.1,1.1,1.1,0xff8a3d,0x3a1500):box(.7,.7,.7,0x3ddc97,0x0a3a20);e.position.set(Math.cos(a)*12,big?.55:.35,Math.sin(a)*12);e.userData={hp:big?4:1,sp:(big?.022:.035)+this.wave*.003};this.s.add(e);this.en.push(e)}
      if(!this.left&&!this.en.length){this.pause=150;beep(880,.3,'triangle')}setHud('WAVE '+this.wave+' · CRYSTAL ♦'+this.hp)}
    for(const e of this.en){const p=e.position,d=hyp(p.x,p.z);p.x-=p.x/d*e.userData.sp;p.z-=p.z/d*e.userData.sp;e.rotation.y+=.05;
      for(const pl of live(this)){const dx=p.x-pl.position.x,dz=p.z-pl.position.z,dd=hyp(dx,dz);if(dd<1&&dd>0){p.x=pl.position.x+dx/dd;p.z=pl.position.z+dz/dd}}
      if(d<1.5){e.userData.hp=0;e.userData.hit=1;this.hp--;beep(110,.2,'sawtooth');if(this.hp<=0){setHud('');return over('CRYSTAL SHATTERED')}}}
    for(const b of this.bl){b.position.x+=b.userData.vx;b.position.z+=b.userData.vz;b.userData.l--;
      for(const e of this.en)if(e.userData.hp>0&&hyp(e.position.x-b.position.x,e.position.z-b.position.z)<.65){b.userData.l=0;if(--e.userData.hp<=0){setScore(score+(e.scale&&e.geometry.parameters.width>1?3:1));beep(300,.05)}break}}
    this.en=this.en.filter(e=>{if(e.userData.hp<=0){this.s.remove(e);return false}return true});this.bl=this.bl.filter(b=>{if(b.userData.l<=0){this.s.remove(b);return false}return true})},
  draw:r3,
  art(c){c.fillStyle='#1e1a2e';c.beginPath();c.ellipse(64,56,58,30,0,0,7);c.fill();c.fillStyle='#c58bff';c.beginPath();c.moveTo(64,24);c.lineTo(74,44);c.lineTo(64,64);c.lineTo(54,44);c.fill();c.fillStyle='#5ab0ff';c.fillRect(30,56,10,14);c.fillStyle='#ff5d8f';c.fillRect(90,56,10,14);c.fillStyle='#3ddc97';c.fillRect(10,40,8,8);c.fillRect(112,64,8,8)}});

/* Lava Floor */
add({id:'lava',name:'LAVA FLOOR',c:'--a6',cat:'3dc',modes:COOP,three:true,sticks:true,desc:'Tiles crumble into lava. Keep each other alive and grab coins.',how:'Move with your half of the screen (P1 left, P2 right; WASD and arrows). Red tiles are about to drop. If your partner falls, grab two coins to bring them back.',
  init(){const s=this.s=scene3(0x1a0a08,20,40);this.cam=cam3(52);this.cam.position.set(0,15,11);this.cam.lookAt(0,0,.5);
    const lv=new THREE.Mesh(new THREE.PlaneGeometry(60,60),new THREE.MeshBasicMaterial({color:0xff5a1f}));lv.rotation.x=-Math.PI/2;lv.position.y=-3;s.add(lv);this.lv=lv;
    this.ti=[];for(let r=0;r<9;r++)for(let c=0;c<9;c++){const m=box(1.5,.4,1.5,0x4a4258);m.position.set((c-4)*1.6,-.2,(r-4)*1.6);s.add(m);this.ti.push({m,st:0,t:0})}
    this.pl=[hero(0x5ab0ff),hero(0xff5d8f)];this.pl[0].position.set(-1.6,0,0);this.pl[1].position.set(1.6,0,0);this.pl.forEach(p=>{p.userData={dead:0,vy:0};s.add(p)});if(this.solo)this.pl[1].visible=false;
    this.coin=new THREE.Mesh(new THREE.CylinderGeometry(.35,.35,.1,20),lam(0xffb627,0x6a4a00));this.coin.rotation.x=Math.PI/2;s.add(this.coin);this.placeCoin();
    this.t=0;this.coins=0;this.rv=0;setScore(0)},
  tile(x,z){const c=Math.round(x/1.6)+4,r=Math.round(z/1.6)+4;if(c<0||c>8||r<0||r>8)return null;return this.ti[r*9+c]},
  placeCoin(){const ok=this.ti.filter(t=>t.st===0);const t=pick(ok.length?ok:this.ti);this.coin.position.set(t.m.position.x,.7,t.m.position.z)},
  update(){this.t++;this.coin.rotation.z+=.06;this.lv.material.color.setHSL(.04,1,.45+Math.sin(this.t*.05)*.05);
    const every=Math.max(14,60-(this.t/240|0)*4);if(this.t>90&&this.t%every===0){const ok=this.ti.filter(t=>t.st===0);for(let k=0;k<Math.min(ok.length-6,1+(this.t/1500|0));k++){const t=pick(ok);if(t.st===0){t.st=1;t.t=55}}}
    for(const t of this.ti){if(t.st===1){t.m.material.color.setHex(t.t%10<5?0xff3d3d:0x7a3a3a);if(--t.t<=0){t.st=2;t.t=300;t.m.visible=false}}else if(t.st===2&&--t.t<=0){t.st=0;t.m.visible=true;t.m.material.color.setHex(0x4a4258)}}
    const ps=live(this);let alive=0;
    ps.forEach((p,i)=>{const u=p.userData;if(u.dead===2)return;if(u.dead===1){u.vy-=.02;p.position.y+=u.vy;if(p.position.y<-4){u.dead=2;p.visible=false;beep(90,.3,'sawtooth')}alive++;return}
      alive++;const pd=padLR(i);p.position.x=clamp(p.position.x+pd.x*.13,-8,8);p.position.z=clamp(p.position.z+pd.y*.13,-8,8);if(hyp(pd.x,pd.y)>.1)p.rotation.y=Math.atan2(pd.x,pd.y);
      const t=this.tile(p.position.x,p.position.z);if(!t||t.st===2){u.dead=1;u.vy=0}
      if(hyp(p.position.x-this.coin.position.x,p.position.z-this.coin.position.z)<.8){this.coins++;beep(990,.08,'triangle');this.placeCoin();
        const other=ps.find(o=>o!==p&&o.userData.dead===2);if(other&&++this.rv>=2){this.rv=0;other.userData={dead:0,vy:0};other.visible=true;other.position.set(p.position.x,0,p.position.z);beep(660,.3,'triangle')}}});
    if(!alive)return over('INTO THE LAVA');
    setScore(this.coins*5+(this.t/60|0));const dn=ps.find(o=>o.userData.dead===2);setHud(dn&&ps.some(o=>!o.userData.dead)?'GRAB '+(2-this.rv)+' COIN'+(2-this.rv>1?'S':'')+' TO REVIVE '+(dn===this.pl[0]?'BLUE':'PINK'):'COINS '+this.coins)},
  draw:r3,
  art(c){c.fillStyle='#ff5a1f';c.fillRect(0,0,128,96);for(let r=0;r<3;r++)for(let k=0;k<4;k++){if((r+k)%3===1)continue;c.fillStyle=(r===1&&k===2)?'#ff3d3d':'#4a4258';c.fillRect(14+k*26,12+r*26,22,22)}c.fillStyle='#5ab0ff';c.fillRect(20,18,10,12);c.fillStyle='#ffb627';c.beginPath();c.arc(96,72,6,0,7);c.fill()}});

/* Twin Raiders */
add({id:'raid',name:'TWIN RAIDERS',c:'--a4',cat:'3dc',modes:COOP,three:true,sticks:true,desc:'Fly two ships side by side and blast an invading fleet. Shared lives.',how:'P1 steers on the left half, P2 on the right (WASD and arrows). Ships fire on their own. Green orbs give triple shot. You share five lives.',
  init(){const s=this.s=scene3(0x060818,25,55);this.cam=cam3(55);this.cam.position.set(0,16,11);this.cam.lookAt(0,0,-3);
    this.stars=[];for(let i=0;i<80;i++){const st=box(.06,.06,.06,0xffffff,0xffffff);st.position.set(rnd(-14,14),-2,rnd(-30,12));s.add(st);this.stars.push(st)}
    const ship=c=>{const g2=new THREE.Group();const b=new THREE.Mesh(new THREE.ConeGeometry(.5,1.6,4),lam(c));b.rotation.x=-Math.PI/2;const w=box(1.8,.12,.5,c);w.position.z=.3;g2.add(b,w);return g2};
    this.pl=[ship(0x5ab0ff),ship(0xff5d8f)];this.pl[0].position.set(-2,0,5);this.pl[1].position.set(2,0,5);this.pl.forEach((p,i)=>{p.userData={cd:i*5,inv:0,tri:0};s.add(p)});if(this.solo){this.pl[1].visible=false;this.pl[0].position.x=0}
    this.en=[];this.bl=[];this.pu=[];this.t=0;this.lives=5;setScore(0)},
  update(){this.t++;for(const st of this.stars){st.position.z+=.3;if(st.position.z>12)st.position.z-=42}
    live(this).forEach((p,i)=>{const pd=padLR(i),u=p.userData;p.position.x=clamp(p.position.x+pd.x*.2,-8,8);p.position.z=clamp(p.position.z+pd.y*.2,-1,7);p.rotation.z=-pd.x*.4;
      if(u.inv>0){u.inv--;p.visible=u.inv%8<4}else p.visible=true;if(u.tri>0)u.tri--;
      if(--u.cd<=0){u.cd=9;const angs=u.tri?[-.18,0,.18]:[0];for(const a of angs){const b=box(.12,.12,.6,i?0xff9ab8:0x9fd2ff,i?0x5a0f26:0x0a2a50);b.position.set(p.position.x,0,p.position.z-.9);b.userData={vx:Math.sin(a)*.6,vz:-Math.cos(a)*.6};this.s.add(b);this.bl.push(b)}}});
    if(this.t%Math.max(14,44-(this.t/300|0)*3)===0){const big=Math.random()<.15;const e=big?box(1.6,.6,1.2,0xff8a3d,0x3a1500):new THREE.Mesh(new THREE.OctahedronGeometry(.55),lam(0x3ddc97,0x0a3a20));
      e.position.set(rnd(-7,7),0,-26);e.userData={hp:big?5:1,big,ph:rnd(0,7),vz:big?.07:rnd(.09,.14)+this.t/40000};this.s.add(e);this.en.push(e)}
    if(this.t%900===450){const o=orb(.4,0x3ddc97,0x1a8a5a);o.position.set(rnd(-6,6),0,-24);this.s.add(o);this.pu.push(o)}
    for(const e of this.en){const u=e.userData;e.position.z+=u.vz;e.position.x+=Math.sin(this.t*.03+u.ph)*.05;e.rotation.y+=.04;
      if(e.position.z>9){u.hp=0;this.hurt()}
      for(const p of live(this))if(u.hp>0&&p.userData.inv<=0&&hyp(p.position.x-e.position.x,p.position.z-e.position.z)<(u.big?1.2:.9)){u.hp=0;p.userData.inv=90;this.hurt()}}
    for(const b of this.bl){b.position.x+=b.userData.vx;b.position.z+=b.userData.vz;for(const e of this.en)if(e.userData.hp>0&&hyp(e.position.x-b.position.x,e.position.z-b.position.z)<(e.userData.big?1:.6)){b.userData.d=1;if(--e.userData.hp<=0){setScore(score+(e.userData.big?5:1));beep(260,.05)}break}}
    for(const o of this.pu){o.position.z+=.12;for(const p of live(this))if(hyp(p.position.x-o.position.x,p.position.z-o.position.z)<1){o.userData.d=1;p.userData.tri=360;beep(990,.2,'triangle')}}
    const cl=(arr,f)=>arr.filter(x=>{if(f(x)){this.s.remove(x);return false}return true});
    this.en=cl(this.en,e=>e.userData.hp<=0);this.bl=cl(this.bl,b=>b.userData.d||b.position.z<-30);this.pu=cl(this.pu,o=>o.userData.d||o.position.z>10);
    if(this.lives<=0)return over('FLEET LOST');setHud('♥'.repeat(Math.max(0,this.lives)))},
  hurt(){this.lives--;beep(120,.25,'sawtooth')},
  draw:r3,
  art(c){c.fillStyle='#060818';c.fillRect(0,0,128,96);c.fillStyle='#5ab0ff';c.beginPath();c.moveTo(44,62);c.lineTo(52,84);c.lineTo(36,84);c.fill();c.fillStyle='#ff5d8f';c.beginPath();c.moveTo(84,62);c.lineTo(92,84);c.lineTo(76,84);c.fill();c.fillStyle='#3ddc97';c.fillRect(30,16,10,10);c.fillRect(70,24,10,10);c.fillStyle='#ff8a3d';c.fillRect(92,8,20,10)}});

/* Sumo Smash 3D */
add({id:'sumo',name:'SUMO SMASH 3D',c:'--a3',cat:'3dv',modes:['2 PLAYERS','VS CPU'],three:true,sticks:true,desc:'Ram your rival off a floating ring. Best of 5 rounds.',how:'Blue drags on the left half, Pink on the right (WASD and arrows). Build up speed and slam into each other. Last one on the ring takes the round.',
  init(){const s=this.s=scene3(0x0e1020,20,45);this.cam=cam3(52);this.cam.position.set(0,13,11.5);this.cam.lookAt(0,0,.5);
    const pf=new THREE.Mesh(new THREE.CylinderGeometry(7,6.4,.8,48),lam(0xe8d6b0));pf.position.y=-.4;s.add(pf);
    const rg=new THREE.Mesh(new THREE.RingGeometry(6.6,6.9,48),new THREE.MeshBasicMaterial({color:0xff5d8f,side:THREE.DoubleSide}));rg.rotation.x=-Math.PI/2;rg.position.y=.01;s.add(rg);
    this.b=[orb(.8,0x5ab0ff,0x0a2a50),orb(.8,0xff5d8f,0x5a0f26)];this.b.forEach(b=>s.add(b));this.sc=[0,0];this.round();vsScore(0,0)},
  round(){this.b[0].position.set(-3,.8,0);this.b[1].position.set(3,.8,0);this.v=[{x:0,z:0,y:0},{x:0,z:0,y:0}];this.fall=[0,0];this.pause=60;this.over=0},
  update(){if(this.pause>0){this.pause--;setHud(this.pause>0?'READY…':'');return}
    const p0=this.b[0].position,p1=this.b[1].position;
    for(let i=0;i<2;i++){const b=this.b[i].position,v=this.v[i];if(this.fall[i]){v.y-=.02;b.y+=v.y;b.x+=v.x;b.z+=v.z;continue}
      let pd=padLR(i);if(i===1&&this.cpu){const o=p0,dx=o.x-b.x,dz=o.z-b.z,d=hyp(dx,dz)||1,r=hyp(b.x,b.z);let ax=dx/d,az=dz/d;if(r>4.5){ax=ax*.3-b.x/r;az=az*.3-b.z/r}const l=hyp(ax,az)||1;pd={x:ax/l*.85,y:az/l*.85}}
      v.x=(v.x+pd.x*.014)*.985;v.z=(v.z+pd.y*.014)*.985;b.x+=v.x;b.z+=v.z;this.b[i].rotation.x+=v.z;this.b[i].rotation.z-=v.x;
      if(hyp(b.x,b.z)>7.1){this.fall[i]=1;beep(140,.3,'sawtooth')}}
    const dx=p1.x-p0.x,dz=p1.z-p0.z,d=hyp(dx,dz);
    if(d<1.6&&d>0&&!this.fall[0]&&!this.fall[1]){const nx=dx/d,nz=dz/d,a=this.v[0],c=this.v[1],rv=(a.x-c.x)*nx+(a.z-c.z)*nz;
      if(rv>0){const k=rv*1.35;a.x-=k*nx;a.z-=k*nz;c.x+=k*nx;c.z+=k*nz;beep(200+rv*900,.06,'square',.05)}p0.x-=nx*(1.6-d)/2;p0.z-=nz*(1.6-d)/2;p1.x+=nx*(1.6-d)/2;p1.z+=nz*(1.6-d)/2}
    if(!this.over&&(this.b[0].position.y<-3||this.b[1].position.y<-3)){this.over=1;const w=this.b[0].position.y<-3?(this.b[1].position.y<-3?-1:1):0;
      if(w>=0){this.sc[w]++;vsScore(...this.sc)}if(w>=0&&this.sc[w]>=3)return win(nm(w,this.cpu)+' WINS!',this.sc[0]+' rounds to '+this.sc[1]);this.round()}},
  draw:r3,
  art(c){c.fillStyle='#e8d6b0';c.beginPath();c.ellipse(64,56,56,28,0,0,7);c.fill();c.fillStyle='#5ab0ff';c.beginPath();c.arc(44,50,12,0,7);c.fill();c.fillStyle='#ff5d8f';c.beginPath();c.arc(84,54,12,0,7);c.fill()}});
