/* Pocket Arcade Vol. 2 — shared engine */
const W=360,H=540;
/* admin state (panel lives in admin.js) */
const ADM={on:(()=>{try{return localStorage.getItem('pa_admin')==='1'}catch(e){return false}})(),god:false,freeze:false,speed:1,xray:false,used:false,forced:{},
  take(k){if(!(k in this.forced))return null;const v=this.forced[k];delete this.forced[k];return v}};
const $=id=>document.getElementById(id);
const cv=$('cv'),g=cv.getContext('2d'),gl=$('gl');
let R3=null,cur=null,score=0,running=false,raf=0,last=0,acc=0;
const keys={},ptrs=new Map(),GAMES=[];
const store={get(k){try{return +localStorage.getItem('pa_'+k)||0}catch(e){return 0}},set(k,v){try{localStorage.setItem('pa_'+k,v)}catch(e){}}};
const rnd=(a,b)=>a+Math.random()*(b-a),ri=(a,b)=>Math.floor(rnd(a,b+1)),clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),hyp=Math.hypot,pick=a=>a[Math.random()*a.length|0];
const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(x,y,w,h)};
const C=(x,y,r,c)=>{g.fillStyle=c;g.beginPath();g.arc(x,y,r,0,7);g.fill()};
const T=(s,x,y,c='#f1eefa',sz=12,al='center')=>{g.fillStyle=c;g.font=sz+'px "Press Start 2P",monospace';g.textAlign=al;g.fillText(s,x,y)};
const TF=(s,x,y,c,sz)=>{g.save();g.translate(x,y);g.rotate(Math.PI);T(s,0,0,c,sz);g.restore()}; // upside-down text for the top player
const bg=(c='#0c0a14')=>R(0,0,W,H,c);
const P1C='#5ab0ff',P2C='#ff5d8f';
function segDist(px,py,ax,ay,bx,by){const dx=bx-ax,dy=by-ay,l=dx*dx+dy*dy;let t=l?((px-ax)*dx+(py-ay)*dy)/l:0;t=clamp(t,0,1);return hyp(px-ax-t*dx,py-ay-t*dy)}
function setScore(v){score=v;$('sc').textContent=v}
function setHud(s){$('hud').textContent=s||''}
function add(gm){GAMES.push(gm)}

/* sound: tiny synth, only after a tap */
let AC=null;
function beep(f=440,d=.08,type='square',v=.05){try{if(!AC)return;const o=AC.createOscillator(),gn=AC.createGain();o.type=type;o.frequency.value=f;gn.gain.value=v;gn.gain.exponentialRampToValueAtTime(.0001,AC.currentTime+d);o.connect(gn);gn.connect(AC.destination);o.start();o.stop(AC.currentTime+d)}catch(e){}}
function unlockAudio(){try{if(!AC){const A=window.AudioContext||window.webkitAudioContext;if(A)AC=new A()}AC&&AC.resume&&AC.resume()}catch(e){}}

/* sticks: drag from where your thumb lands */
function joyR(test){for(const p of ptrs.values())if(test(p)){const dx=p.cx-p.scx,dy=p.cy-p.scy,d=hyp(dx,dy);if(d<6)return{x:0,y:0,on:1};const m=Math.min(1,d/45)/d;return{x:dx*m,y:dy*m,on:1}}return null}
function kj(u,d,l,r){const x=(keys[r]?1:0)-(keys[l]?1:0),y=(keys[d]?1:0)-(keys[u]?1:0),L=hyp(x,y);return L?{x:x/L,y:y/L,on:1}:null}
const KP1=['KeyW','KeyS','KeyA','KeyD'],KP2=['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'];
/* left/right split (3D co-op) */
function padLR(i){const solo=cur.solo||cur.cpu||cur.cat==='3ds';const t=solo?()=>true:(i===0?p=>p.sx<.5:p=>p.sx>=.5);
  return joyR(t)||kj(...(i===0?KP1:KP2))||(solo&&i===0?kj(...KP2):null)||{x:0,y:0,on:0}}
/* bottom/top split (2D versus). P1 = bottom */
function padTB(i){return joyR(i===0?p=>p.sy>=.5:p=>p.sy<.5)||kj(...(i===0?KP1:KP2))||(cur.cpu&&i===0?kj(...KP2):null)||{x:0,y:0,on:0}}

/* 3D helpers */
const lam=(c,e)=>new THREE.MeshLambertMaterial({color:c,emissive:e||0});
function scene3(bgc,fogN,fogF){const s=new THREE.Scene();s.background=new THREE.Color(bgc);if(fogN)s.fog=new THREE.Fog(bgc,fogN,fogF);
  s.add(new THREE.HemisphereLight(0xffffff,0x332244,1));const d=new THREE.DirectionalLight(0xffffff,.7);d.position.set(4,10,6);s.add(d);return s}
const box=(w,h,d,c,e)=>new THREE.Mesh(new THREE.BoxGeometry(w,h,d),lam(c,e));
const orb=(r,c,e)=>new THREE.Mesh(new THREE.SphereGeometry(r,20,14),lam(c,e));
const cam3=(fov=60)=>new THREE.PerspectiveCamera(fov,.66,.1,300);
function r3(){if(R3&&cur.s&&cur.cam)R3.render(cur.s,cur.cam)}

/* flow */
function msg(h,p,b,b2){$('mh').textContent=h;$('mp').textContent=p;$('mgo').textContent=b;$('mgo2').hidden=!b2;if(b2)$('mgo2').textContent=b2;$('msg').hidden=false}
function open(gm){cur=gm;$('lobby').hidden=true;$('play').hidden=false;$('title').textContent=gm.name;setHud('');setScore(0);
  $('dom').classList.remove('cas');cv.hidden=!!(gm.three||gm.dom);gl.hidden=!gm.three;$('dom').hidden=!gm.dom;$('dom').onclick=null;
  if(gm.dom){gm.mode=0;running=false;$('msg').hidden=true;gm.init();window.scrollTo(0,0);return}
  if(gm.three){if(typeof THREE==='undefined'){msg('3D UNAVAILABLE','The 3D engine did not load. Check your connection and reopen the page.','LOBBY');$('mgo').onclick=leave;return}
    if(!R3){try{R3=new THREE.WebGLRenderer({canvas:gl,antialias:true})}catch(e){msg('3D UNAVAILABLE','This device could not start 3D graphics.','LOBBY');$('mgo').onclick=leave;return}}}
  gm.mode=0;gm.solo=false;gm.cpu=false;
  try{gm.init()}catch(e){console.error(e)}fit();gm.draw();
  $('mgo').onclick=()=>start(0);$('mgo2').onclick=()=>start(1);
  msg(gm.name,gm.how,gm.modes?gm.modes[0]:'START',gm.modes&&gm.modes[1]);window.scrollTo(0,0)}
function start(mode){unlockAudio();$('msg').hidden=true;const gm=cur;gm.mode=mode||0;gm.solo=gm.cat==='3dc'&&gm.mode===1;gm.cpu=gm.cat!=='3dc'&&!!gm.modes&&gm.mode===1;
  ptrs.clear();setHud('');gm.init();fit();if(gm.dom)return;running=true;last=0;acc=0;cancelAnimationFrame(raf);raf=requestAnimationFrame(loop)}
function leave(){cur&&cur.leave&&cur.leave();$('dom').onclick=null;$('dom').classList.remove('cas');running=false;cancelAnimationFrame(raf);ptrs.clear();knobs();$('play').hidden=true;$('lobby').hidden=false;refreshBest()}
$('back').onclick=leave;
/* solo game over: saves best */
function over(title){if(!running&&!cur.dom)return;if(ADM.god&&!cur.dom&&!/CLEAR|DONE|FINAL|STRIKE/.test(title||''))return;running=false;beep(140,.3,'sawtooth',.06);if(typeof lbPost==='function')lbPost(cur.id,score);const best=store.get(cur.id),nb=score>best;if(nb)store.set(cur.id,score);
  setTimeout(()=>msg(title||(nb?'NEW BEST!':'GAME OVER'),'Score '+score+(nb?'':' · Best '+best),'PLAY AGAIN'),250)}
/* versus game over */
function win(title,sub){if(!running)return;running=false;beep(660,.25,'triangle',.06);const m=cur.modes;
  setTimeout(()=>msg(title,sub||'Same seats? Go again.',m?m[0]:'REMATCH',m&&m[1]),250)}
function loop(t){if(!running)return;if(!last)last=t;acc+=Math.min(100,t-last)*(ADM.freeze?0:ADM.speed);last=t;
  while(acc>=16.667&&running){cur.hold&&cur.hold(keys);ADM.tick&&ADM.tick(cur);cur.update();acc-=16.667}
  cur.draw();knobs();if(running)raf=requestAnimationFrame(loop)}
function fit(){if(!cur)return;const st=$('stage').getBoundingClientRect();
  if(cur.three&&R3){const w=Math.max(120,st.width-32),h=Math.max(120,st.height-16);R3.setPixelRatio(Math.min(2,devicePixelRatio||1));R3.setSize(w,h);if(cur.cam){cur.cam.aspect=w/h;cur.cam.updateProjectionMatrix()}return}
  const s=Math.min((st.width-32)/W,(st.height-16)/H);cv.style.width=W*s+'px';cv.style.height=H*s+'px'}
addEventListener('resize',fit);

/* joystick rings for stick games */
const kn=[];
function knobs(){let i=0;if(running&&cur&&cur.sticks)for(const p of ptrs.values()){if(i>3)break;let k=kn[i];if(!k){k=document.createElement('div');k.className='knob';k.innerHTML='<i></i>';document.body.appendChild(k);kn[i]=k}
  k.hidden=false;k.style.left=p.scx+'px';k.style.top=p.scy+'px';const dx=p.cx-p.scx,dy=p.cy-p.scy,d=hyp(dx,dy),m=d>25?25/d:1;k.firstChild.style.transform=`translate(${dx*m}px,${dy*m}px)`;i++}
  for(;i<kn.length;i++)kn[i].hidden=true}

/* input */
function pt(e,el){const r=el.getBoundingClientRect();const nx=(e.clientX-r.left)/r.width,ny=(e.clientY-r.top)/r.height;return{x:nx*W,y:ny*H,nx,ny,cx:e.clientX,cy:e.clientY,id:e.pointerId}}
[cv,gl].forEach(el=>{
  el.addEventListener('pointerdown',e=>{e.preventDefault();try{el.setPointerCapture(e.pointerId)}catch(_){}const p=pt(e,el);
    ptrs.set(e.pointerId,Object.assign({},p,{sx:p.nx,sy:p.ny,scx:p.cx,scy:p.cy,t:performance.now()}));if(running&&cur.down)cur.down(p)});
  el.addEventListener('pointermove',e=>{const q=ptrs.get(e.pointerId);const p=pt(e,el);if(q)Object.assign(q,{x:p.x,y:p.y,nx:p.nx,ny:p.ny,cx:p.cx,cy:p.cy});
    if(running&&cur.move&&(q||cur.hover))cur.move(p)});
  ['pointerup','pointercancel'].forEach(v=>el.addEventListener(v,e=>{const q=ptrs.get(e.pointerId);ptrs.delete(e.pointerId);if(running&&cur.up&&q){const p=pt(e,el);p.sx=q.sx;p.sy=q.sy;p.sxp=q.sx*W;p.syp=q.sy*H;p.dt=performance.now()-q.t;cur.up(p)}}));
});
addEventListener('keydown',e=>{if(!cur||$('play').hidden)return;keys[e.code]=true;
  if(!running&&!$('msg').hidden&&(e.code==='Enter')){$('mgo').click();return}
  if(running&&cur.key)cur.key(e.code);if(e.code.startsWith('Arrow')||e.code==='Space')e.preventDefault()});
addEventListener('keyup',e=>keys[e.code]=false);
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;ptrs.clear()});
