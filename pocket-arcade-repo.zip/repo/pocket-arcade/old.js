/* Original Pocket Arcade games, ported */
const txt=(s,x,y,c='#f1eefa',sz=12)=>{g.fillStyle=c;g.font=sz+'px "Press Start 2P", monospace';g.textAlign='center';g.fillText(s,x,y)};
/* ---------- Noodle (snake) ---------- */
const snake={id:'snake',name:'NOODLE',c:'--a2',desc:'Slurp dots, grow longer, never bite your tail.',
  how:'Swipe or use arrow keys to turn.',
  init(){this.n=18;this.s=20;this.body=[[9,13],[9,14],[9,15]];this.d=[0,-1];this.nd=[0,-1];this.t=0;this.place();setScore(0)},
  place(){do{this.f=[Math.random()*this.n|0,Math.random()*27|0]}while(this.body.some(b=>b[0]==this.f[0]&&b[1]==this.f[1]))},
  turn(dx,dy){if(dx==-this.d[0]&&dy==-this.d[1])return;this.nd=[dx,dy]},
  update(){if(++this.t<Math.max(4,9-Math.floor(score/5)))return;this.t=0;this.d=this.nd;
    const h=[this.body[0][0]+this.d[0],this.body[0][1]+this.d[1]];
    if(h[0]<0||h[1]<0||h[0]>=this.n||h[1]>=27||this.body.some(b=>b[0]==h[0]&&b[1]==h[1]))return over();
    this.body.unshift(h);if(h[0]==this.f[0]&&h[1]==this.f[1]){setScore(score+1);this.place()}else this.body.pop()},
  draw(){R(0,0,W,H,'#0c0a14');for(let x=0;x<18;x++)for(let y=0;y<27;y++)if((x+y)%2)R(x*20,y*20,20,20,'#100d1a');
    R(this.f[0]*20+4,this.f[1]*20+4,12,12,'#ffb627');
    this.body.forEach((b,i)=>R(b[0]*20+1,b[1]*20+1,18,18,i?'#2fb57c':'#3ddc97'))},
  key(k){({ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0],KeyW:[0,-1],KeyS:[0,1],KeyA:[-1,0],KeyD:[1,0]})[k]&&this.turn(...({ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0],KeyW:[0,-1],KeyS:[0,1],KeyA:[-1,0],KeyD:[1,0]})[k])},
  down(p){this.sp=p},
  up(p){if(!this.sp)return;const dx=p.x-this.sp.x,dy=p.y-this.sp.y;if(Math.max(Math.abs(dx),Math.abs(dy))<12)return;
    Math.abs(dx)>Math.abs(dy)?this.turn(Math.sign(dx),0):this.turn(0,Math.sign(dy));this.sp=null},
  art(c){c.fillStyle='#3ddc97';[[2,5],[3,5],[4,5],[4,4],[4,3],[5,3],[6,3]].forEach(([x,y])=>c.fillRect(x*10,y*10,9,9));c.fillStyle='#ffb627';c.fillRect(90,30,9,9)}
};

/* ---------- Brick Bash (breakout) ---------- */
const brick={id:'brick',name:'BRICK BASH',c:'--a3',desc:'Bounce the ball and clear every brick.',
  how:'Drag anywhere to move the paddle.',
  init(){this.px=W/2;this.lives=3;this.level=1;this.build();this.serve();setScore(0)},
  build(){this.b=[];const cols=['#ff5d8f','#ffb627','#3ddc97','#5ab0ff','#c58bff','#f29a2e'];
    for(let r=0;r<5+this.level;r++)for(let c=0;c<7;c++)this.b.push({x:12+c*48,y:60+r*20,c:cols[r%6]})},
  serve(){this.bx=W/2;this.by=H-90;const sp=4+this.level*.4;this.vx=sp*.6*(Math.random()<.5?-1:1);this.vy=-sp},
  update(){this.bx+=this.vx;this.by+=this.vy;
    if(this.bx<6||this.bx>W-6)this.vx*=-1;if(this.by<6)this.vy=Math.abs(this.vy);
    if(this.by>H-50&&this.by<H-38&&Math.abs(this.bx-this.px)<38&&this.vy>0){this.vy*=-1;this.vx=(this.bx-this.px)/6}
    if(this.by>H){if(--this.lives<=0)return over();this.serve()}
    for(const k of this.b)if(!k.dead&&this.bx>k.x&&this.bx<k.x+44&&this.by>k.y&&this.by<k.y+16){k.dead=1;this.vy*=-1;setScore(score+10);break}
    if(this.b.every(k=>k.dead)){this.level++;this.build();this.serve()}},
  draw(){R(0,0,W,H,'#0c0a14');this.b.forEach(k=>!k.dead&&R(k.x,k.y,44,16,k.c));
    R(this.px-36,H-46,72,10,'#f1eefa');R(this.bx-6,this.by-6,12,12,'#ffb627');
    txt('♥'.repeat(this.lives),40,30,'#ff5d8f',10);txt('LV '+this.level,W-40,30,'#9a93b5',10)},
  down(p){this.px=p.x},move(p){this.px=Math.max(36,Math.min(W-36,p.x))},
  key(k){},hold(keys){if(keys.ArrowLeft||keys.KeyA)this.px=Math.max(36,this.px-7);if(keys.ArrowRight||keys.KeyD)this.px=Math.min(W-36,this.px+7)},
  art(c){const cs=['#ff5d8f','#ffb627','#3ddc97'];for(let r=0;r<3;r++)for(let x=0;x<5;x++)c.fillStyle=cs[r],c.fillRect(6+x*24,8+r*12,21,9);c.fillStyle='#f1eefa';c.fillRect(46,78,36,6);c.fillStyle='#ffb627';c.fillRect(70,58,7,7)}
};

/* ---------- Sky Hop (flappy-style) ---------- */
const hop={id:'hop',name:'SKY HOP',c:'--a4',desc:'Flap a paper kite through the tower gaps.',
  how:'Tap or press Space to flap.',
  init(){this.y=H/2;this.v=0;this.p=[];this.t=0;setScore(0)},
  flap(){this.v=-6.4},
  update(){this.v+=.36;this.y+=this.v;if(++this.t%90===0)this.p.push({x:W,gy:90+Math.random()*(H-260),ok:0});
    for(const p of this.p){p.x-=2.4;if(!p.ok&&p.x<80){p.ok=1;setScore(score+1)}
      if(p.x<104&&p.x+52>76&&(this.y-12<p.gy||this.y+12>p.gy+150))return over()}
    this.p=this.p.filter(p=>p.x>-60);if(this.y>H-10||this.y<0)over()},
  draw(){R(0,0,W,H,'#0f1530');for(let i=0;i<30;i++)R((i*53+this.t*.3)%W,(i*97)%H,2,2,'#ffffff30');
    this.p.forEach(p=>{R(p.x,0,52,p.gy,'#5ab0ff');R(p.x,p.gy+150,52,H,'#5ab0ff');R(p.x-4,p.gy-12,60,12,'#3d8fe0');R(p.x-4,p.gy+150,60,12,'#3d8fe0')});
    g.save();g.translate(90,this.y);g.rotate(Math.min(.8,this.v/10));g.fillStyle='#ffb627';g.beginPath();g.moveTo(-14,0);g.lineTo(0,-12);g.lineTo(14,0);g.lineTo(0,12);g.fill();g.fillStyle='#ff5d8f';g.fillRect(-20,-2,8,4);g.restore()},
  down(){this.flap()},key(k){if(k==='Space'||k==='ArrowUp')this.flap()},
  art(c){c.fillStyle='#5ab0ff';c.fillRect(80,0,22,30);c.fillRect(80,62,22,40);c.fillStyle='#ffb627';c.beginPath();c.moveTo(30,46);c.lineTo(42,36);c.lineTo(54,46);c.lineTo(42,56);c.fill()}
};

/* ---------- Pair Up (memory) with five difficulty modes ---------- */
const PAIR_MODES=[
  {k:'EASY',pairs:6,cols:4,back:1100,mult:.5,time:0,note:'6 pairs · slow flip-back'},
  {k:'NORMAL',pairs:8,cols:4,back:750,mult:1,time:0,note:'8 pairs · the classic'},
  {k:'HARD',pairs:10,cols:5,back:550,mult:1.6,time:0,note:'10 pairs · quick flip-back'},
  {k:'INSANE',pairs:15,cols:5,back:450,mult:2.5,time:100,note:'15 pairs · 100 second clock'},
  {k:'NIGHTMARE',pairs:18,cols:6,back:350,mult:4,time:120,note:'18 pairs · 120 seconds · hidden cards reshuffle every 3 misses'}];
const PAIR_COL={EASY:'var(--a2)',NORMAL:'var(--a4)',HARD:'var(--a1)',INSANE:'var(--a3)',NIGHTMARE:'var(--a5)'};
const pair={id:'pair',name:'PAIR UP',c:'--a5',desc:'Flip cards to find matching pairs. Five modes from Easy to Nightmare.',how:'Pick a mode, then flip two cards at a time. Fewer flips and harder modes score more.',dom:true,
  icons:['🍉','🚀','🐙','🎲','🌵','⚡','🍩','🦊','🎸','🐢','🍄','🌙','🔥','🦄','🍒','🐝','🎯','🧊'],
  init(){this.stop();setScore(0);$('title').textContent='PAIR UP';const d=$('dom');d.innerHTML='<div class="status">CHOOSE A MODE</div><div class="pmodes"></div>';const w=d.querySelector('.pmodes');
    PAIR_MODES.forEach(m=>{const b=document.createElement('button');b.className='pmode';b.style.setProperty('--c',PAIR_COL[m.k]);b.innerHTML=`<b>${m.k}</b><span>${m.note}</span>`;b.onclick=()=>this.begin(m);w.appendChild(b)})},
  begin(m){this.m=m;const ic=this.icons.slice(0,m.pairs);this.deck=[...ic,...ic].sort(()=>Math.random()-.5).map(i=>({i}));this.open=[];this.flips=0;this.miss=0;this.found=0;this.lock=false;this.left=m.time;this.render();
    $('title').textContent='PAIR UP · '+m.k;if(m.time)this.tick=setInterval(()=>{if(cur!==this){this.stop();return}this.left--;this.stat();if(this.left<=0){this.stop();this.lock=true;setScore(0);over('TIME UP')}},1000)},
  stop(){if(this.tick){clearInterval(this.tick);this.tick=null}},leave(){this.stop()},
  stat(){const e=$('ps');if(e)e.textContent=this.m.k+' · FLIPS '+this.flips+(this.m.time?' · ⏱ '+this.left+'s':'')},
  render(){const d=$('dom');d.innerHTML='<div class="status" id="ps"></div><div class="cards"></div>';const w=d.querySelector('.cards');w.style.gridTemplateColumns=`repeat(${this.m.cols},1fr)`;
    if(this.m.cols>4)w.style.fontSize='0';this.deck.forEach((c,k)=>{const b=document.createElement('button');b.className='card'+(this.m.cols>4?' sm':'');b.id='card'+k;b.setAttribute('aria-label','Card '+(k+1));b.onclick=()=>this.flip(k,b);c.el=b;w.appendChild(b)});this.stat()},
  flip(k,b){const c=this.deck[k];if(this.lock||c.up||c.done)return;c.up=1;b.classList.add('up');b.textContent=c.i;this.open.push(c);beep(500,.03);
    if(this.open.length===2){this.flips++;this.stat();const[a,z]=this.open;this.open=[];
      if(a.i===z.i){a.done=z.done=1;a.el.classList.add('done');z.el.classList.add('done');beep(880,.08,'triangle');
        if(++this.found===this.m.pairs){this.stop();const extra=Math.max(0,this.flips-this.m.pairs);setScore(Math.max(10,Math.round((this.m.pairs*20-extra*4)*this.m.mult+this.left*2)));setTimeout(()=>over(this.m.k+' CLEARED!'),500)}}
      else{this.lock=true;this.miss++;setTimeout(()=>{[a,z].forEach(c=>{c.up=0;c.el.classList.remove('up');c.el.textContent=''});this.lock=false;
        if(this.m.k==='NIGHTMARE'&&this.miss%3===0)this.shuffle()},this.m.back)}}},
  shuffle(){const hid=this.deck.filter(c=>!c.done&&!c.up),vals=hid.map(c=>c.i).sort(()=>Math.random()-.5);hid.forEach((c,j)=>{c.i=vals[j];c.el.classList.add('shake')});
    setTimeout(()=>hid.forEach(c=>c.el.classList.remove('shake')),450);const e=$('ps');if(e)e.textContent='☠ CARDS RESHUFFLED!';beep(110,.3,'sawtooth');setTimeout(()=>this.stat(),900)},
  art(c){const cs=['#2a2442','#1b3a30','#2a2442','#2a2442'];for(let i=0;i<4;i++){c.fillStyle=cs[i];c.fillRect(8+i*30,26,26,40)}c.font='18px sans-serif';c.fillText('🐙',40,52)}
};

/* ---------- Three in a Row (tic-tac-toe vs CPU) ---------- */
const ttt={id:'ttt',name:'THREE IN A ROW',c:'--a1',desc:'Beat the CPU at noughts and crosses.',how:'You are X. Score counts your wins.',dom:true,
  init(){this.wins=0;this.ties=0;setScore(0);this.round()},
  round(){this.b=Array(9).fill('');this.done=false;const d=$('dom');d.innerHTML='<div class="status" id="ts">YOUR MOVE</div><div class="ttt"></div><div class="status" id="tw"></div>';
    const w=d.querySelector('.ttt');for(let i=0;i<9;i++){const c=document.createElement('button');c.className='cell';c.id='cell'+i;c.setAttribute('aria-label','Square '+(i+1));c.onclick=()=>this.play(i);w.appendChild(c)}this.tally()},
  tally(){$('tw').textContent='WINS '+this.wins+'  TIES '+this.ties},
  L:[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]],
  win(b,p){return this.L.some(l=>l.every(i=>b[i]===p))},
  set(i,p){this.b[i]=p;const c=$('cell'+i);c.textContent=p;c.classList.add(p.toLowerCase())},
  play(i){if(this.done||this.b[i])return;this.set(i,'X');if(this.end())return;
    const m=this.ai();this.set(m,'O');this.end()},
  ai(){const e=this.b.map((v,i)=>v?-1:i).filter(i=>i>=0);
    for(const p of['O','X'])for(const i of e){const t=[...this.b];t[i]=p;if(this.win(t,p))return i}
    if(Math.random()<.25)return e[Math.random()*e.length|0];
    if(e.includes(4))return 4;const cs=[0,2,6,8].filter(i=>e.includes(i));return cs.length?cs[Math.random()*cs.length|0]:e[0]},
  end(){let r=null;if(this.win(this.b,'X'))r='YOU WIN!';else if(this.win(this.b,'O'))r='CPU WINS';else if(this.b.every(v=>v))r='TIE GAME';
    if(!r)return false;this.done=true;$('ts').textContent=r+' — TAP TO REPLAY';
    if(r==='YOU WIN!'){this.wins++;setScore(this.wins);lbPost('ttt',this.wins);if(this.wins>store.get('ttt')){store.set('ttt',this.wins);$('best-ttt').textContent='BEST '+this.wins}}else if(r==='TIE GAME')this.ties++;this.tally();
    if(r==='CPU WINS'){setTimeout(over,700)}else setTimeout(()=>{$('dom').onclick=()=>{$('dom').onclick=null;this.round()}},50);return true},
  art(c){c.strokeStyle='#2f2948';c.lineWidth=3;[44,84].forEach(v=>{c.beginPath();c.moveTo(v,10);c.lineTo(v,90);c.moveTo(10,v-14+4);c.stroke()});
    c.font='bold 22px monospace';c.fillStyle='#5ab0ff';c.fillText('X',18,40);c.fillText('X',56,64);c.fillStyle='#ff5d8f';c.fillText('O',92,40)}
};
let room=null;
(async()=>{try{room=window.claude&&window.claude.use?await window.claude.use("room"):null}catch(e){room=null}})();
function lights(s){s.add(new THREE.HemisphereLight(0xffffff,0x332244,1.0));const d=new THREE.DirectionalLight(0xffffff,.7);d.position.set(4,10,6);s.add(d)}

/* ---------- Lane Dash 3D (single player) ---------- */
const dash={id:'dash',name:'LANE DASH 3D',c:'--a4',three:true,tag:'3D',desc:'Race down a neon track, switch lanes and jump the low walls.',
  how:'Swipe left or right to switch lanes. Tap or swipe up to jump. Pink walls are too tall to jump. Arrows and Space work too.',
  init(){const s=this.s=new THREE.Scene();s.background=new THREE.Color(0x12101c);s.fog=new THREE.Fog(0x12101c,20,70);
    this.cam=new THREE.PerspectiveCamera(62,.66,.1,200);this.cam.position.set(0,4.6,7.5);this.cam.lookAt(0,1,-6);lights(s);
    const fl=new THREE.Mesh(new THREE.PlaneGeometry(9.4,400),lam(0x1e1a2e));fl.rotation.x=-Math.PI/2;fl.position.z=-150;s.add(fl);
    this.lines=[];const lm=new THREE.MeshBasicMaterial({color:0x5ab0ff});
    for(let i=0;i<40;i++)for(const x of[-1.5,1.5,-4.6,4.6]){const m=new THREE.Mesh(new THREE.BoxGeometry(.1,.03,2),lm);m.position.set(x,.02,-i*5);s.add(m);this.lines.push(m)}
    this.p=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),lam(0xffb627,0x3a2400));this.p.position.set(0,.5,0);s.add(this.p);
    this.lane=0;this.vy=0;this.obs=[];this.coins=[];this.spd=.25;this.t=0;this.dist=0;this.bonus=0;setScore(0)},
  spawn(){const lane=(Math.random()*3|0)-1,tall=Math.random()<.35;
    const m=new THREE.Mesh(new THREE.BoxGeometry(2.6,tall?2.6:1,1),lam(tall?0xff5d8f:0xc58bff));m.position.set(lane*3,tall?1.3:.5,-70);m.userData={tall};this.s.add(m);this.obs.push(m);
    const cl=(Math.random()*3|0)-1;if(cl!==lane){const c=new THREE.Mesh(new THREE.OctahedronGeometry(.38),lam(0x3ddc97,0x0c4a32));c.position.set(cl*3,.9,-70);this.s.add(c);this.coins.push(c)}},
  left(){this.lane=Math.max(-1,this.lane-1)},right(){this.lane=Math.min(1,this.lane+1)},
  jump(){if(this.p.position.y<=.501)this.vy=.25},
  update(){this.t++;this.spd=Math.min(.7,.25+this.t*.00009);const p=this.p.position;
    p.x+=(this.lane*3-p.x)*.25;this.vy-=.02;p.y+=this.vy;if(p.y<.5){p.y=.5;this.vy=0}
    this.p.rotation.x-=this.spd*.5;
    if(this.t%Math.max(24,Math.round(16/this.spd))===0)this.spawn();
    for(const o of this.obs){o.position.z+=this.spd;
      if(Math.abs(o.position.z)<1&&Math.abs(o.position.x-p.x)<1.8&&(o.userData.tall||p.y-.5<1))return over()}
    this.obs=this.obs.filter(o=>{if(o.position.z>9){this.s.remove(o);return false}return true});
    this.coins=this.coins.filter(c=>{c.position.z+=this.spd;c.rotation.y+=.08;
      if(Math.abs(c.position.z)<1&&Math.abs(c.position.x-p.x)<1.2&&Math.abs(c.position.y-p.y)<1.2){this.bonus+=25;this.s.remove(c);return false}
      if(c.position.z>9){this.s.remove(c);return false}return true});
    for(const l of this.lines){l.position.z+=this.spd;if(l.position.z>6)l.position.z-=200}
    this.dist+=this.spd;const sc=Math.floor(this.dist)+this.bonus;if(sc!==score)setScore(sc)},
  draw(){R3.render(this.s,this.cam)},
  key(k){if(k==='ArrowLeft'||k==='KeyA')this.left();if(k==='ArrowRight'||k==='KeyD')this.right();if(k==='Space'||k==='ArrowUp'||k==='KeyW')this.jump()},
  down(p){this.sp=p},
  up(p){if(!this.sp)return;const dx=p.x-this.sp.x,dy=p.y-this.sp.y;this.sp=null;
    if(Math.max(Math.abs(dx),Math.abs(dy))<14)return this.jump();
    if(Math.abs(dx)>Math.abs(dy))dx<0?this.left():this.right();else if(dy<0)this.jump()},
  art(c){c.fillStyle='#1e1a2e';c.beginPath();c.moveTo(50,10);c.lineTo(78,10);c.lineTo(124,96);c.lineTo(4,96);c.fill();
    c.fillStyle='#5ab0ff';c.fillRect(42,40,3,56);c.fillRect(84,40,3,56);c.fillStyle='#ff5d8f';c.fillRect(56,22,16,18);c.fillStyle='#ffb627';c.fillRect(54,66,20,20)}
};

/* ---------- Gem Rush Co-op 3D (online) ---------- */
const PAL=[0xffb627,0x3ddc97,0x5ab0ff,0xc58bff,0xff8a3d,0x4fd1c5];
const frac=v=>v-Math.floor(v);
const gemAt=k=>({x:(frac(Math.sin(k*12.9898+1)*43758.5453)-.5)*24,z:(frac(Math.sin(k*78.233+3)*12345.678)-.5)*24});
const rush={id:'rush',name:'GEM RUSH CO-OP',c:'--a2',three:true,tag:'3D · ONLINE CO-OP',desc:'Team up live with friends to grab gems while dodging roaming hazards.',
  how:'Drag anywhere to steer, or use WASD. Everyone with this page open in the arena plays together and shares the team gem count.',
  init(){const s=this.s=new THREE.Scene();s.background=new THREE.Color(0x0f1324);s.fog=new THREE.Fog(0x0f1324,25,60);lights(s);
    this.cam=new THREE.PerspectiveCamera(55,.66,.1,200);
    const fl=new THREE.Mesh(new THREE.BoxGeometry(31,.5,31),lam(0x1e1a2e));fl.position.y=-.25;s.add(fl);
    const gh=new THREE.GridHelper(31,31,0x3a3360,0x2a2448);gh.position.y=.01;s.add(gh);
    const wm=lam(0x2f2948);[[0,15.5,31,1],[0,-15.5,31,1],[15.5,0,1,31],[-15.5,0,1,31]].forEach(([x,z,w,d])=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,1,d),wm);m.position.set(x,.5,z);s.add(m)});
    this.col=PAL[Math.random()*PAL.length|0];
    this.me=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),lam(this.col));this.me.position.set((Math.random()-.5)*4,.5,(Math.random()-.5)*4);s.add(this.me);
    const ring=new THREE.Mesh(new THREE.RingGeometry(.8,1,24),new THREE.MeshBasicMaterial({color:0xffffff,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.03;this.ring=ring;s.add(ring);
    this.gem=new THREE.Mesh(new THREE.OctahedronGeometry(.6),lam(0x3ddc97,0x0f6b48));s.add(this.gem);
    this.hz=[];for(let i=0;i<7;i++){const h=new THREE.Mesh(new THREE.SphereGeometry(.8,16,12),lam(0xff5d8f,0x5a0f26));s.add(h);this.hz.push(h)}
    this.others=new Map();this.k=this.teamK();this.mine=0;this.stun=0;this.f=0;this.drag=null;this.online=-1;setScore(this.k)},
  live(){return room?room.peers().filter(p=>!p.sameTab&&p.presence&&p.presence.g==='rush'):[]},
  teamK(){let k=this.k||0;for(const p of this.live()){const v=+p.presence.k;if(Number.isFinite(v)&&v>k&&v<1e6)k=Math.floor(v)}return k},
  update(){this.f++;const m=this.me.position;
    let vx=0,vz=0;if(keys.KeyA||keys.ArrowLeft)vx=-1;if(keys.KeyD||keys.ArrowRight)vx=1;if(keys.KeyW||keys.ArrowUp)vz=-1;if(keys.KeyS||keys.ArrowDown)vz=1;
    if(this.drag){const dx=this.drag.x-this.drag.sx,dy=this.drag.y-this.drag.sy,d=Math.hypot(dx,dy);if(d>6){vx=dx/Math.max(d,40);vz=dy/Math.max(d,40)}}
    const len=Math.hypot(vx,vz);if(len>1){vx/=len;vz/=len}
    if(this.stun>0){this.stun--;this.me.rotation.y+=.3}else{m.x=Math.max(-14.5,Math.min(14.5,m.x+vx*.2));m.z=Math.max(-14.5,Math.min(14.5,m.z+vz*.2));if(len)this.me.rotation.y=Math.atan2(vx,vz)}
    this.k=this.teamK();const g=gemAt(this.k);this.gem.position.set(g.x,.9+Math.sin(this.f*.08)*.2,g.z);this.gem.rotation.y+=.05;
    if(Math.hypot(m.x-g.x,m.z-g.z)<1.3){this.k++;this.mine++}
    if(this.k!==score){setScore(this.k);lbPost('rush',this.k);if(this.k>store.get('rush'))store.set('rush',this.k)}
    const t=Date.now()/1000,n=Math.min(7,3+Math.floor(this.k/5));
    this.hz.forEach((h,i)=>{h.visible=i<n;h.position.set(12*Math.sin(t*(.35+.06*i)+i*1.7),.8,12*Math.cos(t*(.27+.05*i)+i*2.3));
      if(h.visible&&this.stun===0&&Math.hypot(h.position.x-m.x,h.position.z-m.z)<1.4){this.stun=70;m.x*=.4;m.z*=.4}});
    this.ring.position.x=m.x;this.ring.position.z=m.z;
    // others
    const live=this.live(),seen=new Set();
    for(const p of live){const pr=p.presence;const x=+pr.x,z=+pr.z;if(!Number.isFinite(x)||!Number.isFinite(z))continue;seen.add(p.peer);
      let o=this.others.get(p.peer);if(!o){o=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),lam(PAL.includes(+pr.c)?+pr.c:0xffffff));o.position.set(x,.5,z);this.s.add(o);this.others.set(p.peer,o)}
      o.position.x+=(Math.max(-15,Math.min(15,x))-o.position.x)*.3;o.position.z+=(Math.max(-15,Math.min(15,z))-o.position.z)*.3;o.position.y=.5}
    for(const[k,o]of this.others)if(!seen.has(k)){this.s.remove(o);this.others.delete(k)}
    if(live.length!==this.online){this.online=live.length;$('title').textContent=room?(live.length?'CO-OP · '+(live.length+1)+' PLAYING':'CO-OP · WAITING FOR FRIENDS'):'GEM RUSH · SOLO'}
    if(room&&this.f%3===0)room.presence({g:'rush',x:+m.x.toFixed(2),z:+m.z.toFixed(2),c:this.col,k:this.k,mine:this.mine}).catch(()=>{});
    this.cam.position.set(m.x,15,m.z+11);this.cam.lookAt(m.x,0,m.z-1)},
  draw(){R3.render(this.s,this.cam)},
  down(p){this.drag={sx:p.x,sy:p.y,x:p.x,y:p.y}},move(p){if(this.drag){this.drag.x=p.x;this.drag.y=p.y}},up(){this.drag=null},key(){},
  leave(){if(room)room.presence({g:null}).catch(()=>{})},
  art(c){c.strokeStyle='#2f2948';for(let i=0;i<=8;i++){c.beginPath();c.moveTo(i*16,0);c.lineTo(i*16,96);c.moveTo(0,i*12);c.lineTo(128,i*12);c.stroke()}
    c.fillStyle='#ffb627';c.fillRect(30,50,14,14);c.fillStyle='#5ab0ff';c.fillRect(60,62,14,14);c.fillStyle='#3ddc97';c.beginPath();c.moveTo(96,22);c.lineTo(104,32);c.lineTo(96,42);c.lineTo(88,32);c.fill();
    c.fillStyle='#ff5d8f';c.beginPath();c.arc(90,72,8,0,7);c.fill()}
};
brick.hover=true;snake.cat='2ds';brick.cat='2ds';hop.cat='2ds';pair.cat='2ds';ttt.cat='2ds';dash.cat='3ds';rush.cat='3dc';
const OLD=[snake,brick,hop,pair,ttt,dash,rush];
