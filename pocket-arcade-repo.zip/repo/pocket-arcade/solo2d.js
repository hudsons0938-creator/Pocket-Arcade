/* 2D SOLO — part 1 */

/* Puff Glide */
add({id:'puff',name:'PUFF GLIDE',cat:'2ds',c:'--a1',desc:'Flap a puffball through gaps in the pipes.',how:'Tap (or Space) to flap. Each pipe you pass is a point.',
  init(){this.y=H/2;this.vy=0;this.p=[];this.t=0;setScore(0)},
  flap(){this.vy=-6.4;beep(620,.05)},
  update(){this.t++;this.vy+=.35;this.y+=this.vy;
    if(this.t%92===30)this.p.push({x:W+30,gp:rnd(130,H-150),s:0});
    for(const p of this.p){p.x-=2.4+Math.min(1.4,score*.04);
      if(!p.s&&p.x+56<80-12){p.s=1;setScore(score+1);beep(880,.04)}
      if(Math.abs(p.x+28-80)<28+11&&(this.y-11<p.gp-74||this.y+11>p.gp+74))return over()}
    this.p=this.p.filter(p=>p.x>-70);if(this.y>H-24||this.y<-20)over()},
  draw(){bg('#151230');for(let i=0;i<6;i++)C((i*97+40-this.t*.3)%(W+80)-40+40,H-40,60,'#1e1a3e');R(0,H-24,W,24,'#2f2948');
    for(const p of this.p){R(p.x,0,56,p.gp-74,'#3ddc97');R(p.x,p.gp+74,56,H-24-p.gp-74,'#3ddc97');R(p.x-4,p.gp-90,64,16,'#2fb57c');R(p.x-4,p.gp+74,64,16,'#2fb57c')}
    C(80,this.y,13,'#ffb627');C(85,this.y-4,4,'#fff');C(86,this.y-4,2,'#111');R(70,this.y+2+(this.vy<0?-6:0),10,5,'#f29a2e')},
  down(){this.flap()},key(k){if(k==='Space'||k==='ArrowUp')this.flap()},
  art(c){c.fillStyle='#3ddc97';c.fillRect(80,0,22,30);c.fillRect(80,62,22,34);c.fillStyle='#ffb627';c.beginPath();c.arc(40,48,11,0,7);c.fill()}});

/* Star Swarm */
add({id:'swarm',name:'STAR SWARM',c:'--a4',cat:'2ds',desc:'Blast waves of alien diamonds before they reach you.',how:'Drag to fly. Your ship fires on its own. Big ships take three hits.',
  init(){this.x=W/2;this.y=H-80;this.tx=this.x;this.ty=this.y;this.b=[];this.f=[];this.t=0;this.lives=3;this.inv=0;this.st=Array.from({length:40},()=>[rnd(0,W),rnd(0,H),rnd(.5,2)]);setScore(0)},
  update(){this.t++;if(keys.ArrowLeft||keys.KeyA)this.tx-=5;if(keys.ArrowRight||keys.KeyD)this.tx+=5;if(keys.ArrowUp||keys.KeyW)this.ty-=5;if(keys.ArrowDown||keys.KeyS)this.ty+=5;
    this.tx=clamp(this.tx,16,W-16);this.ty=clamp(this.ty,H*.45,H-24);this.x+=(this.tx-this.x)*.3;this.y+=(this.ty-this.y)*.3;
    if(this.t%9===0){this.b.push({x:this.x-7,y:this.y-14},{x:this.x+7,y:this.y-14})}
    if(this.t%Math.max(14,46-(this.t/180|0))===0){const big=Math.random()<.18;this.f.push({x:rnd(24,W-24),y:-20,vy:rnd(1.1,2)+this.t/4000,hp:big?3:1,r:big?20:12,ph:rnd(0,6)})}
    for(const s of this.st){s[1]+=s[2];if(s[1]>H)s[1]=0}
    for(const b of this.b)b.y-=9;
    for(const f of this.f){f.y+=f.vy;f.x+=Math.sin(this.t/30+f.ph)*1.2;
      for(const b of this.b)if(!b.d&&hyp(b.x-f.x,b.y-f.y)<f.r+3){b.d=1;f.hp--;if(f.hp<=0){f.dead=1;setScore(score+(f.r>15?5:1));beep(300,.05,'square',.03)}}
      if(!f.dead&&this.inv<=0&&hyp(f.x-this.x,f.y-this.y)<f.r+12){f.dead=1;this.lives--;this.inv=90;beep(120,.2,'sawtooth');if(this.lives<=0)return over()}}
    if(this.inv>0)this.inv--;this.b=this.b.filter(b=>!b.d&&b.y>-10);this.f=this.f.filter(f=>!f.dead&&f.y<H+30)},
  draw(){bg('#08070f');for(const s of this.st)R(s[0],s[1],s[2],s[2],'#9a93b5');
    for(const b of this.b)R(b.x-1.5,b.y-6,3,10,'#ffb627');
    for(const f of this.f){g.fillStyle=f.hp>1?'#c58bff':'#ff5d8f';g.beginPath();g.moveTo(f.x,f.y-f.r);g.lineTo(f.x+f.r,f.y);g.lineTo(f.x,f.y+f.r);g.lineTo(f.x-f.r,f.y);g.fill()}
    if(!(this.inv>0&&this.t%8<4)){g.fillStyle='#5ab0ff';g.beginPath();g.moveTo(this.x,this.y-16);g.lineTo(this.x+14,this.y+12);g.lineTo(this.x-14,this.y+12);g.fill();R(this.x-3,this.y+12,6,4+this.t%4,'#ffb627')}
    T('♥'.repeat(Math.max(0,this.lives)),12,24,'#ff5d8f',12,'left')},
  down(p){this.ox=p.x-this.tx;this.oy=p.y-this.ty},move(p){this.tx=p.x-this.ox;this.ty=p.y-this.oy},
  art(c){c.fillStyle='#5ab0ff';c.beginPath();c.moveTo(64,62);c.lineTo(78,88);c.lineTo(50,88);c.fill();c.fillStyle='#ff5d8f';[[30,20],[90,30]].forEach(([x,y])=>{c.beginPath();c.moveTo(x,y-10);c.lineTo(x+10,y);c.lineTo(x,y+10);c.lineTo(x-10,y);c.fill()});c.fillStyle='#ffb627';c.fillRect(63,40,3,10)}});

/* Stacker */
add({id:'stacker',name:'STACKER',c:'--a5',cat:'2ds',desc:'Drop sliding slabs to build the tallest tower you can.',how:'Tap to drop the moving slab. Overhang gets sliced off. Land it perfectly to keep its width.',
  init(){this.s=[{x:80,w:200}];this.m={x:0,w:200,d:1};this.sp=2.4;this.fall=[];this.off=0;setScore(0)},
  drop(){const t=this.s[this.s.length-1],m=this.m;let L=Math.max(m.x,t.x),Rr=Math.min(m.x+m.w,t.x+t.w);
    if(Rr<=L){this.fall.push({x:m.x,w:m.w,y:this.yOf(this.s.length),vy:0});return over()}
    if(Math.abs(m.x-t.x)<5){L=t.x;Rr=t.x+t.w;beep(990,.08,'triangle')}else{beep(440,.05);const cut=m.x<t.x?{x:m.x,w:t.x-m.x}:{x:t.x+t.w,w:m.x+m.w-t.x-t.w};cut.y=this.yOf(this.s.length);cut.vy=0;this.fall.push(cut)}
    this.s.push({x:L,w:Rr-L});setScore(this.s.length-1);this.sp=Math.min(6,this.sp+.12);const d=this.s.length%2?1:-1;this.m={x:d>0?-0:W-(Rr-L),w:Rr-L,d}},
  yOf(i){return H-70-i*24},
  update(){const m=this.m;m.x+=m.d*this.sp;if(m.x<0){m.x=0;m.d=1}if(m.x+m.w>W){m.x=W-m.w;m.d=-1}
    const want=Math.max(0,(this.s.length-12)*24);this.off+=(want-this.off)*.1;
    for(const f of this.fall){f.vy+=.5;f.y+=f.vy}this.fall=this.fall.filter(f=>f.y<H+200)},
  draw(){bg('#110f1f');g.save();g.translate(0,this.off);
    this.s.forEach((b,i)=>{R(b.x,this.yOf(i),b.w,22,`hsl(${(i*14)%360} 70% ${i?60:35}%)`)});
    if(running)R(this.m.x,this.yOf(this.s.length),this.m.w,22,`hsl(${(this.s.length*14)%360} 80% 65%)`);
    for(const f of this.fall)R(f.x,f.y,f.w,22,'#ffffff55');g.restore()},
  down(){this.drop()},key(k){if(k==='Space')this.drop()},
  art(c){for(let i=0;i<6;i++){c.fillStyle=`hsl(${i*14+250} 70% 60%)`;c.fillRect(34+i*3,80-i*12,60-i*4,10)}}});

/* Merge 2048 — tiles slide, merges and new tiles pop */
const M2C={2:'#3a3360',4:'#4a3f7a',8:'#f29a2e',16:'#ff8a3d',32:'#ff5d8f',64:'#e0436f',128:'#ffb627',256:'#ffd23f',512:'#3ddc97',1024:'#5ab0ff',2048:'#c58bff'};
add({id:'merge',name:'MERGE 2048',c:'--a6',cat:'2ds',desc:'Slide matching tiles together and chase the 2048 tile.',how:'Swipe (or arrow keys) to slide every tile. Matching numbers merge.',
  init(){this.b=Array(16).fill(0);this.pts=0;this.anim=null;this.dead=0;this.addT();this.addT();setScore(0)},
  addT(){const e=this.b.map((v,i)=>v?-1:i).filter(i=>i>=0);if(!e.length)return -1;const i=pick(e);this.b[i]=Math.random()<.9?2:4;return i},
  can(){for(let i=0;i<16;i++){if(!this.b[i])return true;if(i%4<3&&this.b[i]===this.b[i+1])return true;if(i<12&&this.b[i]===this.b[i+4])return true}return false},
  slide(dir){if(this.dead)return;if(this.anim&&this.anim.t<1)this.anim.t=1;let mv=false;const moves=[],merged=[];
    for(let i=0;i<4;i++){const idx=[0,1,2,3].map(j=>dir<2?i*4+(dir===0?j:3-j):(dir===2?j:3-j)*4+i);
      const v=idx.map(k=>({v:this.b[k],k})).filter(x=>x.v),o=[];
      for(let j=0;j<v.length;j++){const to=idx[o.length];
        if(v[j+1]&&v[j].v===v[j+1].v){moves.push({v:v[j].v,f:v[j].k,t:to},{v:v[j+1].v,f:v[j+1].k,t:to});merged.push(to);o.push(v[j].v*2);this.pts+=v[j].v*2;j++}
        else{moves.push({v:v[j].v,f:v[j].k,t:to});o.push(v[j].v)}}
      while(o.length<4)o.push(0);idx.forEach((k,j)=>{if(this.b[k]!==o[j])mv=true;this.b[k]=o[j]})}
    if(!mv)return;const sp=this.addT();this.anim={moves,merged,sp,t:0};setScore(this.pts);beep(merged.length?440:330,.04);if(!this.can())this.dead=1},
  update(){const a=this.anim;if(!a)return;a.t+=a.t<1?1/7:1/9;if(a.t>=1.9){this.anim=null;if(this.dead)over()}},
  pos(i){return[28+(i%4)*78,118+(i/4|0)*78]},
  tile(v,x,y,s=1){const w=70*s,o=(70-w)/2;R(x+o,y+o,w,w,M2C[v]||'#f1eefa');T(String(v),x+35,y+42,v<8?'#f1eefa':'#111',Math.round((v>999?11:v>99?14:18)*s))},
  draw(){bg('#14111f');R(20,110,320,320,'#2f2948');for(let i=0;i<16;i++){const[x,y]=this.pos(i);R(x,y,70,70,'#221d36')}
    const a=this.anim;
    if(a&&a.t<1){const e=1-Math.pow(1-a.t,3);for(const m of a.moves){const[fx,fy]=this.pos(m.f),[tx,ty]=this.pos(m.t);this.tile(m.v,fx+(tx-fx)*e,fy+(ty-fy)*e)}}
    else{const p=a?a.t-1:1;this.b.forEach((v,i)=>{if(!v)return;const[x,y]=this.pos(i);let s=1;
      if(a&&a.merged.includes(i))s=1+Math.sin(Math.min(1,p/.9)*Math.PI)*.16;if(a&&i===a.sp)s=Math.min(1,.2+p*1.6);this.tile(v,x,y,s)})}
    T('SWIPE TO MERGE',W/2,470,'#9a93b5',9)},
  down(p){this.sp=p},up(p){if(!this.sp)return;const dx=p.x-this.sp.x,dy=p.y-this.sp.y;this.sp=null;if(Math.max(Math.abs(dx),Math.abs(dy))<18)return;
    this.slide(Math.abs(dx)>Math.abs(dy)?(dx<0?0:1):(dy<0?2:3))},
  key(k){const m={ArrowLeft:0,ArrowRight:1,ArrowUp:2,ArrowDown:3,KeyA:0,KeyD:1,KeyW:2,KeyS:3}[k];if(m!==undefined)this.slide(m)},
  art(c){const v=[['#f29a2e','8'],['#ff5d8f','32'],['#3a3360','2'],['#ffb627','128']];v.forEach(([col,t],i)=>{c.fillStyle=col;c.fillRect(24+(i%2)*42,8+(i>>1)*42,38,38);c.fillStyle='#111';c.font='12px monospace';c.fillText(t,30+(i%2)*42,32+(i>>1)*42)})}});

/* Bop the Bots */
add({id:'bop',name:'BOP THE BOTS',c:'--a2',cat:'2ds',desc:'Bonk robots as they pop up. Leave the red ones alone.',how:'Tap green bots before they hide. Red bots cost you 3 points. 40 seconds on the clock.',
  init(){this.h=Array.from({length:9},(_,i)=>({x:70+(i%3)*110,y:180+(i/3|0)*120,u:0,t:0,bad:0,hit:0}));this.time=40*60;this.t=0;setScore(0)},
  update(){this.t++;this.time--;if(this.time<=0)return over('TIME UP');
    const rate=Math.max(16,44-(this.t/150|0));if(this.t%rate===0){const f=this.h.filter(h=>!h.u);if(f.length){const h=pick(f);h.u=1;h.t=Math.max(40,90-(this.t/60|0));h.bad=Math.random()<.22;h.hit=0}}
    for(const h of this.h)if(h.u){h.t--;if(h.t<=0)h.u=0}},
  draw(){bg('#16202a');T('TIME '+Math.ceil(this.time/60),W/2,60,'#ffb627',14);
    for(const h of this.h){g.fillStyle='#0b1016';g.beginPath();g.ellipse(h.x,h.y+30,42,14,0,0,7);g.fill();
      if(h.u){const k=h.hit?.5:1;R(h.x-26,h.y-22*k,52,50*k,h.bad?'#ff5d8f':'#3ddc97');R(h.x-16,h.y-12*k,10,10,'#111');R(h.x+6,h.y-12*k,10,10,'#111');if(h.bad)R(h.x-14,h.y+8,28,5,'#111');else R(h.x-4,h.y-36,8,14,'#9a93b5')}
      g.fillStyle='#16202a';g.fillRect(h.x-50,h.y+30,100,40)}},
  down(p){for(const h of this.h)if(h.u&&!h.hit&&Math.abs(p.x-h.x)<44&&p.y>h.y-50&&p.y<h.y+40){h.hit=1;h.t=8;if(h.bad){setScore(score-3);beep(120,.15,'sawtooth')}else{setScore(score+1);beep(700,.05)}return}},
  art(c){c.fillStyle='#3ddc97';c.fillRect(20,30,30,30);c.fillStyle='#ff5d8f';c.fillRect(78,40,30,30);c.fillStyle='#111';c.fillRect(26,38,6,6);c.fillRect(38,38,6,6);c.fillStyle='#0b1016';c.fillRect(8,60,112,10)}});

/* Slice Storm */
add({id:'slice',name:'SLICE STORM',c:'--a3',cat:'2ds',desc:'Swipe through flying fruit, but never touch a bomb.',how:'Swipe to slice. Let three fruit drop and it is over. Slicing a bomb ends the run.',
  init(){this.o=[];this.tr=[];this.pc=[];this.t=0;this.lives=3;setScore(0)},
  launch(){const n=ri(1,Math.min(4,1+(this.t/900|0)));for(let i=0;i<n;i++){const bomb=Math.random()<.16;this.o.push({x:rnd(50,W-50),y:H+20,vx:rnd(-1.6,1.6),vy:-rnd(11,13.5),r:bomb?16:rnd(16,22),c:bomb?'#111':pick(['#ff5d8f','#ffb627','#3ddc97','#c58bff','#f29a2e']),bomb})}},
  update(){this.t++;if(this.t%Math.max(38,70-(this.t/200|0))===1)this.launch();
    for(const o of this.o){o.vy+=.2;o.x+=o.vx;o.y+=o.vy}
    for(const o of this.o)if(!o.cut&&o.vy>0&&o.y>H+30){o.gone=1;if(!o.bomb){this.lives--;beep(150,.1);if(this.lives<=0)return over()}}
    this.o=this.o.filter(o=>!o.cut&&!o.gone);for(const p of this.pc){p.vy+=.25;p.x+=p.vx;p.y+=p.vy;p.l--}this.pc=this.pc.filter(p=>p.l>0);
    for(const t of this.tr)t.l--;this.tr=this.tr.filter(t=>t.l>0)},
  draw(){bg('#1a1020');for(const o of this.o){C(o.x,o.y,o.r,o.c);if(o.bomb){C(o.x,o.y,o.r-3,'#2b2b2b');R(o.x-2,o.y-o.r-6,4,8,'#f29a2e');C(o.x,o.y-o.r-7,3,'#ffd23f')}else C(o.x-o.r*.35,o.y-o.r*.35,o.r*.25,'#ffffff55')}
    for(const p of this.pc)C(p.x,p.y,p.r,p.c);
    g.strokeStyle='#f1eefa';g.lineCap='round';for(let i=1;i<this.tr.length;i++){const a=this.tr[i-1],b=this.tr[i];if(b.l<1||a.s!==b.s)continue;g.lineWidth=b.l/2;g.beginPath();g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.stroke()}
    T('♥'.repeat(Math.max(0,this.lives)),12,26,'#ff5d8f',12,'left')},
  down(p){this.lp=p;this.sid=(this.sid||0)+1;this.tr.push({x:p.x,y:p.y,l:12,s:this.sid})},
  move(p){if(!this.lp)return;const a=this.lp;this.tr.push({x:p.x,y:p.y,l:12,s:this.sid});
    for(const o of this.o)if(!o.cut&&segDist(o.x,o.y,a.x,a.y,p.x,p.y)<o.r+4){if(o.bomb){this.lives=0;return over('BOOM!')}
      o.cut=1;setScore(score+1);beep(500+score%5*80,.05);for(let k=0;k<6;k++)this.pc.push({x:o.x,y:o.y,vx:rnd(-3,3),vy:rnd(-5,1),r:rnd(3,7),c:o.c,l:40})}
    this.lp=p},up(){this.lp=null},
  art(c){c.fillStyle='#ffb627';c.beginPath();c.arc(40,50,16,0,7);c.fill();c.fillStyle='#3ddc97';c.beginPath();c.arc(88,40,13,0,7);c.fill();c.strokeStyle='#fff';c.lineWidth=3;c.beginPath();c.moveTo(10,80);c.lineTo(118,14);c.stroke()}});

/* Cliff Runner */
add({id:'cliff',name:'CLIFF RUNNER',c:'--a6',cat:'2ds',desc:'Sprint across floating cliffs. Jump the gaps, double-jump to save yourself.',how:'Tap to jump, tap again in the air for a double jump.',
  init(){this.y=380;this.vy=0;this.j=0;this.pl=[{x:-20,w:520,y:400}];this.sp=4;this.d=0;this.t=0;setScore(0)},
  jump(){if(this.j<2){this.vy=this.j?-9:-10.5;this.j++;beep(this.j?520:700,.05)}},
  update(){this.t++;this.sp=Math.min(9,4+this.t/900);this.d+=this.sp;
    for(const p of this.pl)p.x-=this.sp;
    let l=this.pl[this.pl.length-1];while(l.x+l.w<W+200){const n={x:l.x+l.w+rnd(55,95)*(this.sp/4.5),w:rnd(90,230),y:clamp(l.y+rnd(-70,60),250,470)};this.pl.push(n);l=n}
    this.pl=this.pl.filter(p=>p.x+p.w>-40);
    const py=this.y;this.vy+=.6;this.y+=this.vy;
    for(const p of this.pl)if(this.vy>=0&&80+10>p.x&&80-10<p.x+p.w&&py<=p.y&&this.y>=p.y){this.y=p.y;this.vy=0;this.j=0}
    if(this.y>H+40)return over();const s=Math.floor(this.d/10);if(s!==score)setScore(s)},
  draw(){const sky=g.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#2a1745');sky.addColorStop(1,'#f29a2e55');g.fillStyle=sky;g.fillRect(0,0,W,H);
    for(let i=0;i<5;i++){const x=((i*120-this.d*.2)%(W+120)+W+120)%(W+120)-60;g.fillStyle='#3a2458';g.beginPath();g.moveTo(x-80,H);g.lineTo(x,H-180-i%2*60);g.lineTo(x+80,H);g.fill()}
    for(const p of this.pl){R(p.x,p.y,p.w,H-p.y,'#3a3360');R(p.x,p.y,p.w,8,'#3ddc97')}
    const leg=this.vy===0?Math.sin(this.t*.5)*5:3;R(70,this.y-26,20,18,'#ffb627');R(72+leg,this.y-8,5,8,'#f1eefa');R(83-leg,this.y-8,5,8,'#f1eefa');R(82,this.y-22,5,5,'#111')},
  down(){this.jump()},key(k){if(k==='Space'||k==='ArrowUp'||k==='KeyW')this.jump()},
  art(c){c.fillStyle='#3a3360';c.fillRect(0,60,50,36);c.fillRect(76,50,52,46);c.fillStyle='#3ddc97';c.fillRect(0,60,50,4);c.fillRect(76,50,52,4);c.fillStyle='#ffb627';c.fillRect(56,30,12,12)}});
