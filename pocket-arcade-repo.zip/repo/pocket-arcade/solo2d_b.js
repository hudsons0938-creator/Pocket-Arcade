/* 2D SOLO — part 2 */

/* Block Drop (falling blocks) */
const SHP={I:[[0,1],[1,1],[2,1],[3,1]],O:[[1,0],[2,0],[1,1],[2,1]],T:[[1,0],[0,1],[1,1],[2,1]],S:[[1,0],[2,0],[0,1],[1,1]],Z:[[0,0],[1,0],[1,1],[2,1]],J:[[0,0],[0,1],[1,1],[2,1]],L:[[2,0],[0,1],[1,1],[2,1]]};
const SHC={I:'#5ab0ff',O:'#ffb627',T:'#c58bff',S:'#3ddc97',Z:'#ff5d8f',J:'#4f7dff',L:'#f29a2e'};
add({id:'drop',name:'BLOCK DROP',c:'--a4',cat:'2ds',desc:'Fit falling shapes into full rows to clear them.',how:'Tap left or right side to move, tap the middle to rotate, swipe down to slam. Arrows, Up and Space on a keyboard.',
  init(){this.b=Array.from({length:18},()=>Array(10).fill(0));this.lines=0;this.t=0;this.next=pick(Object.keys(SHP));this.spawn();setScore(0)},
  spawn(){const k=this.next;this.next=pick(Object.keys(SHP));this.p={k,c:SHP[k].map(a=>a.slice()),x:3,y:0};if(!this.fits(this.p.c,3,0))over()},
  fits(c,x,y){return c.every(([a,b])=>{const X=a+x,Y=b+y;return X>=0&&X<10&&Y<18&&(Y<0||!this.b[Y][X])})},
  mv(dx){if(this.p&&this.fits(this.p.c,this.p.x+dx,this.p.y))this.p.x+=dx},
  rot(){const p=this.p;if(p.k==='O')return;const n=p.k==='I'?3:2;const c=p.c.map(([x,y])=>[n-y,x]);for(const k of[0,-1,1,-2,2])if(this.fits(c,p.x+k,p.y)){p.c=c;p.x+=k;beep(400,.03);return}},
  lock(){const p=this.p;for(const[a,b]of p.c)if(b+p.y>=0)this.b[b+p.y][a+p.x]=SHC[p.k];
    let n=0;this.b=this.b.filter(r=>{if(r.every(v=>v)){n++;return false}return true});while(this.b.length<18)this.b.unshift(Array(10).fill(0));
    if(n){this.lines+=n;setScore(score+[0,100,300,500,800][n]);beep(660+n*100,.12,'triangle')}else beep(200,.03);this.spawn()},
  slam(){while(this.fits(this.p.c,this.p.x,this.p.y+1))this.p.y++;this.lock()},
  update(){if(!this.p)return;this.t++;const sp=Math.max(5,38-(this.lines/5|0)*4);if(this.t%(keys.ArrowDown||keys.KeyS?3:sp)===0){if(this.fits(this.p.c,this.p.x,this.p.y+1))this.p.y++;else this.lock()}},
  draw(){bg('#0e0c18');const ox=50,oy=40,s=26;R(ox-3,oy-3,s*10+6,s*18+6,'#2f2948');R(ox,oy,s*10,s*18,'#0c0a14');
    this.b.forEach((r,y)=>r.forEach((v,x)=>{if(v)R(ox+x*s+1,oy+y*s+1,s-2,s-2,v)}));
    if(this.p){let gy=this.p.y;while(this.fits(this.p.c,this.p.x,gy+1))gy++;for(const[a,b]of this.p.c){R(ox+(a+this.p.x)*s+1,oy+(b+gy)*s+1,s-2,s-2,'#ffffff18');if(b+this.p.y>=0)R(ox+(a+this.p.x)*s+1,oy+(b+this.p.y)*s+1,s-2,s-2,SHC[this.p.k])}}
    T('LINES '+this.lines,W/2,28,'#9a93b5',9)},
  down(p){this.sp=p},up(p){if(!this.sp)return;const dx=p.x-this.sp.x,dy=p.y-this.sp.y;this.sp=null;
    if(dy>50&&dy>Math.abs(dx))return this.slam();if(Math.abs(dx)>30)return this.mv(Math.sign(dx));
    if(p.x<W*.33)this.mv(-1);else if(p.x>W*.67)this.mv(1);else this.rot()},
  key(k){if(k==='ArrowLeft'||k==='KeyA')this.mv(-1);if(k==='ArrowRight'||k==='KeyD')this.mv(1);if(k==='ArrowUp'||k==='KeyW')this.rot();if(k==='Space')this.slam()},
  art(c){const f=(x,y,col)=>{c.fillStyle=col;c.fillRect(x,y,15,15)};[[30,66],[46,66],[62,66],[46,50]].forEach(p=>f(...p,'#c58bff'));[[78,66],[94,66],[94,50],[94,34]].forEach(p=>f(...p,'#f29a2e'));[[54,10],[70,10],[54,26],[70,26]].forEach(p=>f(...p,'#ffb627'))}});

/* Mine Field */
add({id:'mines',name:'MINE FIELD',c:'--a2',cat:'2ds',desc:'Clear the field using number clues without hitting a mine.',how:'Tap to dig. Switch to FLAG mode (top button) to mark mines. Numbers count mines touching that square. Faster clears score more.',
  init(){this.cols=9;this.rows=12;this.n=18;this.c=Array.from({length:108},()=>({m:0,o:0,f:0,a:0}));this.placed=0;this.flag=0;this.t=0;this.done=0;setScore(0)},
  nb(i){const x=i%9,y=i/9|0,o=[];for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;const X=x+dx,Y=y+dy;if(X>=0&&X<9&&Y>=0&&Y<12)o.push(Y*9+X)}return o},
  place(safe){const ban=new Set([safe,...this.nb(safe)]);let k=0;while(k<this.n){const i=ri(0,107);if(!ban.has(i)&&!this.c[i].m){this.c[i].m=1;k++}}
    this.c.forEach((c,i)=>c.a=this.nb(i).filter(j=>this.c[j].m).length);this.placed=1},
  open(i){const st=[i];while(st.length){const j=st.pop(),c=this.c[j];if(c.o||c.f)continue;c.o=1;if(!c.a&&!c.m)st.push(...this.nb(j))}},
  update(){if(this.placed&&!this.done)this.t++},
  draw(){bg('#10161a');const s=36,ox=18,oy=80;
    R(18,18,150,40,this.flag?'#ff5d8f':'#2f2948');T(this.flag?'FLAG MODE':'DIG MODE',93,44,'#f1eefa',9);T('⏱ '+(this.t/60|0),300,44,'#ffb627',11);
    this.c.forEach((c,i)=>{const x=ox+(i%9)*s,y=oy+(i/9|0)*s;
      if(c.o){R(x+1,y+1,s-2,s-2,c.m?'#ff5d8f':'#22303a');if(c.m)C(x+s/2,y+s/2,8,'#111');else if(c.a)T(String(c.a),x+s/2,y+s/2+7,['','#5ab0ff','#3ddc97','#ff5d8f','#c58bff','#f29a2e','#ffb627','#fff','#fff'][c.a],14)}
      else{R(x+1,y+1,s-2,s-2,'#3a4a58');if(ADM.xray&&c.m&&this.placed)C(x+s/2,y+s/2,5,'#ff5d8f');if(c.f){R(x+15,y+8,3,20,'#f1eefa');g.fillStyle='#ff5d8f';g.beginPath();g.moveTo(x+18,y+8);g.lineTo(x+28,y+13);g.lineTo(x+18,y+18);g.fill()}}})},
  down(p){if(p.y<62&&p.x<170){this.flag^=1;beep(300,.03);return}
    const x=Math.floor((p.x-18)/36),y=Math.floor((p.y-80)/36);if(x<0||x>8||y<0||y>11)return;const i=y*9+x,c=this.c[i];
    if(this.flag){if(!c.o){c.f^=1;beep(500,.03)}return}if(c.f||c.o)return;
    if(!this.placed)this.place(i);
    if(c.m){this.c.forEach(k=>{if(k.m)k.o=1});setScore(0);return over('BOOM!')}
    this.open(i);beep(600,.03);
    if(this.c.filter(k=>k.o).length===108-this.n){this.done=1;setScore(Math.max(50,1000-(this.t/60|0)*5));over('FIELD CLEAR!')}},
  key(k){if(k==='KeyF')this.flag^=1},
  art(c){for(let i=0;i<12;i++){c.fillStyle=i%5===2?'#22303a':'#3a4a58';c.fillRect(16+(i%4)*25,10+(i/4|0)*26,23,24)}c.fillStyle='#3ddc97';c.font='14px monospace';c.fillText('2',75,30);c.fillStyle='#ff5d8f';c.fillRect(46,64,10,10)}});

/* Echo Lights */
add({id:'echo',name:'ECHO LIGHTS',c:'--a5',cat:'2ds',desc:'Watch the lights, then repeat the pattern. It grows every round.',how:'Watch which pads glow, then tap them back in the same order. Sound on helps.',
  pads:[['#3ddc97',330],['#ff5d8f',392],['#5ab0ff',494],['#ffb627',587]],
  init(){this.seq=[ri(0,3)];this.ph='show';this.si=0;this.tm=50;this.lit=-1;this.lt=0;this.ii=0;setScore(0)},
  update(){if(this.lt>0&&--this.lt===0)this.lit=-1;
    if(this.ph==='show'&&--this.tm<=0){if(this.si<this.seq.length){this.lit=this.seq[this.si];this.lt=22;beep(this.pads[this.lit][1],.25,'sine',.08);this.si++;this.tm=Math.max(18,34-this.seq.length)}else{this.ph='input';this.ii=0}}},
  draw(){bg('#120f1d');this.pads.forEach(([c],i)=>{const x=30+(i%2)*155,y=110+(i>>1)*155;R(x,y,145,145,c);if(this.lit!==i)R(x,y,145,145,'#000000aa')});
    T(this.ph==='show'?'WATCH...':'YOUR TURN',W/2,70,this.ph==='show'?'#9a93b5':'#ffb627',12);T('ROUND '+this.seq.length,W/2,470,'#9a93b5',10)},
  down(p){if(this.ph!=='input')return;const i=(p.x>W/2?1:0)+(p.y>265?2:0);if(p.y<110||p.y>420)return;
    this.lit=i;this.lt=12;beep(this.pads[i][1],.18,'sine',.08);
    if(i!==this.seq[this.ii])return over();this.ii++;if(this.ii===this.seq.length){setScore(this.seq.length);this.seq.push(ri(0,3));this.ph='show';this.si=0;this.tm=55}},
  art(c){['#3ddc97','#ff5d8f','#5ab0ff','#ffb627'].forEach((col,i)=>{c.fillStyle=col;c.globalAlpha=i===1?1:.35;c.fillRect(26+(i%2)*40,8+(i>>1)*40,36,36)});c.globalAlpha=1}});

/* Dodge Rain */
add({id:'dodge',name:'DODGE RAIN',c:'--a3',cat:'2ds',desc:'Slide left and right under a storm of falling blocks. Grab gold.',how:'Drag (or arrows) to move. Gold coins are worth 5. Score climbs while you survive.',
  init(){this.x=W/2;this.tx=W/2;this.o=[];this.t=0;this.bonus=0;setScore(0)},
  update(){this.t++;if(keys.ArrowLeft||keys.KeyA)this.tx-=6;if(keys.ArrowRight||keys.KeyD)this.tx+=6;this.tx=clamp(this.tx,20,W-20);this.x+=(this.tx-this.x)*.35;
    const r=Math.max(6,26-(this.t/240|0));if(this.t%r===0)this.o.push({x:rnd(10,W-10),y:-20,w:rnd(16,40),vy:rnd(3,4.5)+this.t/2400,gold:Math.random()<.08});
    for(const o of this.o){o.y+=o.vy;if(o.y+o.w/2>H-60&&o.y-o.w/2<H-36&&Math.abs(o.x-this.x)<o.w/2+18){if(o.gold){o.d=1;this.bonus+=5;beep(900,.05)}else return over()}}
    this.o=this.o.filter(o=>!o.d&&o.y<H+40);const s=(this.t/30|0)+this.bonus;if(s!==score)setScore(s)},
  draw(){bg('#0f1420');for(const o of this.o){if(o.gold){C(o.x,o.y,10,'#ffb627');C(o.x,o.y,5,'#f29a2e')}else R(o.x-o.w/2,o.y-o.w/2,o.w,o.w,'#ff5d8f')}
    R(0,H-36,W,36,'#1e1a2e');R(this.x-18,H-60,36,24,'#5ab0ff');R(this.x-10,H-54,6,6,'#111');R(this.x+4,H-54,6,6,'#111')},
  down(p){this.tx=p.x},move(p){this.tx=p.x},
  art(c){c.fillStyle='#ff5d8f';[[20,10,16],[70,30,22],[100,6,12]].forEach(([x,y,s])=>c.fillRect(x,y,s,s));c.fillStyle='#5ab0ff';c.fillRect(50,72,26,16);c.fillStyle='#ffb627';c.beginPath();c.arc(40,50,6,0,7);c.fill()}});

/* Mini Putt */
const HOLES=[
 {b:[180,470],h:[180,90],w:[[100,260,160,20]]},
 {b:[70,470],h:[290,90],w:[[0,300,240,20],[120,170,240,20]]},
 {b:[180,480],h:[180,80],w:[[60,200,20,200],[280,140,20,200],[140,280,80,20]]},
 {b:[60,80],h:[300,470],w:[[0,180,280,18],[80,330,280,18]]},
 {b:[180,480],h:[180,262],w:[[110,190,140,14],[110,190,14,140],[236,190,14,140],[110,316,50,14],[200,316,50,14]]},
 {b:[60,480],h:[300,70],w:[[60,380,120,16],[180,270,120,16],[60,160,120,16]]}];
add({id:'putt',name:'MINI PUTT',c:'--a2',cat:'2ds',desc:'Six tricky holes of pocket mini golf.',how:'Drag back from anywhere, like a slingshot, then let go to putt. Fewer strokes, more points.',
  init(){this.hole=0;this.tot=0;this.load();setScore(0)},
  load(){const L=HOLES[this.hole];this.bx=L.b[0];this.by=L.b[1];this.vx=0;this.vy=0;this.st=0;this.sink=0;this.walls=L.w.concat([[0,0,W,10],[0,H-10,W,10],[0,0,10,H],[W-10,0,10,H]])},
  update(){if(this.sink){if(--this.sink===0){const pts=Math.max(0,6-this.st)*10;setScore(score+pts);if(this.hole+1>=HOLES.length)return over('ROUND DONE');this.hole++;this.load()}return}
    const L=HOLES[this.hole];this.bx+=this.vx;this.by+=this.vy;this.vx*=.985;this.vy*=.985;if(hyp(this.vx,this.vy)<.06){this.vx=this.vy=0}
    for(const[x,y,w,h]of this.walls){const cx=clamp(this.bx,x,x+w),cy=clamp(this.by,y,y+h),dx=this.bx-cx,dy=this.by-cy,d=hyp(dx,dy);
      if(d<8&&d>0){const nx=dx/d,ny=dy/d;this.bx=cx+nx*8;this.by=cy+ny*8;const dot=this.vx*nx+this.vy*ny;if(dot<0){this.vx-=2*dot*nx;this.vy-=2*dot*ny;this.vx*=.8;this.vy*=.8;beep(250,.02)}}}
    const dh=hyp(this.bx-L.h[0],this.by-L.h[1]);if(dh<12&&hyp(this.vx,this.vy)<7){this.sink=40;this.bx=L.h[0];this.by=L.h[1];this.vx=this.vy=0;beep(880,.2,'triangle')}
    else if(dh<40&&hyp(this.vx,this.vy)>0){this.vx+=(L.h[0]-this.bx)*.002;this.vy+=(L.h[1]-this.by)*.002}
    if(!this.vx&&!this.vy&&this.st>=8&&!this.sink){this.sink=1}},
  draw(){const L=HOLES[this.hole];bg('#1f6b45');for(let y=0;y<H;y+=30)R(0,y,W,15,'#227550');
    for(const[x,y,w,h]of this.walls)R(x,y,w,h,'#7a5230');C(L.h[0],L.h[1],12,'#0b1a12');R(L.h[0]-1,L.h[1]-46,3,46,'#f1eefa');g.fillStyle='#ff5d8f';g.beginPath();g.moveTo(L.h[0]+2,L.h[1]-46);g.lineTo(L.h[0]+22,L.h[1]-39);g.lineTo(L.h[0]+2,L.h[1]-32);g.fill();
    if(!this.sink||this.sink>30)C(this.bx,this.by,8,'#f1eefa');
    if(this.aim){const dx=this.aim.sx-this.aim.x,dy=this.aim.sy-this.aim.y,l=Math.min(hyp(dx,dy),110);if(l>5){const k=l/hyp(dx,dy);g.strokeStyle='#ffb627';g.lineWidth=3;g.setLineDash([6,6]);g.beginPath();g.moveTo(this.bx,this.by);g.lineTo(this.bx+dx*k,this.by+dy*k);g.stroke();g.setLineDash([])}}
    T('HOLE '+(this.hole+1)+'/6  STROKES '+this.st,W/2,32,'#f1eefa',9)},
  down(p){if(!this.vx&&!this.vy&&!this.sink)this.aim={sx:p.x,sy:p.y,x:p.x,y:p.y}},move(p){if(this.aim){this.aim.x=p.x;this.aim.y=p.y}},
  up(){const a=this.aim;this.aim=null;if(!a)return;const dx=a.sx-a.x,dy=a.sy-a.y,l=hyp(dx,dy);if(l<8)return;const pw=Math.min(l,110)/110*14;this.vx=dx/l*pw;this.vy=dy/l*pw;this.st++;beep(330,.04)},
  art(c){c.fillStyle='#1f6b45';c.fillRect(0,0,128,96);c.fillStyle='#7a5230';c.fillRect(20,44,70,8);c.fillStyle='#0b1a12';c.beginPath();c.arc(96,20,6,0,7);c.fill();c.fillStyle='#fff';c.beginPath();c.arc(36,78,5,0,7);c.fill()}});

/* Bounce Up */
add({id:'bounce',name:'BOUNCE UP',c:'--a1',cat:'2ds',desc:'Bounce from ledge to ledge and climb as high as you can.',how:'Hold or drag left and right to steer (or arrows). Fly off one side to wrap to the other.',
  init(){this.x=W/2;this.y=H-80;this.vx=0;this.vy=-10;this.h=0;this.pl=[{x:W/2-30,y:H-40,vx:0}];this.top=H-40;while(this.top>-40)this.gen();this.tx=null;setScore(0)},
  gen(){const gap=rnd(55,75)+Math.min(40,this.h/400);this.top-=gap;this.pl.push({x:rnd(0,W-60),y:this.top,vx:Math.random()<Math.min(.4,this.h/6000)?rnd(-1.5,1.5):0})},
  update(){let ax=0;if(keys.ArrowLeft||keys.KeyA)ax=-1;if(keys.ArrowRight||keys.KeyD)ax=1;if(this.tx!==null)ax=clamp((this.tx-this.x)/40,-1,1);
    this.vx=this.vx*.85+ax*1.1;this.x+=this.vx;if(this.x<-12)this.x=W+12;if(this.x>W+12)this.x=-12;
    const py=this.y;this.vy+=.35;this.y+=this.vy;
    for(const p of this.pl){p.x+=p.vx;if(p.x<0||p.x>W-60)p.vx*=-1;if(this.vy>0&&py+14<=p.y&&this.y+14>=p.y&&this.x>p.x-10&&this.x<p.x+70){this.y=p.y-14;this.vy=-10.5;beep(420+Math.random()*80,.04)}}
    if(this.y<H*.4){const d=H*.4-this.y;this.y+=d;for(const p of this.pl)p.y+=d;this.top+=d;this.h+=d;setScore(Math.floor(this.h/10))}
    while(this.top>-40)this.gen();this.pl=this.pl.filter(p=>p.y<H+20);if(this.y>H+30)over()},
  draw(){bg('#141a2c');for(let i=0;i<20;i++)R((i*53)%W,((i*91+this.h*.3)%H),2,2,'#3a4566');
    for(const p of this.pl)R(p.x,p.y,60,10,p.vx?'#c58bff':'#3ddc97');C(this.x,this.y,14,'#ffb627');C(this.x+4,this.y-4,3,'#111')},
  down(p){this.tx=p.x},move(p){this.tx=p.x},up(){this.tx=null},
  art(c){c.fillStyle='#3ddc97';c.fillRect(14,76,34,6);c.fillRect(70,50,34,6);c.fillStyle='#c58bff';c.fillRect(30,24,34,6);c.fillStyle='#ffb627';c.beginPath();c.arc(84,34,8,0,7);c.fill()}});

/* Rock Ring */
add({id:'rocks',name:'ROCK RING',c:'--a6',cat:'2ds',desc:'Spin your turret and shatter space rocks closing in from every side.',how:'Touch where you want to aim. The turret fires on its own. Big rocks split.',
  init(){this.a=-Math.PI/2;this.ta=this.a;this.b=[];this.r=[];this.t=0;this.hp=5;this.fx=[];setScore(0)},
  spawn(sz){const a=rnd(0,7),d=340;const ang=Math.atan2(H/2-(H/2+Math.sin(a)*d),W/2-(W/2+Math.cos(a)*d))+rnd(-.3,.3),sp=rnd(.6,1.2)+this.t/6000;this.r.push({x:W/2+Math.cos(a)*d,y:H/2+Math.sin(a)*d,vx:Math.cos(ang)*sp,vy:Math.sin(ang)*sp,s:sz||3,rot:0})},
  update(){this.t++;if(keys.ArrowLeft||keys.KeyA)this.ta-=.07;if(keys.ArrowRight||keys.KeyD)this.ta+=.07;
    let d=this.ta-this.a;d=Math.atan2(Math.sin(d),Math.cos(d));this.a+=clamp(d,-.15,.15);
    if(this.t%10===0)this.b.push({x:W/2+Math.cos(this.a)*20,y:H/2+Math.sin(this.a)*20,vx:Math.cos(this.a)*8,vy:Math.sin(this.a)*8,l:60});
    if(this.t%Math.max(40,120-(this.t/120|0))===0)this.spawn();
    for(const b of this.b){b.x+=b.vx;b.y+=b.vy;b.l--}
    for(const r of this.r){r.x+=r.vx;r.y+=r.vy;r.rot+=.02;const rad=r.s*9;
      for(const b of this.b)if(b.l>0&&hyp(b.x-r.x,b.y-r.y)<rad){b.l=0;r.dead=1;setScore(score+(4-r.s));beep(200+r.s*60,.06,'square',.04);
        for(let k=0;k<5;k++)this.fx.push({x:r.x,y:r.y,vx:rnd(-2,2),vy:rnd(-2,2),l:20});
        if(r.s>1)for(let k=0;k<2;k++){const a=rnd(0,7);this.r.push({x:r.x,y:r.y,vx:Math.cos(a)*1.3,vy:Math.sin(a)*1.3,s:r.s-1,rot:0})}break}
      if(!r.dead&&hyp(r.x-W/2,r.y-H/2)<rad+16){r.dead=1;this.hp--;beep(100,.2,'sawtooth');if(this.hp<=0)return over()}}
    for(const f of this.fx){f.x+=f.vx;f.y+=f.vy;f.l--}
    this.b=this.b.filter(b=>b.l>0);this.r=this.r.filter(r=>!r.dead&&Math.abs(r.x-W/2)<420&&Math.abs(r.y-H/2)<420);this.fx=this.fx.filter(f=>f.l>0)},
  draw(){bg('#0a0812');for(let i=0;i<30;i++)R((i*137)%W,(i*71)%H,1.5,1.5,'#6c6590');
    g.strokeStyle='#2f2948';g.lineWidth=2;g.beginPath();g.arc(W/2,H/2,40,0,7);g.stroke();
    for(const r of this.r){g.save();g.translate(r.x,r.y);g.rotate(r.rot);g.fillStyle='#8a7a6a';g.beginPath();const n=7,rad=r.s*9;for(let i=0;i<n;i++){const a=i/n*Math.PI*2,k=rad*(.8+((i*37)%5)/20);g.lineTo(Math.cos(a)*k,Math.sin(a)*k)}g.fill();g.restore()}
    for(const b of this.b)C(b.x,b.y,3,'#ffb627');for(const f of this.fx)R(f.x,f.y,3,3,'#f29a2e');
    g.save();g.translate(W/2,H/2);g.rotate(this.a);R(0,-5,26,10,'#f29a2e');g.restore();C(W/2,H/2,16,'#5ab0ff');T('♥'.repeat(Math.max(0,this.hp)),12,26,'#ff5d8f',12,'left')},
  aim(p){this.ta=Math.atan2(p.y-H/2,p.x-W/2)},down(p){this.aim(p)},move(p){this.aim(p)},
  art(c){c.fillStyle='#5ab0ff';c.beginPath();c.arc(64,48,10,0,7);c.fill();c.fillStyle='#f29a2e';c.fillRect(64,45,20,6);c.fillStyle='#8a7a6a';[[20,20,10],[104,70,8],[100,18,6]].forEach(([x,y,r])=>{c.beginPath();c.arc(x,y,r,0,7);c.fill()})}});
