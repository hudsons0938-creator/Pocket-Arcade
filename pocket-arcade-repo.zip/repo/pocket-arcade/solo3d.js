/* 3D SOLO */

/* Marble Maze */
add({id:'maze',name:'MARBLE MAZE',c:'--a2',cat:'3ds',three:true,sticks:true,desc:'Roll a marble through bigger and bigger mazes before the clock runs out.',how:'Drag anywhere like a joystick to tilt the maze (or WASD). Reach the glowing pad. Each maze solved adds time.',
  init(){this.lv=0;this.time=60*60;this.cam=this.cam||cam3(55);setScore(0);this.build()},
  build(){const N=this.N=Math.min(10,4+this.lv),cs=this.cs=2.4;const s=this.s=scene3(0x0f1724);
    const hw=Array.from({length:N+1},()=>Array(N).fill(1)),vw=Array.from({length:N},()=>Array(N+1).fill(1)),vis=new Array(N*N).fill(0),st=[0];vis[0]=1;
    while(st.length){const cl=st[st.length-1],r=cl/N|0,c=cl%N,nb=[];if(r>0&&!vis[cl-N])nb.push([cl-N,'u']);if(r<N-1&&!vis[cl+N])nb.push([cl+N,'d']);if(c>0&&!vis[cl-1])nb.push([cl-1,'l']);if(c<N-1&&!vis[cl+1])nb.push([cl+1,'r']);
      if(!nb.length){st.pop();continue}const[n,d]=pick(nb);if(d==='u')hw[r][c]=0;if(d==='d')hw[r+1][c]=0;if(d==='l')vw[r][c]=0;if(d==='r')vw[r][c+1]=0;vis[n]=1;st.push(n)}
    const fl=box(N*cs+.4,.3,N*cs+.4,0x1e2a3a);fl.position.y=-.15;s.add(fl);this.walls=[];const wm=lam(0x5ab0ff,0x0a2040),th=.3;
    const addW=(x,z,w,d)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,.8,d),wm);m.position.set(x,.4,z);s.add(m);this.walls.push([x-w/2,x+w/2,z-d/2,z+d/2])};
    for(let r=0;r<=N;r++)for(let c=0;c<N;c++)if(hw[r][c])addW((c-N/2+.5)*cs,(r-N/2)*cs,cs+th,th);
    for(let r=0;r<N;r++)for(let c=0;c<=N;c++)if(vw[r][c])addW((c-N/2)*cs,(r-N/2+.5)*cs,th,cs+th);
    const gp=(N-1-N/2+.5)*cs;this.goal=new THREE.Mesh(new THREE.CylinderGeometry(.8,.8,.1,24),lam(0x3ddc97,0x1f8a5a));this.goal.position.set(gp,.06,gp);s.add(this.goal);
    const sp=(-N/2+.5)*cs;this.b=orb(.45,0xffb627,0x3a2400);this.b.position.set(sp,.45,sp);s.add(this.b);this.v={x:0,z:0};this.f=0},
  update(){this.f++;this.time--;if(this.time<=0)return over('TIME UP');const p=padLR(0),b=this.b.position,v=this.v;
    v.x=(v.x+p.x*.016)*.965;v.z=(v.z+p.y*.016)*.965;const sp=hyp(v.x,v.z);if(sp>.22){v.x*=.22/sp;v.z*=.22/sp}
    b.x+=v.x;b.z+=v.z;
    for(const[x0,x1,z0,z1]of this.walls){const cx=clamp(b.x,x0,x1),cz=clamp(b.z,z0,z1),dx=b.x-cx,dz=b.z-cz,d=hyp(dx,dz);
      if(d<.45&&d>0){const nx=dx/d,nz=dz/d;b.x=cx+nx*.45;b.z=cz+nz*.45;const dot=v.x*nx+v.z*nz;if(dot<0){v.x-=1.4*dot*nx;v.z-=1.4*dot*nz}}}
    this.b.rotation.x+=v.z/.45;this.b.rotation.z-=v.x/.45;this.goal.rotation.y+=.03;
    if(hyp(b.x-this.goal.position.x,b.z-this.goal.position.z)<.8){this.lv++;setScore(this.lv);this.time+=25*60;beep(880,.25,'triangle');this.build()}
    const c=this.cam;c.position.set(b.x,7+this.N*.5,b.z+5+this.N*.2);c.lookAt(b.x,0,b.z-.3);setHud('⏱ '+Math.ceil(this.time/60)+'s  ·  MAZE '+(this.lv+1))},
  draw:r3,
  art(c){c.fillStyle='#1e2a3a';c.fillRect(10,6,108,84);c.fillStyle='#5ab0ff';[[10,6,108,5],[10,85,108,5],[10,6,5,84],[113,6,5,84],[40,6,5,50],[70,40,5,50],[40,56,30,5]].forEach(r=>c.fillRect(...r));c.fillStyle='#3ddc97';c.fillRect(92,66,14,14);c.fillStyle='#ffb627';c.beginPath();c.arc(26,22,6,0,7);c.fill()}});

/* Ring Flight */
add({id:'rings',name:'RING FLIGHT',c:'--a4',cat:'3ds',three:true,sticks:true,desc:'Pilot a glider through floating rings. Miss three and you are grounded.',how:'Drag like a joystick to steer up, down, left and right (or WASD). Fly through every ring.',
  init(){const s=this.s=scene3(0x101a38,30,95);this.cam=cam3(62);
    const gr=this.gr=new THREE.GridHelper(200,80,0x3a4a90,0x223060);gr.position.y=-1;s.add(gr);
    const p=this.pl=new THREE.Group();const body=box(.5,.4,1.6,0xffb627,0x3a2400),wing=box(2.6,.08,.6,0xff5d8f),tail=box(.9,.06,.35,0xff5d8f),fin=box(.06,.45,.35,0x5ab0ff);wing.position.z=.1;tail.position.z=.7;fin.position.set(0,.25,.7);p.add(body,wing,tail,fin);p.position.set(0,3,0);s.add(p);
    this.r=[];this.t=0;this.lives=3;this.spd=.38;this.lx=0;this.ly=3.5;this.fl=0;setScore(0)},
  update(){this.t++;this.spd=Math.min(.85,.38+this.t*.00007);const pd=padLR(0),p=this.pl.position;
    p.x=clamp(p.x+pd.x*.2,-7,7);p.y=clamp(p.y-pd.y*.16,.5,8.5);this.pl.rotation.z+=(-pd.x*.7-this.pl.rotation.z)*.15;this.pl.rotation.x+=(pd.y*.35-this.pl.rotation.x)*.15;
    if(this.t%Math.max(40,Math.round(30/this.spd))===0){this.lx=clamp(this.lx+rnd(-4.5,4.5),-6,6);this.ly=clamp(this.ly+rnd(-2.5,2.5),1.2,7.5);
      const r=new THREE.Mesh(new THREE.TorusGeometry(1.6,.14,8,28),lam(0x3ddc97,0x0c5a3a));r.position.set(this.lx,this.ly,-95);r.userData={z:-95};this.s.add(r);this.r.push(r)}
    for(const r of this.r){const pz=r.position.z;r.position.z+=this.spd;r.rotation.z+=.01;
      if(pz<0&&r.position.z>=0&&!r.userData.done){r.userData.done=1;if(hyp(r.position.x-p.x,r.position.y-p.y)<1.55){setScore(score+1);beep(700+score%8*60,.08,'triangle');r.material=lam(0xffb627,0x5a3a00)}
        else{this.lives--;this.fl=20;r.material=lam(0xff5d8f,0x5a0f26);beep(130,.25,'sawtooth');if(this.lives<=0)return over()}}}
    this.r=this.r.filter(r=>{if(r.position.z>12){this.s.remove(r);return false}return true});
    this.gr.position.z=(this.gr.position.z+this.spd)%2.5;
    this.cam.position.set(p.x*.6,p.y+2,7);this.cam.lookAt(p.x*.8,p.y,-12);
    this.s.background.setHex(this.fl-->0?0x3a1030:0x101a38);setHud('♥'.repeat(Math.max(0,this.lives)))},
  draw:r3,
  art(c){c.strokeStyle='#3ddc97';c.lineWidth=5;c.beginPath();c.ellipse(80,40,18,24,0,0,7);c.stroke();c.fillStyle='#ff5d8f';c.fillRect(20,60,40,5);c.fillStyle='#ffb627';c.fillRect(36,54,8,16)}});

/* Stack Tower 3D */
add({id:'stack3',name:'STACK TOWER 3D',c:'--a5',cat:'3ds',three:true,desc:'Stack sliding slabs into a sky-high 3D tower.',how:'Tap (or Space) to drop the moving slab onto the tower. Overhang gets sliced off. Perfect drops keep full size.',
  init(){const s=this.s=scene3(0x1a1630);this.cam=cam3(45);
    const base=box(3,6,3,0x2f2948);base.position.y=-3;s.add(base);this.bl=[{x:0,z:0,w:3,d:3}];this.fall=[];this.ax='x';this.t=0;this.cy=2;this.newMov();setScore(0)},
  col(i){return new THREE.Color().setHSL((.7+i*.035)%1,.65,.58)},
  newMov(){const t=this.bl[this.bl.length-1],i=this.bl.length;this.mv={x:this.ax==='x'?-6:t.x,z:this.ax==='z'?-6:t.z,w:t.w,d:t.d,dir:1};
    this.mm=new THREE.Mesh(new THREE.BoxGeometry(t.w,.6,t.d),new THREE.MeshLambertMaterial({color:this.col(i)}));this.mm.position.set(this.mv.x,i*.6-.3,this.mv.z);this.s.add(this.mm)},
  chunk(x,z,w,d,y,col){const m=new THREE.Mesh(new THREE.BoxGeometry(w,.6,d),new THREE.MeshLambertMaterial({color:col}));m.position.set(x,y,z);m.userData.vy=0;this.s.add(m);this.fall.push(m)},
  drop(){if(!running)return;const t=this.bl[this.bl.length-1],m=this.mv,ax=this.ax,i=this.bl.length,y=i*.6-.3;
    let delta=ax==='x'?m.x-t.x:m.z-t.z;const size=ax==='x'?t.w:t.d,ov=size-Math.abs(delta);
    if(ov<=0){this.s.remove(this.mm);this.chunk(m.x,m.z,m.w,m.d,y,this.col(i));return over()}
    if(Math.abs(delta)<.12){delta=0;beep(990,.1,'triangle')}else beep(440,.05);
    const nb={x:t.x,z:t.z,w:t.w,d:t.d};const cut=Math.abs(delta),sg=Math.sign(delta);
    if(ax==='x'){nb.x=t.x+delta/2;nb.w=ov;if(cut)this.chunk(nb.x+sg*(ov/2+cut/2),t.z,cut,t.d,y,this.col(i))}else{nb.z=t.z+delta/2;nb.d=ov;if(cut)this.chunk(t.x,nb.z+sg*(ov/2+cut/2),t.w,cut,y,this.col(i))}
    this.s.remove(this.mm);const mesh=new THREE.Mesh(new THREE.BoxGeometry(nb.w,.6,nb.d),new THREE.MeshLambertMaterial({color:this.col(i)}));mesh.position.set(nb.x,y,nb.z);this.s.add(mesh);
    this.bl.push(nb);setScore(this.bl.length-1);this.ax=ax==='x'?'z':'x';this.newMov()},
  update(){this.t++;const m=this.mv,sp=Math.min(.16,.07+this.bl.length*.003);
    if(this.mm){m[this.ax]+=m.dir*sp;if(Math.abs(m[this.ax])>6)m.dir*=-1;this.mm.position.x=m.x;this.mm.position.z=m.z}
    for(const f of this.fall){f.userData.vy-=.02;f.position.y+=f.userData.vy;f.rotation.x+=.02}
    this.fall=this.fall.filter(f=>{if(f.position.y<-30){this.s.remove(f);return false}return true});
    const top=this.bl.length*.6;this.cy+=(top-this.cy)*.08;this.cam.position.set(9,this.cy+8,9);this.cam.lookAt(0,this.cy-1.5,0)},
  draw:r3,down(){this.drop()},key(k){if(k==='Space')this.drop()},
  art(c){for(let i=0;i<6;i++){c.fillStyle=`hsl(${250+i*12} 65% ${45+i*4}%)`;c.beginPath();const y=80-i*11;c.moveTo(64,y-8);c.lineTo(96,y);c.lineTo(64,y+8);c.lineTo(32,y);c.fill()}}});

/* Strike Lanes (bowling) */
add({id:'bowl',name:'STRIKE LANES',c:'--a1',cat:'3ds',three:true,desc:'Five frames of bowling. Curve it in for strikes.',how:'Swipe up to roll. Where you start the swipe sets your spot on the lane; swipe at an angle to aim. A strike is worth 20, a spare 15.',
  init(){const s=this.s=scene3(0x15121f,20,45);this.cam=cam3(55);
    const ln=box(3.2,.2,26,0xc9925a);ln.position.set(0,-.1,-10);s.add(ln);
    for(const x of[-1.9,1.9]){const gt=box(.6,.1,26,0x3a2f40);gt.position.set(x,-.15,-10);s.add(gt)}
    for(let i=0;i<5;i++){const a=box(.08,.01,.3,0x7a4a20);a.position.set((i-2)*.5,.01,-5);s.add(a)}
    this.pins=[];const pm=lam(0xf4f1f8);for(let r=0;r<4;r++)for(let k=0;k<=r;k++){const m=new THREE.Mesh(new THREE.CylinderGeometry(.11,.17,.75,12),pm);m.userData={hx:(k-r/2)*.62,hz:-18-r*.55};s.add(m);this.pins.push(m)}
    this.ball=orb(.35,0x5ab0ff,0x0a2a50);s.add(this.ball);this.fr=0;this.roll=0;this.tot=0;this.first=0;this.rack(true);this.ready();setScore(0)},
  rack(full){for(const p of this.pins){if(full){p.userData.down=0;p.visible=true}if(p.userData.down){p.visible=false;continue}p.position.set(p.userData.hx,.375,p.userData.hz);p.rotation.set(0,0,0);p.userData.vx=0;p.userData.vz=0;p.userData.fall=0}},
  ready(){this.st='aim';this.ball.position.set(0,.35,2);this.bv={x:0,z:0};this.gut=0;setHud('FRAME '+(this.fr+1)+'/5 · ROLL '+(this.roll+1)+' · SWIPE UP')},
  update(){const b=this.ball.position;
    if(this.st==='roll'){b.x+=this.bv.x;b.z+=this.bv.z;this.ball.rotation.x-=this.bv.z*3;
      if(!this.gut&&Math.abs(b.x)>1.5){this.gut=1;this.bv.x=0;b.x=Math.sign(b.x)*1.9;b.y=.2;beep(150,.2)}
      if(!this.gut)for(const p of this.pins){if(!p.visible)continue;const dx=p.position.x-b.x,dz=p.position.z-b.z,d=hyp(dx,dz);
        if(d<.52&&d>0){const s=hyp(this.bv.x,this.bv.z)*1.1;p.userData.vx+=dx/d*s;p.userData.vz+=dz/d*s;p.position.x=b.x+dx/d*.52;p.position.z=b.z+dz/d*.52;this.bv.z*=.97;beep(300+Math.random()*200,.03)}}
      if(b.z<-22){this.st='settle';this.tm=80}}
    for(const p of this.pins){if(!p.visible)continue;const u=p.userData;p.position.x+=u.vx;p.position.z+=u.vz;u.vx*=.95;u.vz*=.95;if(hyp(u.vx,u.vz)>.02)u.fall=1;
      if(u.fall&&p.rotation.x>-1.5){p.rotation.x-=.12;p.rotation.y=Math.atan2(u.vx,u.vz);p.position.y=.2}}
    for(let i=0;i<10;i++)for(let j=i+1;j<10;j++){const a=this.pins[i],c=this.pins[j];if(!a.visible||!c.visible)continue;const dx=c.position.x-a.position.x,dz=c.position.z-a.position.z,d=hyp(dx,dz);
      if(d<.36&&d>0){const ua=a.userData,uc=c.userData,nx=dx/d,nz=dz/d,rv=(ua.vx-uc.vx)*nx+(ua.vz-uc.vz)*nz;if(rv>0){ua.vx-=rv*nx*.9;ua.vz-=rv*nz*.9;uc.vx+=rv*nx*.9;uc.vz+=rv*nz*.9}c.position.x+=nx*(.36-d)/2;c.position.z+=nz*(.36-d)/2;a.position.x-=nx*(.36-d)/2;a.position.z-=nz*(.36-d)/2}}
    if(this.st==='settle'&&--this.tm<=0){const down=this.pins.filter(p=>p.visible&&p.userData.fall).length;this.pins.forEach(p=>{if(p.userData.fall)p.userData.down=1});
      const left=this.pins.filter(p=>!p.userData.down).length;
      if(this.roll===0){this.first=down;if(left===0){this.tot+=20;this.flash='STRIKE!';beep(990,.3,'triangle');this.next()}else{this.roll=1;this.rack(false);this.ready()}}
      else{if(left===0){this.tot+=15;this.flash='SPARE!';beep(880,.25,'triangle')}else this.tot+=this.first+down;this.next()}
      setScore(this.tot)}
    const cz=clamp(b.z+4.5,-13,6.5);this.cam.position.set(0,1.9,cz);this.cam.lookAt(0,.2,cz-8)},
  next(){this.fr++;this.roll=0;if(this.fr>=5){setScore(this.tot);return over(this.flash==='STRIKE!'?'STRIKE TO FINISH!':'FINAL SCORE')}this.rack(true);this.ready();if(this.flash){setHud(this.flash+'  ·  FRAME '+(this.fr+1)+'/5');this.flash=''}},
  draw:r3,
  down(p){if(this.st==='aim')this.ball.position.x=clamp((p.nx-.5)*3,-1.3,1.3)},
  up(p){if(this.st!=='aim')return;const dy=p.y-p.syp,dx=p.x-p.sxp;if(dy>-40)return;const sp=clamp(-dy/340,.3,.8)*.7,ang=clamp(dx/-dy,-.3,.3);
    this.bv={x:ang*sp*.55,z:-sp};this.st='roll';setHud('');beep(200,.15,'triangle')},
  key(k){if(this.st!=='aim')return;if(k==='ArrowLeft')this.ball.position.x=Math.max(-1.3,this.ball.position.x-.2);if(k==='ArrowRight')this.ball.position.x=Math.min(1.3,this.ball.position.x+.2);if(k==='Space'||k==='ArrowUp'){this.bv={x:0,z:-.5};this.st='roll'}},
  art(c){c.fillStyle='#c9925a';c.beginPath();c.moveTo(50,0);c.lineTo(78,0);c.lineTo(110,96);c.lineTo(18,96);c.fill();c.fillStyle='#f4f1f8';[[58,14],[70,14],[64,8],[64,20]].forEach(([x,y])=>c.fillRect(x,y,5,10));c.fillStyle='#5ab0ff';c.beginPath();c.arc(62,76,9,0,7);c.fill()}});

/* Warp Tunnel */
add({id:'tunnel',name:'WARP TUNNEL',c:'--a3',cat:'3ds',three:true,desc:'Race down a spinning neon tube and slip through the gaps.',how:'Drag left or right to spin around the tunnel (or arrow keys). Find the gap in each wall.',
  init(){const s=this.s=scene3(0x07050f,8,60);this.cam=cam3(75);this.cam.position.set(0,0,4.5);
    this.rings=[];for(let i=0;i<16;i++){const r=new THREE.Mesh(new THREE.TorusGeometry(4.3,.05,6,40),new THREE.MeshBasicMaterial({color:i%2?0xc58bff:0x5ab0ff}));r.position.z=-i*4;s.add(r);this.rings.push(r)}
    this.pl=box(.8,.35,1.1,0xffb627,0x553300);s.add(this.pl);this.th=0;this.ob=[];this.t=0;this.spd=.35;this.d=0;setScore(0)},
  wall(){const n=ri(3,5),gap=ri(0,n-1),a0=rnd(0,7),grp=[];
    for(let k=0;k<n;k++){if(k===gap)continue;const a=a0+k*Math.PI*2/n,w=(Math.PI*2/n)*3.4*.82;const m=box(w,.9,.6,0xff5d8f,0x400a20);m.position.set(Math.sin(a)*3.6,-Math.cos(a)*3.6,-60);m.rotation.z=a;m.userData={a,hw:Math.PI/n*.82};this.s.add(m);this.ob.push(m)}},
  update(){this.t++;this.spd=Math.min(1,.35+this.t*.00012);this.d+=this.spd;if(keys.ArrowLeft||keys.KeyA)this.th-=.07;if(keys.ArrowRight||keys.KeyD)this.th+=.07;
    if(this.t%Math.max(26,Math.round(22/this.spd))===0)this.wall();
    for(const r of this.rings){r.position.z+=this.spd;if(r.position.z>4)r.position.z-=64}
    for(const o of this.ob){o.position.z+=this.spd;if(Math.abs(o.position.z)<.7){let d=o.userData.a-this.th;d=Math.atan2(Math.sin(d),Math.cos(d));if(Math.abs(d)<o.userData.hw+.1)return over()}}
    this.ob=this.ob.filter(o=>{if(o.position.z>6){this.s.remove(o);return false}return true});
    this.pl.position.set(Math.sin(this.th)*3.5,-Math.cos(this.th)*3.5,0);this.pl.rotation.z=this.th;this.cam.rotation.z=this.th;
    const sc=Math.floor(this.d);if(sc!==score)setScore(sc)},
  draw:r3,down(p){this.lx=p.x},move(p){if(this.lx!=null){this.th+=(p.x-this.lx)*.022;this.lx=p.x}},up(){this.lx=null},
  art(c){for(let i=4;i>0;i--){c.strokeStyle=i%2?'#c58bff':'#5ab0ff';c.lineWidth=2;c.beginPath();c.arc(64,48,i*11,0,7);c.stroke()}c.fillStyle='#ff5d8f';c.fillRect(44,10,40,10);c.fillStyle='#ffb627';c.fillRect(58,84,12,7)}});

/* Hoop Shot */
add({id:'hoops',name:'HOOP SHOT',c:'--a6',cat:'3ds',three:true,desc:'Swipe to shoot hoops against the clock. The rim starts sliding after 5.',how:'Swipe up toward the hoop. Swipe length sets power, sideways angle sets aim. 45 seconds.',
  init(){const s=this.s=scene3(0x1a1420);this.cam=cam3(55);this.cam.position.set(0,2.4,6.2);this.cam.lookAt(0,2.2,-4);
    const fl=box(14,.2,20,0x9a6a3a);fl.position.set(0,-.1,-3);s.add(fl);const ln=box(6,.01,.08,0xffffff);ln.position.set(0,.01,1);s.add(ln);
    this.hp=new THREE.Group();const bb=box(2,1.3,.1,0xf1eefa);bb.position.set(0,3.55,-.55);const sq=box(.7,.5,.11,0xff5d8f);sq.position.set(0,3.4,-.54);
    const rim=new THREE.Mesh(new THREE.TorusGeometry(.45,.04,8,24),lam(0xff8a3d,0x5a2000));rim.rotation.x=Math.PI/2;rim.position.y=3;const pole=box(.15,3.5,.15,0x3a3360);pole.position.set(0,1.75,-.9);
    this.hp.add(bb,sq,rim,pole);this.hp.position.set(0,0,-6);s.add(this.hp);this.hx=0;
    this.b=orb(.22,0xf29a2e,0x3a1a00);s.add(this.b);this.time=45*60;this.t=0;this.ready();setScore(0)},
  ready(){this.st='ready';this.b.position.set(0,1,2.5);this.v={x:0,y:0,z:0};this.sc=0},
  update(){this.t++;this.time--;if(this.time<=0)return over('TIME UP');setHud('⏱ '+Math.ceil(this.time/60)+'s');
    if(score>=5)this.hx=Math.sin(this.t*.012*(1+score*.03))*2.2;this.hp.position.x=this.hx;
    if(this.st!=='fly')return;const b=this.b.position,v=this.v,py=b.y,pz=b.z;v.y-=.012;b.x+=v.x;b.y+=v.y;b.z+=v.z;this.b.rotation.x-=.15;
    const cx=this.hx,cz=-6,cy=3,dx=b.x-cx,dz=b.z-cz,dh=hyp(dx,dz);
    if(!this.sc&&py>cy&&b.y<=cy&&dh<.48){this.sc=1;setScore(score+1);beep(880,.2,'triangle')}
    if(dh>0){const rx=cx+dx/dh*.45,rz=cz+dz/dh*.45,ex=b.x-rx,ey=b.y-cy,ez=b.z-rz,d=hyp(ex,ey,ez);
      if(d<.26&&d>0){const nx=ex/d,ny=ey/d,nz=ez/d,dot=v.x*nx+v.y*ny+v.z*nz;if(dot<0){v.x-=1.6*dot*nx;v.y-=1.6*dot*ny;v.z-=1.6*dot*nz}b.x=rx+nx*.26;b.y=cy+ny*.26;b.z=rz+nz*.26;beep(260,.03)}}
    if(pz-.22>=cz-.55&&b.z-.22<cz-.55&&Math.abs(b.x-cx)<1&&b.y>2.9&&b.y<4.2){v.z=Math.abs(v.z)*.5;b.z=cz-.55+.22;beep(180,.03)}
    if(b.y<.22){b.y=.22;v.y=Math.abs(v.y)*.55;v.x*=.8;v.z*=.8}
    if(--this.ft<=0||b.z>5||b.z<-12)this.ready()},
  shoot(dxN,dyN){if(this.st!=='ready')return;const T=45,gr=.012,hz=-6,hy=3;const sc=clamp(dyN/.355,.6,1.5);
    this.v={x:dxN*.25,y:(hy-1+.5*gr*T*T)/T*(.55+.45*sc),z:(hz-2.5)/T*sc};this.st='fly';this.ft=150;beep(300,.05)},
  draw:r3,
  up(p){const dyN=(p.syp-p.y)/H,dxN=(p.x-p.sxp)/W;if(dyN>.06)this.shoot(dxN,dyN)},
  key(k){if(k==="Space")this.shoot(this.hx/45/.25,.355)},
  art(c){c.fillStyle='#f1eefa';c.fillRect(44,10,40,26);c.strokeStyle='#ff8a3d';c.lineWidth=3;c.beginPath();c.ellipse(64,40,12,4,0,0,7);c.stroke();c.fillStyle='#f29a2e';c.beginPath();c.arc(58,74,10,0,7);c.fill()}});

/* Hop Cross 3D */
add({id:'hopx',name:'HOP CROSS 3D',c:'--a2',cat:'3ds',three:true,desc:'Hop a little cube across endless roads without getting flattened.',how:'Tap to hop forward. Swipe left, right or down to sidestep or back up. Arrows or WASD on a keyboard.',
  init(){const s=this.s=scene3(0x8fd0ff,18,40);this.cam=cam3(50);this.rows=[];this.gen=0;this.px=0;this.pr=0;this.hop=null;this.best=0;
    this.pl=box(.7,.7,.7,0xffffff);const bk=box(.2,.15,.25,0xff8a3d);bk.position.set(0,.05,-.45);this.pl.add(bk);const cm=box(.2,.15,.3,0xff3d5e);cm.position.set(0,.42,0);this.pl.add(cm);
    this.pl.position.set(0,.35,0);s.add(this.pl);this.cx=0;this.cz=0;for(let i=0;i<22;i++)this.addRow();setScore(0)},
  addRow(){const r=this.gen++,grp=new THREE.Group();grp.position.z=-r;const type=r<3?'g':Math.random()<.6?'r':'g';
    const gr=box(24,.1,1,type==='r'?0x3b3b48:(r%2?0x6fd36f:0x63c763));gr.position.y=-.05;grp.add(gr);const row={type,grp,cars:[],trees:new Set()};
    if(type==='r'){row.dir=Math.random()<.5?1:-1;row.sp=rnd(.04,.09)+Math.min(.08,r*.0008);const n=ri(1,3),off=rnd(0,20);
      for(let k=0;k<n;k++){const car=box(1.6,.7,.8,pick([0xff5d8f,0xffb627,0x5ab0ff,0xc58bff,0xf29a2e]));car.position.set(-10+((off+k*20/n)%20),.4,0);const cab=box(.8,.35,.7,0x222233);cab.position.set(0,.45,0);car.add(cab);grp.add(car);row.cars.push(car)}
      for(let x=-10;x<=10;x+=2){const d=box(.4,.01,.08,0xdddddd);d.position.set(x,.01,.45);grp.add(d)}}
    else if(r>2){const n=ri(0,3);for(let k=0;k<n;k++){const x=ri(-4,4);if(x===0&&r<6)continue;row.trees.add(x);const tr=box(.7,1.2,.7,0x2a8a3a);tr.position.set(x,.6,0);const tk=box(.25,.3,.25,0x7a5230);tk.position.set(x,.15,0);grp.add(tk,tr)}}
    for(const x of[-5,5]){const e=box(.95,.3,.95,0x2a2440);e.position.set(x,.15,0);grp.add(e)}
    this.s.add(grp);this.rows[r]=row},
  go(dx,dr){if(this.hop||!running)return;const nx=this.px+dx,nr=this.pr+dr;if(nx<-4||nx>4||nr<0||nr<this.best-6)return;const row=this.rows[nr];if(row&&row.trees.has(nx))return;
    this.hop={fx:this.px,fr:this.pr,tx:nx,tr:nr,t:0};this.px=nx;this.pr=nr;this.pl.rotation.y=dx?-dx*Math.PI/2:(dr<0?Math.PI:0);beep(500,.03)},
  update(){const pl=this.pl.position;
    if(this.hop){const h=this.hop;h.t+=1/7;const k=Math.min(1,h.t);pl.x=h.fx+(h.tx-h.fx)*k;pl.z=-(h.fr+(h.tr-h.fr)*k);pl.y=.35+Math.sin(k*Math.PI)*.5;if(k>=1){this.hop=null;if(this.pr>this.best){this.best=this.pr;setScore(this.best)}}}
    while(this.gen<this.pr+22)this.addRow();
    for(let r=Math.max(0,this.pr-12);r<this.pr-8;r++){const row=this.rows[r];if(row&&row.grp.parent){this.s.remove(row.grp)}}
    for(let r=Math.max(0,this.pr-8);r<this.gen;r++){const row=this.rows[r];if(row.type!=='r')continue;for(const c of row.cars){c.position.x+=row.dir*row.sp;if(c.position.x>11)c.position.x-=22;if(c.position.x<-11)c.position.x+=22}}
    const cr=Math.round(-pl.z),row=this.rows[cr];if(row&&row.type==='r'&&pl.y<.6)for(const c of row.cars)if(Math.abs(c.position.x-pl.x)<1.1){this.pl.scale.y=.2;pl.y=.08;return over('SPLAT!')}
    this.cx+=(pl.x*.5-this.cx)*.1;this.cz+=(pl.z-this.cz)*.1;this.cam.position.set(this.cx+2.5,8,this.cz+6.5);this.cam.lookAt(this.cx,0,this.cz-1.5)},
  draw:r3,down(p){this.sp=p},up(p){if(!this.sp)return;const dx=p.x-this.sp.x,dy=p.y-this.sp.y;this.sp=null;if(hyp(dx,dy)<16)return this.go(0,1);
    if(Math.abs(dx)>Math.abs(dy))this.go(Math.sign(dx),0);else this.go(0,dy<0?1:-1)},
  key(k){({ArrowUp:()=>this.go(0,1),KeyW:()=>this.go(0,1),Space:()=>this.go(0,1),ArrowDown:()=>this.go(0,-1),KeyS:()=>this.go(0,-1),ArrowLeft:()=>this.go(-1,0),KeyA:()=>this.go(-1,0),ArrowRight:()=>this.go(1,0),KeyD:()=>this.go(1,0)}[k]||(()=>{}))()},
  art(c){c.fillStyle='#63c763';c.fillRect(0,0,128,96);c.fillStyle='#3b3b48';c.fillRect(0,26,128,26);c.fillStyle='#ff5d8f';c.fillRect(20,30,30,16);c.fillStyle='#fff';c.fillRect(70,62,16,16);c.fillStyle='#ff3d5e';c.fillRect(74,58,8,5)}});
