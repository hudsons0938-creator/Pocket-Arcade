/* 2D VERSUS — two players on one screen. Blue = bottom half, Pink = top half. */
const VS2=['2 PLAYERS','VS CPU'];
const nm=(i,cpu)=>i===0?'BLUE':(cpu?'CPU':'PINK');
function vsScore(a,b){setScore(a+' - '+b)}
function bigScores(a,b,col1=P1C,col2=P2C){g.globalAlpha=.25;T(String(a),W/2,H*.75+20,col1,48);TF(String(b),W/2,H*.25-20,col2,48);g.globalAlpha=1}

/* Duel Pong */
add({id:'pong',name:'DUEL PONG',c:'--a4',cat:'2dv',modes:VS2,desc:'Head-to-head paddle battle. First to 7.',how:'Blue slides a finger along the bottom half, Pink along the top half. Keys: A/D and Left/Right.',
  init(){this.p=[W/2,W/2];this.sc=[0,0];this.serve(1);vsScore(0,0)},
  serve(d){this.bx=W/2;this.by=H/2;const a=rnd(-.5,.5);this.vx=Math.sin(a)*4;this.vy=d*Math.cos(a)*4.6;this.wait=50},
  update(){for(const q of ptrs.values()){if(q.sy>=.5)this.p[0]=q.x;else if(!this.cpu)this.p[1]=q.x}
    if(keys.KeyA)this.p[0]-=7;if(keys.KeyD)this.p[0]+=7;
    if(this.cpu){this.p[1]+=clamp(this.bx-this.p[1],-4.4,4.4)}else{if(keys.ArrowLeft)this.p[1]-=7;if(keys.ArrowRight)this.p[1]+=7}
    this.p=this.p.map(x=>clamp(x,44,W-44));if(this.wait>0){this.wait--;return}
    this.bx+=this.vx;this.by+=this.vy;if(this.bx<8||this.bx>W-8){this.vx*=-1;this.bx=clamp(this.bx,8,W-8)}
    const sp=Math.min(12,hyp(this.vx,this.vy)*1.05);
    if(this.vy>0&&this.by+8>=H-40&&this.by<H-24&&Math.abs(this.bx-this.p[0])<50){const a=(this.bx-this.p[0])/50*1;this.vx=Math.sin(a)*sp;this.vy=-Math.cos(a)*sp;beep(520,.04)}
    if(this.vy<0&&this.by-8<=40&&this.by>24&&Math.abs(this.bx-this.p[1])<50){const a=(this.bx-this.p[1])/50;this.vx=Math.sin(a)*sp;this.vy=Math.cos(a)*sp;beep(420,.04)}
    if(this.by>H+10||this.by<-10){const w=this.by<0?0:1;this.sc[w]++;vsScore(...this.sc);beep(w?200:800,.15);
      if(this.sc[w]>=7)return win(nm(w,this.cpu)+' WINS!',this.sc[0]+' to '+this.sc[1]);this.serve(w?1:-1)}},
  draw(){bg();R(0,H/2-1,W,2,'#2f2948');bigScores(...this.sc);R(this.p[0]-44,H-40,88,12,P1C);R(this.p[1]-44,28,88,12,P2C);if(this.wait%10<6)C(this.bx,this.by,8,'#f1eefa')},
  art(c){c.fillStyle='#5ab0ff';c.fillRect(40,82,48,7);c.fillStyle='#ff5d8f';c.fillRect(40,7,48,7);c.fillStyle='#fff';c.beginPath();c.arc(70,48,5,0,7);c.fill()}});

/* Air Hockey */
add({id:'hockey',name:'AIR HOCKEY',c:'--a2',cat:'2dv',modes:VS2,desc:'Smack the puck into your rival\'s goal. First to 5.',how:'Drag your mallet around your half of the table. Blue is bottom, Pink is top. Keys: WASD and arrows.',
  init(){this.m=[{x:W/2,y:H-70,vx:0,vy:0},{x:W/2,y:70,vx:0,vy:0}];this.sc=[0,0];this.reset(1);vsScore(0,0)},
  reset(toward){this.pk={x:W/2,y:H/2+toward*60,vx:0,vy:0}},
  update(){const tg=[null,null];for(const q of ptrs.values()){if(q.sy>=.5)tg[0]={x:q.x,y:q.y};else if(!this.cpu)tg[1]={x:q.x,y:q.y}}
    const k=[kj(...KP1),this.cpu?null:kj(...KP2)];const pk=this.pk;
    if(this.cpu){const m=this.m[1];tg[1]=pk.y<H/2+30?{x:pk.x,y:pk.y-18}:{x:W/2+(pk.x-W/2)*.5,y:60}}
    this.m.forEach((m,i)=>{const ox=m.x,oy=m.y;let t=tg[i];if(!t&&k[i])t={x:m.x+k[i].x*30,y:m.y+k[i].y*30};
      if(t){const dx=t.x-m.x,dy=t.y-m.y,d=hyp(dx,dy),cap=this.cpu&&i===1?5:20;if(d>0){const s=Math.min(d,cap)/d;m.x+=dx*s;m.y+=dy*s}}
      m.x=clamp(m.x,24,W-24);m.y=i===0?clamp(m.y,H/2+26,H-24):clamp(m.y,24,H/2-26);m.vx=m.x-ox;m.vy=m.y-oy});
    pk.x+=pk.vx;pk.y+=pk.vy;pk.vx*=.995;pk.vy*=.995;
    if(pk.x<16||pk.x>W-16){pk.vx*=-.9;pk.x=clamp(pk.x,16,W-16);beep(300,.02)}
    const inGoal=Math.abs(pk.x-W/2)<62;
    if(pk.y<16){if(inGoal&&pk.y<-10)return this.goal(0);if(!inGoal){pk.vy=Math.abs(pk.vy)*.9;pk.y=16}}
    if(pk.y>H-16){if(inGoal&&pk.y>H+10)return this.goal(1);if(!inGoal){pk.vy=-Math.abs(pk.vy)*.9;pk.y=H-16}}
    for(const m of this.m){const dx=pk.x-m.x,dy=pk.y-m.y,d=hyp(dx,dy);if(d<40&&d>0){const nx=dx/d,ny=dy/d;pk.x=m.x+nx*40;pk.y=m.y+ny*40;
      const rv=(pk.vx-m.vx)*nx+(pk.vy-m.vy)*ny;if(rv<0){pk.vx-=1.9*rv*nx;pk.vy-=1.9*rv*ny;beep(600,.02)}const s=hyp(pk.vx,pk.vy);if(s>16){pk.vx*=16/s;pk.vy*=16/s}}}},
  goal(w){this.sc[w]++;vsScore(...this.sc);beep(w?200:800,.2,'triangle');if(this.sc[w]>=5)return win(nm(w,this.cpu)+' WINS!',this.sc[0]+' to '+this.sc[1]);this.reset(w?1:-1);this.m[0].x=this.m[1].x=W/2},
  draw(){bg('#0d1b24');g.strokeStyle='#2c4a5a';g.lineWidth=3;g.beginPath();g.arc(W/2,H/2,50,0,7);g.moveTo(0,H/2);g.lineTo(W,H/2);g.stroke();
    R(W/2-62,0,124,6,P2C);R(W/2-62,H-6,124,6,P1C);bigScores(...this.sc);
    this.m.forEach((m,i)=>{C(m.x,m.y,24,i?P2C:P1C);C(m.x,m.y,11,'#ffffff55')});C(this.pk.x,this.pk.y,16,'#f1eefa');C(this.pk.x,this.pk.y,10,'#c8c3dc')},
  art(c){c.fillStyle='#0d1b24';c.fillRect(0,0,128,96);c.fillStyle='#5ab0ff';c.beginPath();c.arc(50,74,12,0,7);c.fill();c.fillStyle='#ff5d8f';c.beginPath();c.arc(80,22,12,0,7);c.fill();c.fillStyle='#fff';c.beginPath();c.arc(64,48,7,0,7);c.fill()}});

/* Tank Arena */
const TW=[[60,248,80,44],[220,248,80,44],[160,140,40,40],[160,360,40,40]];
const inWall=(x,y,r)=>x<r||x>W-r||y<r||y>H-r||TW.some(([a,b,w,h])=>x>a-r&&x<a+w+r&&y>b-r&&y<b+h+r);
add({id:'tanks',name:'TANK ARENA',c:'--a6',cat:'2dv',modes:VS2,desc:'Steer your tank and bank shots off walls. First to 5 hits.',how:'Drag in your half like a joystick to drive. Tanks fire on their own every second, and shells bounce once. Keys: WASD and arrows.',
  sticks:true,
  init(){this.sc=[0,0];this.round();vsScore(0,0)},
  round(){this.tk=[{x:W/2,y:H-50,a:-Math.PI/2},{x:W/2,y:50,a:Math.PI/2}];this.b=[];this.t=0;this.pause=40},
  update(){if(this.pause>0){this.pause--;return}this.t++;
    this.tk.forEach((tk,i)=>{let s=padTB(i);
      if(i===1&&this.cpu){const o=this.tk[0],dx=o.x-tk.x,dy=o.y-tk.y;const want=Math.atan2(dy,dx)+Math.sin(this.t/50)*.9;s={x:Math.cos(want)*.8,y:Math.sin(want)*.8,on:1};
        if(inWall(tk.x+s.x*20,tk.y+s.y*20,14)){s={x:Math.cos(want+1.6)*.8,y:Math.sin(want+1.6)*.8}}}
      const m=hyp(s.x,s.y);if(m>.2){tk.a=Math.atan2(s.y,s.x);const nx=tk.x+s.x*2.4,ny=tk.y+s.y*2.4;if(!inWall(nx,tk.y,14))tk.x=nx;if(!inWall(tk.x,ny,14))tk.y=ny}
      if((this.t+i*30)%60===0){this.b.push({x:tk.x+Math.cos(tk.a)*20,y:tk.y+Math.sin(tk.a)*20,vx:Math.cos(tk.a)*5,vy:Math.sin(tk.a)*5,n:0,o:i,l:200});beep(220+i*40,.04,'square',.03)}});
    for(const b of this.b){b.l--;b.x+=b.vx;if(inWall(b.x,b.y,3)){b.x-=b.vx;b.vx*=-1;b.n++}b.y+=b.vy;if(inWall(b.x,b.y,3)){b.y-=b.vy;b.vy*=-1;b.n++}
      this.tk.forEach((tk,i)=>{if(b.l>0&&(i!==b.o||b.n>0)&&hyp(b.x-tk.x,b.y-tk.y)<15){b.l=0;const w=1-i;this.sc[w]++;vsScore(...this.sc);beep(120,.25,'sawtooth');
        if(this.sc[w]>=5)win(nm(w,this.cpu)+' WINS!',this.sc[0]+' to '+this.sc[1]);else this.round()}})}
    this.b=this.b.filter(b=>b.l>0&&b.n<2)},
  draw(){bg('#1a1712');for(let x=0;x<W;x+=40)for(let y=0;y<H;y+=40)R(x+19,y+19,2,2,'#2e2a20');for(const[a,b,w,h]of TW)R(a,b,w,h,'#5a4c36');bigScores(...this.sc);
    this.tk.forEach((tk,i)=>{g.save();g.translate(tk.x,tk.y);g.rotate(tk.a);R(-14,-12,28,24,i?P2C:P1C);R(0,-4,22,8,'#2b2b2b');C(0,0,7,'#ffffff66');g.restore()});
    for(const b of this.b)C(b.x,b.y,4,'#ffb627')},
  art(c){c.fillStyle='#5a4c36';c.fillRect(54,38,20,20);c.fillStyle='#5ab0ff';c.fillRect(20,64,22,18);c.fillStyle='#ff5d8f';c.fillRect(88,14,22,18);c.fillStyle='#ffb627';c.beginPath();c.arc(58,74,4,0,7);c.fill()}});

/* Four Up (connect four) */
add({id:'four',name:'FOUR UP',c:'--a1',cat:'2dv',modes:VS2,desc:'Drop discs and line up four in a row before your rival.',how:'Take turns tapping a column to drop a disc. Four in a row in any direction wins.',
  init(){this.b=Array.from({length:6},()=>Array(7).fill(0));this.turn=1;this.cw=0;this.last=null;vsScore('BLUE','TURN')},
  row(b,c){for(let r=5;r>=0;r--)if(!b[r][c])return r;return -1},
  won(b,p){for(let r=0;r<6;r++)for(let c=0;c<7;c++)if(b[r][c]===p)for(const[dr,dc]of[[0,1],[1,0],[1,1],[1,-1]]){let k=1;while(k<4&&b[r+dr*k]&&b[r+dr*k][c+dc*k]===p)k++;if(k===4)return true}return false},
  play(c){const r=this.row(this.b,c);if(r<0)return;this.b[r][c]=this.turn;this.last=[r,c];beep(this.turn===1?440:330,.06);
    if(this.won(this.b,this.turn))return win(nm(this.turn-1,this.cpu)+' WINS!');if(this.b[0].every(v=>v))return win('DRAW!','The board is full.');
    this.turn=3-this.turn;this.cw=30;vsScore(this.turn===1?'BLUE':nm(1,this.cpu),'TURN')},
  ai(){const b=this.b,ok=[0,1,2,3,4,5,6].filter(c=>this.row(b,c)>=0);
    for(const p of[2,1])for(const c of ok){const r=this.row(b,c);b[r][c]=p;const w=this.won(b,p);b[r][c]=0;if(w)return c}
    const safe=ok.filter(c=>{const r=this.row(b,c);b[r][c]=2;let bad=false;const r2=this.row(b,c);if(r2>=0){b[r2][c]=1;bad=this.won(b,1);b[r2][c]=0}b[r][c]=0;return!bad});
    const pool=safe.length?safe:ok;return pool.sort((a,b2)=>Math.abs(a-3)-Math.abs(b2-3)+rnd(-1.6,1.6))[0]},
  update(){if(this.cpu&&this.turn===2&&running&&--this.cw<=0)this.play(this.ai())},
  draw(){bg('#10142a');const s=48,ox=12,oy=150;R(ox-6,oy-6,s*7+12,s*6+12,'#2c3fa0');
    for(let r=0;r<6;r++)for(let c=0;c<7;c++){const v=this.b[r][c];C(ox+c*s+s/2,oy+r*s+s/2,19,v===1?P1C:v===2?P2C:'#10142a')}
    if(this.last)C(ox+this.last[1]*s+s/2,oy+this.last[0]*s+s/2,5,'#ffffffaa');
    T(this.turn===1?'BLUE TO PLAY':(this.cpu?'CPU THINKING...':'PINK TO PLAY'),W/2,110,this.turn===1?P1C:P2C,11)},
  down(p){if(this.cpu&&this.turn===2)return;const c=Math.floor((p.x-12)/48);if(c>=0&&c<7&&p.y>100)this.play(c)},
  art(c){c.fillStyle='#2c3fa0';c.fillRect(16,20,96,70);for(let r=0;r<3;r++)for(let k=0;k<4;k++){c.fillStyle=(r===2&&k<3)?'#5ab0ff':(r===1&&k===1)?'#ff5d8f':'#10142a';c.beginPath();c.arc(32+k*22,38+r*20,8,0,7);c.fill()}}});

/* Light Trails */
add({id:'trails',name:'LIGHT TRAILS',c:'--a5',cat:'2dv',modes:VS2,desc:'Leave a glowing wall behind you and trap your rival. Best of 5.',how:'Swipe in your half to turn (Blue bottom, Pink top). Do not hit any wall or trail. Keys: WASD and arrows.',
  init(){this.sc=[0,0];this.round();vsScore(0,0)},
  round(){this.gw=60;this.gh=90;this.gr=new Uint8Array(60*90);this.p=[{x:30,y:80,dx:0,dy:-1,nd:null},{x:30,y:9,dx:0,dy:1,nd:null}];this.t=0;this.pause=60;this.gr[80*60+30]=1;this.gr[9*60+30]=2},
  free(x,y){return x>=0&&y>=0&&x<60&&y<90&&!this.gr[y*60+x]},
  turn(i,dx,dy){const p=this.p[i];if(dx===-p.dx&&dy===-p.dy)return;p.nd=[dx,dy]},
  ai(){const p=this.p[1];const look=(dx,dy)=>{let n=0,x=p.x,y=p.y;while(n<14){x+=dx;y+=dy;if(!this.free(x,y))break;n++}return n};
    const opts=[[p.dx,p.dy],[p.dy,-p.dx],[-p.dy,p.dx]].map(d=>({d,v:look(...d)+Math.random()*2}));if(look(p.dx,p.dy)<3||Math.random()<.04){opts.sort((a,b)=>b.v-a.v);p.nd=opts[0].d}},
  update(){if(this.pause>0){this.pause--;return}this.t++;if(keys.KeyW)this.turn(0,0,-1);if(keys.KeyS)this.turn(0,0,1);if(keys.KeyA)this.turn(0,-1,0);if(keys.KeyD)this.turn(0,1,0);
    if(!this.cpu){if(keys.ArrowUp)this.turn(1,0,-1);if(keys.ArrowDown)this.turn(1,0,1);if(keys.ArrowLeft)this.turn(1,-1,0);if(keys.ArrowRight)this.turn(1,1,0)}
    if(this.t%Math.max(2,4-(this.t/600|0))!==0)return;if(this.cpu)this.ai();
    for(const p of this.p){if(p.nd){[p.dx,p.dy]=p.nd;p.nd=null}p.x+=p.dx;p.y+=p.dy}
    const a=this.p[0],b=this.p[1];let dead=[!this.free(a.x,a.y),!this.free(b.x,b.y)];if(a.x===b.x&&a.y===b.y)dead=[true,true];
    if(dead[0]||dead[1]){beep(120,.3,'sawtooth');if(dead[0]&&dead[1]){this.pause=60;return this.round()}const w=dead[0]?1:0;this.sc[w]++;vsScore(...this.sc);
      if(this.sc[w]>=3)return win(nm(w,this.cpu)+' WINS!',this.sc[0]+' to '+this.sc[1]);return this.round()}
    this.gr[a.y*60+a.x]=1;this.gr[b.y*60+b.x]=2},
  draw(){bg('#07060d');for(let x=0;x<W;x+=30)R(x,0,1,H,'#16132a');for(let y=0;y<H;y+=30)R(0,y,W,1,'#16132a');bigScores(...this.sc);
    for(let i=0;i<5400;i++)if(this.gr[i])R((i%60)*6,(i/60|0)*6,6,6,this.gr[i]===1?P1C:P2C);
    this.p.forEach((p,i)=>R(p.x*6-1,p.y*6-1,8,8,'#fff'));if(this.pause>0)T('GET READY',W/2,H/2,'#ffb627',12)},
  up(p){const dx=p.x-p.sxp,dy=p.y-p.syp;if(hyp(dx,dy)<14)return;const i=p.sy>=.5?0:1;if(i===1&&this.cpu)return;
    Math.abs(dx)>Math.abs(dy)?this.turn(i,Math.sign(dx),0):this.turn(i,0,Math.sign(dy))},
  art(c){c.fillStyle='#5ab0ff';c.fillRect(20,80,6,0);c.fillRect(20,40,6,46);c.fillRect(20,40,50,6);c.fillStyle='#ff5d8f';c.fillRect(100,10,6,40);c.fillRect(60,50,46,6)}});

/* Tug of War */
add({id:'tug',name:'TUG OF WAR',c:'--a3',cat:'2dv',modes:VS2,desc:'Tap like mad to drag the flag over your line.',how:'Tap your half of the screen as fast as you can after GO. Blue pulls down, Pink pulls up.',
  init(){this.r=0;this.cd=180;this.tp=[0,0];vsScore(0,0)},
  update(){if(this.cd>0){if(this.cd%60===0)beep(440,.1);this.cd--;if(this.cd===0)beep(880,.2);return}
    if(this.cpu&&Math.random()<.115){this.r-=.028;this.tp[1]++}
    this.r*=.999;if(this.r>=1)return win('BLUE WINS!',this.tp[0]+' taps');if(this.r<=-1)return win(nm(1,this.cpu)+' WINS!',this.tp[1]+' taps');vsScore(...this.tp)},
  draw(){bg('#1a1410');R(0,H/2,W,H/2,'#14223a');R(0,0,W,H/2,'#3a1424');R(0,60,W,4,P2C);R(0,H-64,W,4,P1C);
    const ky=H/2+this.r*(H/2-62);R(W/2-4,0,8,H,'#c9a46a');for(let y=10;y<H;y+=22)R(W/2-4,y,8,3,'#8a6a3a');R(W/2-26,ky-6,52,12,'#ffb627');
    if(this.cd>0){const n=Math.ceil(this.cd/60);T(String(n),W/2-80,H/2+12,'#f1eefa',28);TF(String(n),W/2+80,H/2-12,'#f1eefa',28)}
    else{T('TAP!',W/2-90,H*.78,P1C,16);TF('TAP!',W/2+90,H*.22,P2C,16)}},
  down(p){if(this.cd>0)return;if(p.ny>=.5){this.r+=.028;this.tp[0]++}else if(!this.cpu){this.r-=.028;this.tp[1]++}beep(300+Math.random()*200,.02,'square',.02)},
  key(k){if(this.cd>0)return;if(k==='KeyS'||k==='Space'){this.r+=.028;this.tp[0]++}if(k==='ArrowUp'&&!this.cpu){this.r-=.028;this.tp[1]++}},
  art(c){c.fillStyle='#c9a46a';c.fillRect(60,0,8,96);c.fillStyle='#ffb627';c.fillRect(46,40,36,10);c.fillStyle='#ff5d8f';c.fillRect(0,14,128,3);c.fillStyle='#5ab0ff';c.fillRect(0,80,128,3)}});

/* Quick Draw */
add({id:'draw',name:'QUICK DRAW',c:'--a1',cat:'2dv',desc:'Wait for the signal, then tap faster than your rival. First to 5.',how:'Both players hold a thumb near their half. When the screen flashes DRAW, tap. Tap early and your rival gets the point.',
  init(){this.sc=[0,0];this.newR();vsScore(0,0)},
  newR(){this.st='wait';this.tm=ri(100,280);this.msg=''},
  update(){if(this.st==='wait'&&--this.tm<=0){this.st='draw';this.t0=performance.now();beep(1000,.15,'square',.08)}
    else if(this.st==='res'&&--this.tm<=0){if(Math.max(...this.sc)>=5){const w=this.sc[0]>this.sc[1]?0:1;return win(nm(w)+' WINS!',this.sc[0]+' to '+this.sc[1])}this.newR()}},
  draw(){const d=this.st==='draw';bg(d?'#ffb627':'#140f0a');R(0,H/2-1,W,2,'#ffffff33');bigScores(...this.sc);
    const t=this.st==='wait'?'WAIT...':d?'DRAW!':this.msg;const c=d?'#111':'#f1eefa';T(t,W/2,H*.62,c,16);TF(t,W/2,H*.38,c,16)},
  down(p){const i=p.ny>=.5?0:1;if(this.st==='wait'){const w=1-i;this.sc[w]++;this.msg=nm(i)+' TOO EARLY';beep(150,.2,'sawtooth')}
    else if(this.st==='draw'){this.sc[i]++;this.msg=nm(i)+' '+Math.round(performance.now()-this.t0)+'MS';beep(700,.1)}else return;
    vsScore(...this.sc);this.st='res';this.tm=110},
  art(c){c.fillStyle='#ffb627';c.fillRect(0,0,128,96);c.fillStyle='#111';c.font='14px monospace';c.fillText('DRAW!',40,54)}});

/* Dot Boxes */
add({id:'boxes',name:'DOT BOXES',c:'--a2',cat:'2dv',modes:VS2,desc:'Draw lines between dots. Close a box to claim it and go again.',how:'Tap between two dots to draw a line. Finish the fourth side of a box to claim it and take another turn. Most boxes wins.',
  init(){this.h=Array.from({length:5},()=>Array(4).fill(0));this.v=Array.from({length:4},()=>Array(5).fill(0));this.bx=Array.from({length:4},()=>Array(4).fill(0));this.turn=1;this.cw=0;this.sc=[0,0];vsScore(0,0)},
  sides(r,c){return !!this.h[r][c]+!!this.h[r+1][c]+!!this.v[r][c]+!!this.v[r][c+1]},
  lines(){const o=[];for(let r=0;r<5;r++)for(let c=0;c<4;c++)if(!this.h[r][c])o.push(['h',r,c]);for(let r=0;r<4;r++)for(let c=0;c<5;c++)if(!this.v[r][c])o.push(['v',r,c]);return o},
  near(t,r,c){return t==='h'?[[r-1,c],[r,c]]:[[r,c-1],[r,c]]},
  take(t,r,c){(t==='h'?this.h:this.v)[r][c]=this.turn;let got=0;
    for(const[br,bc]of this.near(t,r,c))if(br>=0&&br<4&&bc>=0&&bc<4&&!this.bx[br][bc]&&this.sides(br,bc)===4){this.bx[br][bc]=this.turn;this.sc[this.turn-1]++;got++}
    beep(got?800:400,.05);vsScore(...this.sc);if(this.sc[0]+this.sc[1]===16){const[a,b]=this.sc;return win(a===b?'TIE GAME!':nm(a>b?0:1,this.cpu)+' WINS!',a+' boxes to '+b)}
    if(!got)this.turn=3-this.turn;this.cw=28},
  ai(){const L=this.lines();let best=null;
    for(const l of L){const[t,r,c]=l;let n=0;for(const[br,bc]of this.near(t,r,c))if(br>=0&&br<4&&bc>=0&&bc<4&&!this.bx[br][bc]&&this.sides(br,bc)===3)n++;if(n){best=l;break}}
    if(!best){const safe=L.filter(([t,r,c])=>this.near(t,r,c).every(([br,bc])=>!(br>=0&&br<4&&bc>=0&&bc<4)||this.sides(br,bc)<2));best=pick(safe.length?safe:L)}return best},
  update(){if(this.cpu&&this.turn===2&&--this.cw<=0){const l=this.ai();if(l)this.take(...l)}},
  draw(){bg('#0f1a16');const s=70,ox=40,oy=130;const col=v=>v===1?P1C:v===2?P2C:'#2a3a34';
    for(let r=0;r<4;r++)for(let c=0;c<4;c++)if(this.bx[r][c])R(ox+c*s+5,oy+r*s+5,s-10,s-10,(this.bx[r][c]===1?P1C:P2C)+'55');
    for(let r=0;r<5;r++)for(let c=0;c<4;c++)R(ox+c*s,oy+r*s-3,s,6,col(this.h[r][c]));
    for(let r=0;r<4;r++)for(let c=0;c<5;c++)R(ox+c*s-3,oy+r*s,6,s,col(this.v[r][c]));
    for(let r=0;r<5;r++)for(let c=0;c<5;c++)C(ox+c*s,oy+r*s,7,'#f1eefa');
    T(this.turn===1?'BLUE TO PLAY':(this.cpu?'CPU THINKING...':'PINK TO PLAY'),W/2,90,this.turn===1?P1C:P2C,11);T('BLUE '+this.sc[0]+'   '+nm(1,this.cpu)+' '+this.sc[1],W/2,470,'#9a93b5',10)},
  down(p){if(this.cpu&&this.turn===2)return;const s=70,ox=40,oy=130;let best=null,bd=26;
    for(const[t,r,c]of this.lines()){const mx=t==='h'?ox+c*s+s/2:ox+c*s,my=t==='h'?oy+r*s:oy+r*s+s/2,d=hyp(p.x-mx,p.y-my);if(d<bd){bd=d;best=[t,r,c]}}
    if(best)this.take(...best)},
  art(c){for(let r=0;r<3;r++)for(let k=0;k<4;k++){c.fillStyle='#f1eefa';c.fillRect(24+k*28,16+r*30,5,5)}c.fillStyle='#5ab0ff';c.fillRect(26,18,30,3);c.fillRect(26,18,3,30);c.fillRect(54,18,3,30);c.fillRect(26,46,30,3);c.fillStyle='#5ab0ff55';c.fillRect(30,22,22,22);c.fillStyle='#ff5d8f';c.fillRect(82,46,30,3)}});
