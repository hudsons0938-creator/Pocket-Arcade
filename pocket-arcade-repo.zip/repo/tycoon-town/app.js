/* Tycoon Town — game loop, UI, saving, leaderboard, live visits */
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pick=a=>a[Math.random()*a.length|0];
const fmtN=v=>v<10?v.toFixed(1):Math.round(v).toLocaleString();
const LS='tycoon_save_v1',MAXB=8;
let S=null,sel=0,tab='manage',started=false,visit=null,EV={},nextEv=0,lastTick=0,acc=0,hold=false,confirmK=null;
const NET={db:null,user:null,me:null,canWrite:null,rows:[],names:{},asked:{},status:'wait'};

/* ---------- saving ---------- */
function loadLocal(){try{return cleanSave(JSON.parse(localStorage.getItem(LS)))}catch(e){return null}}
function saveLocal(){if(!S)return;S.ts=Date.now();try{localStorage.setItem(LS,JSON.stringify(S))}catch(e){}}
let lastCloud=0,cloudT=0;
function cloudSave(force){if(!NET.db||!NET.me||NET.canWrite===false||!S||!started)return;const now=Date.now();if(!force&&now-lastCloud<15000)return;lastCloud=now;
  const E=empire(S,now);S.ts=now;const s=JSON.parse(JSON.stringify(S));s.biz.forEach(b=>delete b._L);
  NET.db.doc('players/'+NET.me).set({w:Math.round(E.worth),c:Math.round(S.cash),inc:Math.round(E.net),lim:Math.round(E.limit),ts:now,nb:S.biz.length,s}).then(()=>{NET.err=null},e=>{NET.err=(e&&e.code)||'error'})}
function markSave(){saveLocal();clearTimeout(cloudT);cloudT=setTimeout(()=>cloudSave(true),2500)}
async function netInit(){try{if(!(window.claude&&window.claude.use)){NET.status='off';return}
  const[db,user]=await Promise.all([window.claude.use('db'),window.claude.use('user')]);if(!db||!user){NET.status='off';return}
  NET.db=db;NET.user=user;NET.me=await user.id();if(!NET.me){NET.status='off';return}try{NET.canWrite=await user.can('data.write')}catch(e){NET.canWrite=null}NET.status='on';
  try{const d=await db.doc('players/'+NET.me).get();if(d.exists&&!started){const rs=cleanSave((d.data()||{}).s);if(rs&&(!S||rs.ts>S.ts+1000))S=rs}}catch(e){}
  db.collection('players').orderBy('w','desc').limit(100).onSnapshot(s=>{NET.rows=s.docs.map(d=>({id:d.id,d:d.data()||{}}));askNames(NET.rows.map(r=>r.id));if(tab==='ranks'&&!hold)renderBody()},e=>{NET.err=(e&&e.code)||'error'})}
  catch(e){NET.status='off'}}
function askNames(ids){const need=ids.filter(id=>!NET.asked[id]);if(!need.length||!NET.user)return;need.forEach(id=>NET.asked[id]=1);
  NET.user.profiles(need).then(ps=>{for(const id of need){const p=ps&&ps[id];NET.names[id]=(p&&p.name)||''}if(tab==='ranks'||visit)renderAll()}).catch(()=>{})}
const pName=id=>id===NET.me?'You':(NET.names[id]||'Tycoon');

/* ---------- leaderboard (others are projected forward with their offline earnings) ---------- */
function lbRows(){const now=Date.now(),out=[];for(const r of NET.rows){if(r.id===NET.me)continue;const d=r.d,w=+d.w,inc=+d.inc,ts=+d.ts,c=+d.c,lim=+d.lim;if(![w,inc,ts].every(Number.isFinite)||w>1e15)continue;
    const dt=Math.max(0,Math.min(1440,(now-ts)/60000));if(Number.isFinite(c)&&Number.isFinite(lim)&&c+inc*dt<-lim)continue;out.push({id:r.id,w:w+inc*dt,inc,nb:Math.max(0,Math.min(8,+d.nb||0)),ts})}
  if(S&&started){const E=empire(S);out.push({id:NET.me||'me',w:E.worth,inc:E.net,nb:S.biz.length,me:true})}return out.sort((a,b)=>b.w-a.w)}
function myRank(){if(NET.status!=='on')return'–';const i=lbRows().findIndex(r=>r.me);return i<0?'–':'#'+(i+1)}

/* ---------- economy tick (1 per second while open) ---------- */
const EVENTS=[
  {n:'Rush hour! Twice the customers for 45 seconds.',g:1,f:(b,now)=>{EV[b.id]={dem:2,until:now+45e3}}},
  {n:'Supplier sale! Stock 30% cheaper for a minute.',g:1,f:(b,now)=>{EV[b.id]={goods:.7,until:now+60e3}}},
  {n:'A review went viral! Reputation is up.',g:1,f:b=>{b.rep=Math.min(1.25,b.rep+.08)}},
  {n:'A celebrity stopped by! +60% customers for 30 seconds.',g:1,f:(b,now)=>{EV[b.id]={dem:1.6,until:now+30e3}}},
  {n:'health inspection',g:0,f:b=>{if(upLv(b,'decor')>=2)return-1;const f=Math.round(bizStats(b).rent*3);S.cash-=f;return f}},
  {n:'burst pipe',g:0,f:b=>{const c=Math.round(TBY[b.t].cost*.04);S.cash-=c;return c}}];
function randomEvent(now){nextEv=now+(90+Math.random()*120)*1e3;if(!S.biz.length)return;const b=pick(S.biz),e=pick(EVENTS),r=e.f(b,now),who=S.biz.length>1?esc(b.n)+': ':'';
  if(e.g)toast(who+e.n,'good');else toast(r<0?`${esc(b.n)} passed a health inspection. Nice clean store!`:`${who}A ${e.n} cost you ${fmt$(r)}.`,'bad')}
function econTick(){const now=Date.now();for(const b of S.biz){const ev=EV[b.id]&&EV[b.id].until>now?EV[b.id]:null,st=bizStats(b,ev,now);S.cash+=st.net/60;b.xp+=st.rev/60;
    const rmax=1.08+.05*upLv(b,'decor');if(st.demand>st.capacity*1.05)b.rep=Math.max(.6,b.rep-.0012*Math.min(3,st.demand/st.capacity));else b.rep=Math.min(rmax,b.rep+.0006);if(b.p>1.45)b.rep=Math.max(.6,b.rep-.0032*(b.p-1.45));
    const L=bizLevel(b);if(b._L&&L>b._L){toast(`⭐ ${esc(b.n)} reached level ${L}! Check Upgrades for new unlocks.`,'good')}b._L=L}
  if(S.loan.owed>0){const p=Math.min(S.loan.owed,S.loan.pay/60);S.loan.owed-=p;S.cash-=p;if(S.loan.owed<.01){S.loan.owed=0;S.loan.pay=0;toast('Loan paid off!','good')}}
  const E=empire(S,now);S.peak=Math.max(S.peak||0,E.worth);if(S.cash<-E.limit)return bankrupt('Your cash fell below −'+fmt$(E.limit)+', the most the bank would let you owe.');
  if(now>nextEv)randomEvent(now);if(now%5000<1000)saveLocal();cloudSave(false)}

/* ---------- flow ---------- */
function showStart(){const has=S&&S.biz.length;$('startBtns').innerHTML=has?`<button class="b gold" data-s="continue">CONTINUE</button><button class="b red" data-s="new">NEW GAME</button>`:`<button class="b gold" data-s="new">START</button>`;
  $('startMeta').textContent=has?`Net worth ${fmt$(empire(S).worth)} · ${S.biz.length} business${S.biz.length>1?'es':''}. Your shops kept earning while you were away.`:'Pick your first business, then grow it into an empire. Your shops keep earning while you are away.'}
$('startBtns').onclick=e=>{const b=e.target.closest('[data-s]');if(!b)return;if(b.dataset.s==='continue')continueGame();else if(S&&S.biz.length)modal(`<h2>Start over?</h2><p>Your current empire (worth ${fmt$(empire(S).worth)}) will be deleted and you leave the leaderboard.</p><div class="row"><button class="b red" data-m="wipe">DELETE AND START OVER</button><button class="b" data-m="close">KEEP PLAYING</button></div>`);else newGame()};
function newGame(){if(NET.db&&NET.me&&S&&S.biz.length)NET.db.doc('players/'+NET.me).delete().catch(()=>{});S=newSave();try{localStorage.removeItem(LS)}catch(e){}pickFirst()}
function pickFirst(){modal(`<h2>Pick your first business</h2><p>You have <b class="pos">${fmt$(S.cash)}</b>. Bigger businesses unlock as you get richer.</p><div class="cat">${TYPES.map(T=>{const ok=S.cash>=T.cost;return `<div class="ty"><span class="e">${T.e}</span><b>${T.name}</b><small>${fmt$(T.cost)} · about ${fmt$(bizStats(newBiz({nid:0},T.id)).net)}/min</small><button class="b sm ${ok?'green':''}" data-m="first:${T.id}" ${ok?'':'disabled'}>${ok?'CHOOSE':'🔒 '+fmt$(T.cost)}</button></div>`}).join('')}</div>`)}
function continueGame(){const away=(Date.now()-S.ts)/1000;let msg=null;
  if(away>30){const c0=S.cash,r=simulate(S,Math.min(away,86400),S.ts);if(r.bankrupt)return bankrupt('While you were away, your businesses lost money until the bank shut you down.');msg={away,earned:S.cash-c0}}
  begin();if(msg)modal(`<h2>${msg.earned>=0?'Welcome back!':'Uh oh…'}</h2><p>You were away for ${dur(msg.away)}${msg.away>86400?' (offline earnings count up to 24 hours)':''}.</p><p class="bigm ${msg.earned>=0?'pos':'neg'}">${msg.earned>=0?'+':''}${fmt$(msg.earned)}</p><p class="dim">${msg.earned>=0?'Your businesses kept earning while you were gone.':'Your empire lost money while you were away. Fix it before you go bankrupt.'}</p><button class="b gold" data-m="close">LET'S GO</button>`)}
const dur=s=>{s=Math.round(s);const h=s/3600|0,m=(s%3600)/60|0;return h?`${h}h ${m}m`:m?`${m} min`:`${s} sec`};
function begin(){started=true;lastTick=Date.now();nextEv=Date.now()+60e3;sel=Math.min(sel,Math.max(0,S.biz.length-1));$('start').hidden=true;$('hud').hidden=false;W3.orb.th=.6;W3.orb.ph=.8;fitTop();rebuild(true);renderAll();markSave()}
function bankrupt(why){started=false;$('hud').hidden=true;if(visit)stopVisit(true);const peak=S?S.peak:0;if(NET.db&&NET.me)NET.db.doc('players/'+NET.me).delete().catch(()=>{});try{localStorage.removeItem(LS)}catch(e){}
  S=newSave();modal(`<h2>💸 BANKRUPT</h2><p>${esc(why)}</p><p>Your empire is gone and so is your spot on the leaderboard. Best net worth this run: <b class="goldc">${fmt$(peak)}</b>.</p><p class="dim">Tip: keep profit per minute green, don't hire more staff than you need, and borrow carefully.</p><button class="b gold" data-m="restart">START OVER</button>`)}
function openBiz(t,name){const T=TBY[t];if(S.cash<T.cost||S.biz.length>=MAXB)return;S.cash-=T.cost;const b=newBiz(S,t,name||T.name);S.biz.push(b);sel=S.biz.length-1;if(!started)begin();else{rebuild(true);tab='manage';renderAll()}
  toast(`${T.e} ${esc(b.n)} is open for business!`,'good');markSave()}

/* ---------- actions ---------- */
function curB(){return visit?(visit.data&&visit.data.s.biz[visit.idx]):S&&S.biz[sel]}
function act(a){const b=S&&S.biz[sel],T=b&&TBY[b.t];const[k,v]=a.split(':');
  if(k==='tab'){tab=v;$('sheet').classList.remove('min');return renderAll()}
  if(k==='biz'){sel=+v;tab=tab==='empire'?'manage':tab;rebuild(true);return renderAll()}
  if(k==='vbiz'){visit.idx=+v;rebuild(true);return renderAll()}
  if(k==='grip'){$('sheet').classList.toggle('min');return renderTabs()}
  if(k==='view')return startVisit(v);
  if(k==='leave')return stopVisit();
  if(k==='open'){const TT=TBY[v];return modal(`<h2>${TT.e} Open a ${esc(TT.name)}</h2><p>Costs <b>${fmt$(TT.cost)}</b>. You have ${fmt$(S.cash)}.</p><form class="row" id="nameF"><input class="txt" id="bname" maxlength="24" value="${esc(TT.name)}" aria-label="Business name"><button class="b green" type="submit">OPEN IT</button></form><button class="b" data-m="close">CANCEL</button>`,()=>{$('nameF').onsubmit=e=>{e.preventDefault();closeModal();openBiz(v,$('bname').value.trim())};$('bname').select()})}
  if(k==='loan'){const E=empire(S),amt=Math.floor(E.loanMax*(+v));if(amt>=100){S.cash+=amt;S.loan.owed+=amt*1.2;S.loan.pay=S.loan.owed/45;toast(`Borrowed ${fmt$(amt)}. You'll repay ${fmt$(amt*1.2)} over 45 minutes.`);markSave()}return renderAll()}
  if(k==='repay'){if(S.cash>=S.loan.owed){S.cash-=S.loan.owed;S.loan.owed=0;S.loan.pay=0;toast('Loan repaid in full.','good');markSave()}return renderAll()}
  if(k==='restart'){if(confirmK!=='restart'){confirmK='restart';return renderBody()}confirmK=null;started=false;$('hud').hidden=true;$('start').hidden=false;W3.mode='orbit';renderCamBtn();newGame();return}
  if(k==='nope'){confirmK=null;return renderAll()}
  if(!b)return;
  if(k==='price'){b.p=Math.max(.5,Math.min(2,Math.round((b.p+(+v))*100)/100));markSave()}
  else if(k==='staff'){b.staff=Math.max(1,Math.min(maxStaff(b),b.staff+(+v)));rebuild(true);markSave()}
  else if(k==='up'){const g=UPG_GENERIC.find(x=>x.id===v),L=bizLevel(b);let cost,ok=false;
    if(g){const lv=upLv(b,v);if(lv<g.max&&L>=g.req[lv]){cost=g.cost(T,lv);ok=true}}else{const u=T.up.find(x=>x.id===v);if(u&&!upLv(b,v)&&L>=u.req){cost=T.cost*u.m;ok=true}}
    if(!ok||S.cash<cost)return;S.cash-=cost;b.spent+=cost;b.up[v]=upLv(b,v)+1;if(v==='size')b.staff=Math.min(b.staff,maxStaff(b));toast(`Upgrade bought: ${esc((g||T.up.find(x=>x.id===v)).name)}`,'good');rebuild(true);markSave()}
  else if(k==='rename')return modal(`<h2>Rename your business</h2><form class="row" id="nameF"><input class="txt" id="bname" maxlength="24" value="${esc(b.n)}" aria-label="Business name"><button class="b gold" type="submit">SAVE</button></form>`,()=>{$('nameF').onsubmit=e=>{e.preventDefault();const n=$('bname').value.trim().slice(0,24);if(n)b.n=n;closeModal();rebuild(true);renderAll();markSave()};$('bname').select()});
  else if(k==='sell'){if(confirmK!=='sell'){confirmK='sell';return renderBody()}confirmK=null;const val=bizValue(b);S.cash+=val;S.biz.splice(sel,1);sel=Math.max(0,sel-1);toast(`Sold ${esc(b.n)} for ${fmt$(val)}.`);if(!S.biz.length)tab='empire';rebuild(true);markSave()}
  renderAll()}
document.addEventListener('click',e=>{const el=e.target.closest('[data-a]');if(el&&!el.disabled&&el.closest('#hud'))act(el.dataset.a)});
$('rankBtn').onclick=()=>act('tab:ranks');
$('camBtn').onclick=()=>{W3.mode=W3.mode==='orbit'?'walk':'orbit';if(W3.mode==='walk'){resetWalk();if(innerWidth<900)$('sheet').classList.add('min')}renderCamBtn();renderTabs()};
$('recBtn').onclick=()=>{if(W3.mode==='walk')resetWalk();else{const o=W3.orb;o.tx=0;o.tz=0;o.th=.6;o.ph=.8;o.d=Math.max(18,14+5*upLv(curB()||{up:{}},'size'))}};
function renderCamBtn(){$('camBtn').textContent=W3.mode==='walk'?'🎥 OVERHEAD':'🚶 WALK IN';const h=$('walkHint');h.hidden=W3.mode!=='walk';h.textContent=matchMedia('(pointer:coarse)').matches?'Drag the left side to walk · drag the right side to look':'WASD or arrow keys to walk · drag to look around'}
const sheet=$('sheet');sheet.addEventListener('pointerdown',()=>hold=true);addEventListener('pointerup',()=>setTimeout(()=>hold=false,50));addEventListener('pointercancel',()=>hold=false);

/* ---------- modal + toasts ---------- */
function modal(html,after){$('mbox').innerHTML=html;$('modal').hidden=false;after&&after();const f=$('mbox').querySelector('button,input');f&&f.focus()}
function closeModal(){$('modal').hidden=true}
$('mbox').addEventListener('click',e=>{const el=e.target.closest('[data-m]');if(!el||el.disabled)return;const[k,v]=el.dataset.m.split(':');
  if(k==='close')return closeModal();
  if(k==='wipe'){closeModal();return newGame()}
  if(k==='restart'){closeModal();$('hud').hidden=true;$('start').hidden=false;W3.mode='orbit';renderCamBtn();return pickFirst()}
  if(k==='first'){const T=TBY[v];modal(`<h2>${T.e} Name your ${esc(T.name)}</h2><form class="row" id="nameF"><input class="txt" id="bname" maxlength="24" value="${esc(T.name)}" aria-label="Business name"><button class="b green" type="submit">OPEN IT</button></form><button class="b" data-m="back">BACK</button>`,()=>{$('nameF').onsubmit=ev=>{ev.preventDefault();closeModal();openBiz(v,$('bname').value.trim())};$('bname').select()})}
  if(k==='back')pickFirst()});
addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('modal').hidden&&started)closeModal()});
function toast(html,cls){const box=$('toasts');while(box.children.length>2)box.firstChild.remove();const d=document.createElement('div');d.className='toast '+(cls||'');d.innerHTML=html;box.appendChild(d);setTimeout(()=>d.remove(),4500)}

/* ---------- rendering ---------- */
function layout(){const sh=$('sheet'),wide=innerWidth>=900;if($('hud').hidden){W3.offX=0;W3.offY=0;return}const h=sh.offsetHeight;document.documentElement.style.setProperty('--sheetH',(wide?16:h+10)+'px');W3.offX=wide?sh.offsetWidth*.5:0;W3.offY=wide?0:(W3.mode==='walk'?0:h*.42)}
function fitTop(){document.documentElement.style.setProperty('--topH',($('top').offsetHeight+8)+'px')}
addEventListener('resize',()=>{fitTop();worldResize()});
function renderAll(){renderTop();renderBizbar();renderTabs();renderBody();renderVisit()}
function renderTop(){if(!S)return;const E=empire(S);$('hCash').textContent=fmt$(S.cash);$('hCash').className='num'+(S.cash<0?' neg':'');const n=$('hNet');n.textContent=(E.net>=0?'+':'')+fmt$(E.net);n.className='num '+(E.net>=0?'pos':'neg');$('hWorth').textContent=fmt$(E.worth);$('hRank').textContent=myRank()}
function renderBizbar(){const bb=$('bizbar');if(visit){bb.hidden=true;return}bb.hidden=false;bb.innerHTML=S.biz.map((b,i)=>`<button class="chip ${i===sel?'on':''}" data-a="biz:${i}">${TBY[b.t].e} ${esc(b.n)}</button>`).join('')+(S.biz.length<MAXB?`<button class="chip add" data-a="tab:empire">+ NEW BUSINESS</button>`:'')}
function renderTabs(){const T=visit?[['visit','THEIR STORE'],['ranks','RANKS']]:[['manage','MANAGE'],['upgrades','UPGRADES'],['empire','EMPIRE'],['bank','BANK'],['ranks','RANKS']];if(!T.some(t=>t[0]===tab))tab=T[0][0];
  $('tabs').innerHTML=T.map(([k,l])=>`<button class="tab ${tab===k?'on':''}" data-a="tab:${k}">${l}</button>`).join('')+`<button class="tab grip" data-a="grip" aria-label="Show or hide panel">${$('sheet').classList.contains('min')?'▲':'▼'}</button>`}
function renderBody(){if(!S)return;const f=document.activeElement,fa=f&&f.dataset&&f.dataset.a;const body=$('body');
  body.innerHTML=tab==='manage'?vManage():tab==='upgrades'?vUpgrades():tab==='empire'?vEmpire():tab==='bank'?vBank():tab==='ranks'?vRanks():vVisit();
  if(fa){const n=body.querySelector(`[data-a="${CSS.escape(fa)}"]`);n&&n.focus()}}
function trendTag(t){const m=trend(t,Date.now());return m>1.12?`<span class="pos">▲ Hot market ${m.toFixed(2)}x</span>`:m<.88?`<span class="neg">▼ Slow market ${m.toFixed(2)}x</span>`:`<span class="dim">Market steady ${m.toFixed(2)}x</span>`}
function statsCard(b,ro){const T=TBY[b.t],st=bizStats(b,EV[b.id]&&EV[b.id].until>Date.now()&&!ro?EV[b.id]:null),L=st.L,nx=nextLvXP(b),prev=T.cost*[0,.5,1.5,4,10,25,60,150,400,1000][L-1];
  return `<div class="card"><div class="row"><h3>${T.e} ${esc(b.n)}</h3>${ro?'':'<button class="b sm" data-a="rename">RENAME</button>'}</div>
    <div class="row dim"><span>${T.name} · Level ${L}</span>${trendTag(b.t)}</div><div class="bar"><i style="width:${nx?Math.min(100,(b.xp-prev)/(nx-prev)*100):100}%"></i></div>
    <div class="dim">${nx?`${fmt$(b.xp)} of ${fmt$(nx)} in sales to reach level ${L+1}`:'Top level reached'}</div></div>
  <div class="card"><h3>EVERY MINUTE</h3><div class="grid2">
    <div><span>Customers</span><b>${fmtN(st.served)}</b></div><div><span>Want to shop</span><b>${fmtN(st.demand)}</b></div>
    <div><span>Sales</span><b class="pos">+${fmt$(st.rev)}</b></div><div><span>Stock</span><b class="neg">−${fmt$(st.goods)}</b></div>
    <div><span>Rent</span><b class="neg">−${fmt$(st.rent)}</b></div><div><span>Wages</span><b class="neg">−${fmt$(st.wages)}</b></div>
    <div><span>Reputation</span><b>${Math.round(b.rep*100)}%</b></div><div><span>Profit</span><b class="${st.net>=0?'pos':'neg'}">${st.net>=0?'+':''}${fmt$(st.net)}</b></div></div></div>`+
  (ro?'':(st.net<0?`<div class="warn">This business is losing ${fmt$(-st.net)} every minute, even while you're away. Raise prices, cut staff, or upgrade.</div>`:'')+
    (st.demand>st.capacity*1.05?`<div class="warn">${fmtN(st.demand-st.capacity)} customers a minute walk out because the line is too long. Hire staff or raise prices. Long lines also hurt your reputation.</div>`:st.capacity>st.demand*1.5&&b.staff>1?`<div class="tip">You have more staff than customers need. Letting someone go saves ${fmt$(T.wage)}/min.</div>`:''))}
function vManage(){const b=S.biz[sel];if(!b)return`<div class="card"><h3>No businesses yet</h3><p class="dim">Open one from the Empire tab.</p><button class="b green" data-a="tab:empire">OPEN A BUSINESS</button></div>`;const T=TBY[b.t];
  return statsCard(b)+(!b.spent&&S.biz.length===1?`<div class="tip">Tip: buy upgrades to grow, keep profit green, and hire staff when customers are walking out. Your shops keep earning when you close the page.</div>`:'')+
  `<div class="card"><h3>PRICES</h3><div class="row"><div class="stepper"><button class="b sm" data-a="price:-0.05" aria-label="Lower prices">−</button><b>${b.p.toFixed(2)}x</b><button class="b sm" data-a="price:0.05" aria-label="Raise prices">+</button></div>
    <span class="dim" style="flex:1 1 180px">Higher prices earn more per sale but drive customers away. Most shops do best around 1.10x to 1.20x.</span></div></div>
  <div class="card"><h3>STAFF</h3><div class="row"><div class="stepper"><button class="b sm" data-a="staff:-1" aria-label="Let a worker go">−</button><b>${b.staff} / ${maxStaff(b)}</b><button class="b sm" data-a="staff:1" aria-label="Hire a worker" ${b.staff>=maxStaff(b)?'disabled':''}>+</button></div>
    <span class="dim" style="flex:1 1 180px">Each worker serves ${fmtN(T.cap*(1+.2*upLv(b,'train')+specMods(b).c))} customers a minute and costs ${fmt$(T.wage)}/min. Expand the store to make room for more.</span></div></div>
  <div class="row">${confirmK==='sell'?`<span class="dim">Sell ${esc(b.n)} for ${fmt$(bizValue(b))}?</span><button class="b red sm" data-a="sell">YES, SELL IT</button><button class="b sm" data-a="nope">NO</button>`:`<button class="b red sm" data-a="sell">SELL FOR ${fmt$(bizValue(b))}</button>`}</div>`}
function upRow(id,name,desc,lv,max,cost,req,L){const maxed=lv>=max,lock=!maxed&&L<req,can=!maxed&&!lock&&S.cash>=cost;
  return `<div class="up ${lock?'lock':''}"><h4>${esc(name)} ${max>1?`<span class="dim">${lv}/${max}</span>`:''}</h4><p>${esc(desc)}${lock?` · 🔒 Unlocks at level ${req}`:''}</p><button class="b sm ${can?'gold':''}" data-a="up:${id}" ${can?'':'disabled'}>${maxed?(max>1?'MAXED':'OWNED'):lock?'LOCKED':fmt$(cost)}</button></div>`}
function vUpgrades(){const b=S.biz[sel];if(!b)return vManage();const T=TBY[b.t],L=bizLevel(b);
  return `<div class="card"><h3>${T.e} ${esc(T.name).toUpperCase()} SPECIALS</h3>${T.up.map(u=>upRow(u.id,u.name,u.desc,upLv(b,u.id),1,T.cost*u.m,u.req,L)).join('')}</div>
    <div class="card"><h3>EVERY BUSINESS</h3>${UPG_GENERIC.map(g=>{const lv=upLv(b,g.id);return upRow(g.id,g.name,g.desc,lv,g.max,lv<g.max?g.cost(T,lv):0,g.req[Math.min(lv,g.max-1)],L)}).join('')}</div>`}
function vEmpire(){const E=empire(S);return `<div class="card"><h3>YOUR BUSINESSES · ${S.biz.length}/${MAXB}</h3>${S.biz.length?S.biz.map((b,i)=>{const st=bizStats(b);return `<div class="row"><span>${TBY[b.t].e} <b>${esc(b.n)}</b> <span class="dim">L${st.L}</span></span><span class="${st.net>=0?'pos':'neg'} num">${st.net>=0?'+':''}${fmt$(st.net)}/min</span><button class="b sm" data-a="biz:${i}">MANAGE</button></div>`}).join(''):'<p class="dim">None yet. Pick one below.</p>'}
    <div class="row dim"><span>Empire profit</span><b class="${E.net>=0?'pos':'neg'}">${E.net>=0?'+':''}${fmt$(E.net)}/min</b></div></div>
    <div class="card"><h3>OPEN A NEW BUSINESS</h3><p class="dim">Running several businesses grows your net worth faster, but every shop has rent and wages to cover.</p><div class="cat">${TYPES.map(T=>{const ok=S.cash>=T.cost&&S.biz.length<MAXB;
      return `<div class="ty"><span class="e">${T.e}</span><b>${T.name}</b><small>${fmt$(T.cost)} · about ${fmt$(bizStats(newBiz({nid:0},T.id)).net)}/min</small><button class="b sm ${ok?'green':''}" data-a="open:${T.id}" ${ok?'':'disabled'}>${S.biz.length>=MAXB?'MAX 8':ok?'OPEN':'NEED '+fmt$(T.cost)}</button></div>`}).join('')}</div></div>`}
function vBank(){const E=empire(S),lm=E.loanMax,risk=Math.max(0,Math.min(100,(-S.cash)/E.limit*100));
  return `<div class="card"><h3>YOUR MONEY</h3><div class="grid2"><div><span>Cash</span><b class="${S.cash>=0?'pos':'neg'}">${fmt$(S.cash)}</b></div><div><span>Business value</span><b>${fmt$(E.val)}</b></div><div><span>Loan owed</span><b class="${S.loan.owed?'neg':''}">${fmt$(S.loan.owed)}</b></div><div><span>Net worth</span><b class="goldc">${fmt$(E.worth)}</b></div></div></div>
  <div class="card"><h3>BANKRUPTCY LINE</h3><p class="dim">You go bankrupt if your cash drops below <b class="neg">−${fmt$(E.limit)}</b>. Going bankrupt deletes your empire and your leaderboard spot.</p><div class="bar"><i style="width:${risk}%;background:var(--red)"></i></div>
    ${E.net<0?`<div class="warn">Your empire is losing ${fmt$(-E.net)} a minute. At this rate you hit the line in ${dur(Math.max(0,(S.cash+E.limit)/-E.net*60))}, even if you close the page.</div>`:`<p class="dim">Profit is positive (${fmt$(E.net)}/min), so you're safe for now.</p>`}</div>
  <div class="card"><h3>BANK LOAN</h3>${S.loan.owed>0?`<p class="dim">You owe ${fmt$(S.loan.owed)}. ${fmt$(S.loan.pay)} comes out every minute (done in about ${dur(S.loan.owed/S.loan.pay*60)}).</p><button class="b sm" data-a="repay" ${S.cash>=S.loan.owed?'':'disabled'}>REPAY ALL NOW</button>`:'<p class="dim">No loan right now.</p>'}
    <p class="dim">Borrow cash now and repay 120% over 45 minutes. Loan payments count against your profit, so borrow only for something that earns more.</p>
    <div class="row">${[.25,.5,1].map(f=>`<button class="b sm" data-a="loan:${f}" ${lm*f>=100?'':'disabled'}>BORROW ${fmt$(Math.floor(lm*f))}</button>`).join('')}</div></div>
  <div class="card"><h3>START OVER</h3>${confirmK==='restart'?`<p class="dim">This deletes your empire and removes you from the leaderboard.</p><div class="row"><button class="b red sm" data-a="restart">YES, DELETE IT</button><button class="b sm" data-a="nope">CANCEL</button></div>`:`<button class="b red sm" data-a="restart">START A NEW EMPIRE</button>`}</div>`}
const initial=n=>esc((n||'?').trim().charAt(0).toUpperCase()||'?');
const hue=id=>{let h=0;for(const c of String(id))h=(h*31+c.charCodeAt(0))%360;return h};
function vRanks(){if(NET.status!=='on')return `<div class="card"><h3>WORLD LEADERBOARD</h3><p class="dim">${NET.status==='wait'?'Connecting…':'The world leaderboard appears when this page is opened in Claude while signed in. Your game still saves on this device.'}</p></div>`;
  const rows=lbRows().slice(0,50);return `<div class="card"><h3>🏆 RICHEST BUSINESSES IN THE WORLD</h3><p class="dim">Ranked by net worth, live. Players keep earning while offline, so their worth keeps ticking up. Going bankrupt removes you.</p>
    ${NET.canWrite===false?'<div class="warn">You can play and watch, but joining the leaderboard needs Contributor access to this page. Ask whoever shared it.</div>':''}
    <div class="lb">${rows.length?rows.map((r,i)=>`<div class="lr ${r.me?'me':''}"><span class="rk">${['🥇','🥈','🥉'][i]||i+1}</span><span style="width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;background:hsl(${hue(r.id)} 55% 38%)">${initial(r.me?'You':pName(r.id))}</span>
      <span class="nm"><b>${esc(r.me?'You':pName(r.id))}</b><small>${r.nb} business${r.nb===1?'':'es'} · ${r.inc>=0?'+':''}${fmt$(r.inc)}/min</small></span><span class="row" style="gap:6px;flex-wrap:nowrap"><span class="w num">${fmt$(r.w)}</span>${r.me?'':`<button class="b sm" data-a="view:${esc(r.id)}">VIEW</button>`}</span></div>`).join(''):'<p class="dim">No one is on the board yet. Open a business and you will be first.</p>'}</div></div>`}

/* ---------- visiting another player's empire, live ---------- */
function startVisit(id){if(!NET.db||!/^[A-Za-z0-9_-]{1,200}$/.test(id))return;if(visit)stopVisit(true);visit={id,data:null,idx:0,unsub:null};tab='visit';
  if(W3.mode==='walk'){W3.mode='orbit';renderCamBtn()}
  visit.unsub=NET.db.doc('players/'+id).onSnapshot(d=>{if(!visit||visit.id!==id)return;if(!d.exists){toast('That empire is gone. They went bankrupt.','bad');return stopVisit()}const o=d.data()||{},s=cleanSave(o.s);
    if(!s||!s.biz.length){toast('They have no businesses open right now.');return stopVisit()}visit.data={s,w:+o.w||0,inc:+o.inc||0,ts:+o.ts||Date.now()};visit.idx=Math.min(visit.idx,s.biz.length-1);rebuild();renderAll()},
    ()=>{toast('Could not open that empire.','bad');stopVisit()});askNames([id]);renderAll()}
function stopVisit(quiet){if(!visit)return;try{visit.unsub&&visit.unsub()}catch(e){}visit=null;tab='ranks';if(!quiet){rebuild(true);renderAll()}}
function renderVisit(){const v=$('visit');if(!visit){v.hidden=true;return}v.hidden=false;const d=visit.data;
  if(!d){v.innerHTML=`<span class="live">LIVE</span><span>Opening ${esc(pName(visit.id))}'s empire…</span><button class="b sm" data-a="leave">BACK</button>`;return}
  const dt=Math.max(0,Math.min(1440,(Date.now()-d.ts)/60000)),w=d.w+d.inc*dt;
  v.innerHTML=`<span class="live">LIVE</span><span>Visiting <b>${esc(pName(visit.id))}</b> · worth <b class="num">${fmt$(w)}</b> · ${d.inc>=0?'+':''}${fmt$(d.inc)}/min</span>
    <span class="row" style="gap:6px">${d.s.biz.map((b,i)=>`<button class="chip ${i===visit.idx?'on':''}" data-a="vbiz:${i}">${TBY[b.t].e} ${esc(b.n)}</button>`).join('')}</span><button class="b sm gold" data-a="leave">BACK TO MY EMPIRE</button>`}
function vVisit(){if(!visit||!visit.data)return'<div class="card"><p class="dim">Loading their store…</p></div>';const b=visit.data.s.biz[visit.idx];const last=(Date.now()-visit.data.ts)/1000;
  return `<div class="card"><h3>👀 Visiting ${esc(pName(visit.id))}</h3><p class="dim">${last<60?'They are playing right now. Changes show up here as they happen.':'Last active '+dur(last)+' ago. Their shops are still open and earning.'}</p></div>`+statsCard(b,true)+
    `<div class="card"><h3>UPGRADES THEY OWN</h3><p class="dim">${[...UPG_GENERIC.map(g=>upLv(b,g.id)?`${g.name} ${upLv(b,g.id)}`:''),...TBY[b.t].up.map(u=>upLv(b,u.id)?u.name:'')].filter(Boolean).map(esc).join(' · ')||'None yet'}</p></div>`}

/* ---------- 3D sync ---------- */
function rebuild(force){const b=curB();if(!b)return;const key=(visit?visit.id:'me')+JSON.stringify([b.id,b.t,b.n,b.staff,b.up]);if(!force&&key===W3.key)return;W3.key=key;buildStore(b)}
const joy=$('joy');function joyUI(){const j=W3.mode==='walk'?walkJoy():null;if(!j){joy.hidden=true;return}joy.hidden=false;joy.style.left=j.sx+'px';joy.style.top=j.sy+'px';const dx=j.cx-j.sx,dy=j.cy-j.sy,d=Math.hypot(dx,dy),m=d>30?30/d:1;joy.firstChild.style.transform=`translate(${dx*m}px,${dy*m}px)`}

/* ---------- main loop ---------- */
let lt=0,lh=0,lb=0;
function loop(t){requestAnimationFrame(loop);const dt=Math.min(.1,(t-(lt||t))/1000);lt=t;
  if(started){const wall=Date.now();if(wall-lastTick>5000){const gap=(wall-lastTick)/1000,c0=S.cash,r=simulate(S,Math.min(gap,86400),lastTick);lastTick=wall;acc=0;
      if(r.bankrupt){bankrupt('While the page was in the background, your empire ran out of money.');return}if(gap>60)toast(`While you were gone: ${S.cash-c0>=0?'+':''}${fmt$(S.cash-c0)}`,S.cash>=c0?'good':'bad')}
    acc+=dt;while(acc>=1&&started){acc-=1;econTick();lastTick=Date.now()}
    if(t-lh>250){lh=t;renderTop();renderVisit();layout()}if(t-lb>1000){lb=t;if(!hold&&!(document.activeElement&&document.activeElement.tagName==='INPUT'))renderBody()}}
  else W3.orb.th+=dt*.07;
  const b=curB()||W3.demo;if(b&&W3.info){const st=bizStats(b);const ratio=Math.max(.05,st.served/TBY[b.t].cust);worldTick(dt,Math.max(.6,Math.min(7,4.5/ratio)))}
  camUpdate(dt);joyUI();worldRender()}
document.addEventListener('visibilitychange',()=>{if(document.hidden&&started){saveLocal();cloudSave(true)}});
addEventListener('pagehide',()=>{if(started){saveLocal();cloudSave(true)}});

/* ---------- boot ---------- */
(async function boot(){worldInit($('view'));W3.demo={id:7,t:'coffee',n:'Tycoon Town',staff:3,p:1,up:{size:1,ads:3,decor:2,esp:1,pas:1},xp:0,rep:1,spent:0};buildStore(W3.demo);W3.orb.d=26;
  requestAnimationFrame(loop);S=loadLocal();$('startBtns').innerHTML='<button class="b" disabled>LOADING…</button>';
  await Promise.race([netInit(),new Promise(r=>setTimeout(r,2500))]);if(!S)S=newSave();showStart()})();
