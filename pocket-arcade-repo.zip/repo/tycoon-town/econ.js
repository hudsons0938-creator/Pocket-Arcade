/* Tycoon Town — catalog + economy (all money per minute unless noted) */
const UPG_GENERIC=[
  {id:'ads',name:'Advertising',desc:'+12% customers per level',max:5,req:[1,1,2,3,4],cost:(T,k)=>T.cost*.25*Math.pow(1.9,k)},
  {id:'decor',name:'Nicer interior',desc:'+8% customers, better reputation',max:3,req:[1,2,4],cost:(T,k)=>T.cost*.3*Math.pow(2,k)},
  {id:'train',name:'Staff training',desc:'+20% customers served per worker',max:3,req:[2,3,5],cost:(T,k)=>T.cost*.35*Math.pow(2,k)},
  {id:'size',name:'Expand the store',desc:'Bigger building: +60% demand, more staff room, higher rent',max:3,req:[2,4,6],cost:(T,k)=>T.cost*[1.2,3,7][k]},
  {id:'sup',name:'Better suppliers',desc:'Stock costs 8% less per level',max:3,req:[3,4,6],cost:(T,k)=>T.cost*.45*Math.pow(2.2,k)},
  {id:'fran',name:'Franchise branches',desc:'+25% customers and +2 staff room per level',max:10,req:[3,4,5,6,7,8,9,10,10,10],cost:(T,k)=>T.cost*2*Math.pow(2.6,k)}];
/* type-specific one-time upgrades: a=appeal, k=ticket, c=capacity, g=goods cost multiplier, fx=fixtures added */
const TYPES=[
 {id:'coffee',name:'Coffee Shop',e:'☕',cost:3000,ticket:6,cogs:.3,s0:2,cell:2.4,wall:0x8a5a3c,floor:0xd9c4a6,acc:'#f3c98b',pal:[0x6b3e26,0x9c6b48,0xe8d5b5,0x3d2416],fx:['table','shelf','table','plant','table','display','table'],
  up:[{id:'esp',name:'Espresso bar',desc:'+15% spend per customer',m:.8,req:2,k:.15,fx:['counter']},{id:'pas',name:'Pastry case',desc:'+12% customers',m:1.2,req:3,a:.12,fx:['display']},{id:'drv',name:'Drive-thru window',desc:'+20% customers, +15% served',m:3,req:5,a:.2,c:.15,fx:['plant']}]},
 {id:'games',name:'Game Store',e:'🎮',cost:4000,ticket:45,cogs:.55,s0:2,cell:2.6,wall:0x2a2d5a,floor:0x30344a,acc:'#7cf7ff',pal:[0xff4d6d,0x4dd2ff,0xffd166,0x8aff80,0xb388ff],fx:['shelf','display','shelf','tv','display','shelf','plant'],
  up:[{id:'arc',name:'Arcade cabinets',desc:'+18% customers',m:1,req:2,a:.18,fx:['arcade','arcade','arcade']},{id:'demo',name:'Console demo stations',desc:'+12% spend',m:1.5,req:3,k:.12,fx:['tv','tv']},{id:'vault',name:"Collector's vault",desc:'+25% spend on rare games',m:4,req:5,k:.25,fx:['case']}]},
 {id:'bakery',name:'Bakery',e:'🥐',cost:3500,ticket:9,cogs:.35,s0:2,cell:2.4,wall:0xc98b6b,floor:0xf0e0c8,acc:'#ffd9a8',pal:[0xd99a4e,0xf2d29b,0x8b4a2b,0xffffff],fx:['oven','display','shelf','table','display','table'],
  up:[{id:'cake',name:'Wedding cakes',desc:'+20% spend',m:1.2,req:3,k:.2,fx:['display']},{id:'oven2',name:'Bigger ovens',desc:'+20% served',m:1,req:2,c:.2,fx:['oven']},{id:'cafe',name:'Café seating',desc:'+15% customers',m:1.6,req:4,a:.15,fx:['table','table']}]},
 {id:'flowers',name:'Flower Shop',e:'💐',cost:2500,ticket:28,cogs:.45,s0:1,cell:2.2,wall:0x4f8a5b,floor:0xe8efe0,acc:'#ff9ecf',pal:[0xff4f8b,0xffd23f,0xff8a3d,0xb26bff,0xffffff],fx:['bucket','bucket','plant','display','bucket','plant'],
  up:[{id:'wed',name:'Wedding contracts',desc:'+25% spend',m:1.5,req:3,k:.25},{id:'green',name:'Greenhouse',desc:'+15% customers',m:1,req:2,a:.15,fx:['plant','plant','plant']},{id:'deliv',name:'Same-day delivery',desc:'+20% customers',m:2.5,req:4,a:.2}]},
 {id:'pizza',name:'Pizza Place',e:'🍕',cost:5000,ticket:18,cogs:.32,s0:2,cell:2.5,wall:0xb33a2b,floor:0xe9e1d0,acc:'#ffd166',pal:[0xd94b2b,0xffd166,0x3c8d40],fx:['oven','table','table','table','table','plant'],
  up:[{id:'bike',name:'Delivery bikes',desc:'+20% customers',m:1,req:2,a:.2},{id:'wood',name:'Wood-fired oven',desc:'+15% spend',m:1.4,req:3,k:.15,fx:['oven']},{id:'party',name:'Party room',desc:'+15% customers, +10% spend',m:3,req:5,a:.15,k:.1,fx:['table','table','table']}]},
 {id:'books',name:'Bookstore',e:'📚',cost:5000,ticket:22,cogs:.55,s0:2,cell:2.4,wall:0x3f5a46,floor:0x8a6a4a,acc:'#f1e3c3',pal:[0x8b2e2e,0x2e4a8b,0x2e8b57,0xc9a227,0x6b4a8b],fx:['bookcase','bookcase','table','bookcase','plant','bookcase'],
  up:[{id:'sign',name:'Author signings',desc:'+18% customers',m:1,req:2,a:.18},{id:'bcafe',name:'Café corner',desc:'+12% spend',m:1.3,req:3,k:.12,fx:['table']},{id:'rare',name:'Rare editions',desc:'+25% spend',m:3.5,req:5,k:.25,fx:['case']}]},
 {id:'pets',name:'Pet Shop',e:'🐶',cost:6000,ticket:40,cogs:.5,s0:2,cell:2.5,wall:0x3a7ca5,floor:0xe2ecef,acc:'#ffe08a',pal:[0xff9f1c,0x2ec4b6,0xe71d36,0xfdfffc],fx:['cage','tank','shelf','cage','shelf','plant'],
  up:[{id:'groom',name:'Grooming salon',desc:'+15% spend',m:1.2,req:2,k:.15},{id:'aqua',name:'Aquarium wall',desc:'+15% customers',m:1.4,req:3,a:.15,fx:['tank','tank']},{id:'vet',name:'Vet clinic',desc:'+20% customers, +10% spend',m:3.5,req:5,a:.2,k:.1}]},
 {id:'toys',name:'Toy Store',e:'🧸',cost:7000,ticket:30,cogs:.5,s0:2,cell:2.5,wall:0xf28c28,floor:0xfff3d6,acc:'#6be3ff',pal:[0xff595e,0xffca3a,0x8ac926,0x1982c4,0x6a4c93],fx:['shelf','display','shelf','display','plant','shelf'],
  up:[{id:'play',name:'Play area',desc:'+18% customers',m:1,req:2,a:.18,fx:['display']},{id:'bear',name:'Build-a-plush bar',desc:'+15% spend',m:1.5,req:3,k:.15,fx:['counter']},{id:'imp',name:'Exclusive imports',desc:'+25% spend',m:3.5,req:5,k:.25}]},
 {id:'clothes',name:'Clothing Boutique',e:'👕',cost:8000,ticket:55,cogs:.45,s0:2,cell:2.4,wall:0xe9e4f0,floor:0xc9b8a8,acc:'#ff7aa2',pal:[0x222222,0xff7aa2,0x5aa9e6,0xf5f5f5,0xc0a060],fx:['rack','rack','display','rack','plant','rack'],
  up:[{id:'des',name:'Designer line',desc:'+25% spend',m:1.6,req:3,k:.25},{id:'tail',name:'Tailor station',desc:'+15% served',m:1,req:2,c:.15,fx:['counter']},{id:'snk',name:'Sneaker wall',desc:'+18% customers',m:2.5,req:4,a:.18,fx:['shelf','shelf']}]},
 {id:'burger',name:'Burger Joint',e:'🍔',cost:9000,ticket:12,cogs:.33,s0:3,cell:2.4,wall:0xd62828,floor:0xf7f1e3,acc:'#fcbf49',pal:[0xfcbf49,0xd62828,0x6a994e],fx:['oven','table','table','table','table','plant'],
  up:[{id:'dthru',name:'Drive-thru',desc:'+25% customers',m:1.2,req:2,a:.25},{id:'shake',name:'Milkshake bar',desc:'+12% spend',m:1,req:3,k:.12,fx:['counter']},{id:'h24',name:'Open 24 hours',desc:'+30% customers',m:3,req:5,a:.3}]},
 {id:'grocery',name:'Grocery Store',e:'🛒',cost:12000,ticket:38,cogs:.72,s0:3,cell:2.6,wall:0x2f7d4f,floor:0xeeeeea,acc:'#b5f2c8',pal:[0xe63946,0xf4a261,0x2a9d8f,0xe9c46a,0x264653,0xffffff],fx:['shelf','shelf','fridge','shelf','bucket','fridge','shelf'],
  up:[{id:'org',name:'Organic section',desc:'+15% spend',m:1,req:2,k:.15,fx:['bucket','bucket']},{id:'gbake',name:'In-store bakery',desc:'+12% customers',m:1.3,req:3,a:.12,fx:['oven']},{id:'self',name:'Self-checkout',desc:'+30% served',m:2,req:4,c:.3,fx:['counter']},{id:'home',name:'Home delivery',desc:'+20% customers',m:3.5,req:6,a:.2}]},
 {id:'gym',name:'Fitness Gym',e:'🏋️',cost:15000,ticket:35,cogs:.12,s0:2,cell:2.6,wall:0x1d1f24,floor:0x3a3d44,acc:'#ff3b3b',pal:[0x111111,0xff3b3b,0xcccccc],fx:['gym','gym','gym','gym','plant','gym'],
  up:[{id:'smoo',name:'Smoothie bar',desc:'+12% spend',m:.8,req:2,k:.12,fx:['counter']},{id:'pt',name:'Personal trainers',desc:'+25% spend',m:1.5,req:3,k:.25},{id:'spa',name:'Sauna & spa',desc:'+20% customers',m:3,req:5,a:.2}]},
 {id:'tech',name:'Electronics Store',e:'📺',cost:20000,ticket:160,cogs:.75,s0:3,cell:2.6,wall:0x101820,floor:0xdfe3e8,acc:'#4cc9f0',pal:[0x111111,0x4cc9f0,0xf72585,0xcccccc],fx:['tv','display','tv','shelf','display','tv'],
  up:[{id:'rep',name:'Phone repair desk',desc:'+15% served',m:1,req:2,c:.15,fx:['counter']},{id:'vr',name:'VR demo zone',desc:'+18% customers',m:1.5,req:3,a:.18,fx:['display']},{id:'smart',name:'Smart home showroom',desc:'+20% spend',m:3,req:5,k:.2,fx:['tv','tv']}]},
 {id:'gas',name:'Gas Station',e:'⛽',cost:30000,ticket:45,cogs:.82,s0:2,cell:2.4,wall:0xe0e0e0,floor:0xd0d0d0,acc:'#ff6b35',pal:[0xff6b35,0x004e89,0xffd23f,0x1a936f],fx:['shelf','fridge','shelf','fridge'],out:'pump',
  up:[{id:'wash',name:'Car wash',desc:'+20% spend',m:1,req:2,k:.2},{id:'conv',name:'Bigger mini-mart',desc:'+15% customers',m:1.2,req:3,a:.15,fx:['shelf','fridge']},{id:'ev',name:'EV chargers',desc:'+25% customers',m:3,req:5,a:.25}]},
 {id:'jewel',name:'Jewelry Store',e:'💎',cost:45000,ticket:600,cogs:.55,s0:2,cell:2.4,wall:0x1c1c2e,floor:0xf3eee6,acc:'#ffd700',pal:[0xffd700,0xe0e0ff,0xff4f8b,0x4fd1ff],fx:['case','case','plant','case','case'],
  up:[{id:'cust',name:'Custom design studio',desc:'+20% spend',m:1,req:2,k:.2},{id:'celeb',name:'Celebrity endorsement',desc:'+25% customers',m:2,req:4,a:.25},{id:'dvault',name:'Diamond vault',desc:'+30% spend',m:4,req:6,k:.3,fx:['case','case']}]},
 {id:'cars',name:'Car Dealership',e:'🚗',cost:120000,ticket:32000,cogs:.88,s0:3,cell:4.2,wall:0xf2f2f2,floor:0xbfc6cc,acc:'#e63946',pal:[0xe63946,0x1d3557,0xf1faee,0x111111,0xffb703],fx:['car','car','car','plant','car'],out:'car',
  up:[{id:'sport',name:'Sports cars',desc:'+20% spend',m:1,req:2,k:.2,fx:['car']},{id:'serv',name:'Service center',desc:'+15% customers',m:1.4,req:3,a:.15},{id:'evl',name:'EV lineup',desc:'+25% customers',m:3,req:5,a:.25,fx:['car']}]},
 {id:'cinema',name:'Movie Theater',e:'🎬',cost:250000,ticket:22,cogs:.25,s0:4,cell:2.6,wall:0x3a0d1f,floor:0x5a1a2a,acc:'#ffcf56',pal:[0x8b0000,0xffcf56],fx:['seats','seats','seats','seats','seats'],big:'screen',
  up:[{id:'imax',name:'Giant screen',desc:'+25% spend',m:1,req:2,k:.25},{id:'snack',name:'Gourmet snacks',desc:'+15% spend',m:1.2,req:3,k:.15,fx:['counter']},{id:'prem',name:'Premiere nights',desc:'+30% customers',m:3.5,req:5,a:.3}]}];
const TBY={};TYPES.forEach(T=>{TBY[T.id]=T;
  const roi=8*Math.pow(T.cost/3000,.22),N0=T.cost/roi;T.rent=N0*.18;T.wage=N0*.1;const margin=T.ticket*(1-T.cogs);
  T.cust=(N0+T.rent+T.s0*T.wage)/margin;T.cap=T.cust*1.15/T.s0;T.el=Math.max(1.2,Math.min(5,1.15/(1.15-T.cogs)))});
const LVX=[0,.5,1.5,4,10,25,60,150,400,1000];
const bizLevel=b=>{const T=TBY[b.t];let L=1;for(let i=1;i<LVX.length;i++)if(b.xp>=T.cost*LVX[i])L=i+1;return L};
const nextLvXP=b=>{const L=bizLevel(b);return L>=LVX.length?null:TBY[b.t].cost*LVX[L]};
function upLv(b,id){return(b.up&&+b.up[id])||0}
function specMods(b){const T=TBY[b.t];let a=0,k=0,c=0,g=1;for(const u of T.up)if(upLv(b,u.id)){a+=u.a||0;k+=u.k||0;c+=u.c||0;g*=u.g||1}return{a,k,c,g}}
function maxStaff(b){return TBY[b.t].s0+3+3*upLv(b,'size')+2*upLv(b,'fran')}
/* market trend: each type has slow hot and cold cycles (2 to 6 hours), the same for every player */
function trend(t,now){const T=TBY[t];const P=(2+T.cost%5)*3600e3,ph=(T.cost*7919%1000)/1000*6.283;return 1+.3*Math.sin(now/P*6.283+ph)}
/* ev: active event multipliers {dem, goods} */
function bizStats(b,ev,now){now=now||Date.now();const T=TBY[b.t],L=bizLevel(b),sp=specMods(b),size=1+.6*upLv(b,'size');
  const appeal=(1+.12*upLv(b,'ads')+.08*upLv(b,'decor')+.25*upLv(b,'fran')+sp.a)*(1+.03*(L-1)),tr=trend(b.t,now);
  const pF=Math.min(1.8,Math.pow(b.p,-T.el));
  const demand=T.cust*size*appeal*pF*b.rep*tr*((ev&&ev.dem)||1);
  const capacity=b.staff*T.cap*(1+.2*upLv(b,'train')+sp.c);
  const served=Math.min(demand,capacity);
  const rev=served*T.ticket*(1+sp.k)*b.p;
  const goods=served*T.ticket*T.cogs*Math.pow(.92,upLv(b,'sup'))*sp.g*((ev&&ev.goods)||1);
  const rent=T.rent*size*(1+.12*(L-1))*(1+.15*upLv(b,'fran')),wages=b.staff*T.wage;
  return{L,demand,capacity,served,rev,goods,rent,wages,net:rev-goods-rent-wages,size,appeal,tr}}
const bizValue=b=>TBY[b.t].cost*.5+(b.spent||0)*.35;
function empire(S,now){let net=0,val=0;for(const b of S.biz){net+=bizStats(b,null,now).net;val+=bizValue(b)}const loanPay=S.loan.owed>0?S.loan.pay:0;
  return{net:net-loanPay,bizNet:net,val,worth:S.cash+val-S.loan.owed,limit:500+.2*val,loanMax:Math.max(0,1000+.5*val-S.loan.owed*.8)}}
function newSave(){return{v:1,cash:5000,loan:{owed:0,pay:0},biz:[],ts:Date.now(),born:Date.now(),nid:1,peak:5000}}
function newBiz(S,t,name){const T=TBY[t];return{id:S.nid++,t,n:(name||T.name).slice(0,24),staff:T.s0,p:1,up:{},xp:0,rep:1,spent:0}}
/* advance the empire by dt seconds with no events (offline). Returns {earned, bankrupt} */
function simulate(S,dt,from){from=from||Date.now()-dt*1000;let earned=0;const step=Math.min(dt,120);for(let t=0;t<dt-1e-9;t+=step){const d=Math.min(step,dt-t),per=d/60,now=from+(t+d/2)*1000;for(const b of S.biz){const s=bizStats(b,null,now);earned+=s.net*per;b.xp+=s.rev*per}}
  let lp=0;if(S.loan.owed>0&&S.loan.pay>0){const tPay=Math.min(dt,S.loan.owed/S.loan.pay*60);lp=S.loan.pay*tPay/60;S.loan.owed=Math.max(0,S.loan.owed-lp);if(S.loan.owed<.01){S.loan.owed=0;S.loan.pay=0}}
  S.cash+=earned-lp;const E=empire(S);S.peak=Math.max(S.peak||0,E.worth);return{earned:earned-lp,bankrupt:S.cash<-E.limit}}
function cleanSave(o){/* validate untrusted/old data */if(!o||typeof o!=='object')return null;const n=x=>Number.isFinite(+x)?+x:0;
  const S={v:1,cash:n(o.cash),loan:{owed:Math.max(0,n(o.loan&&o.loan.owed)),pay:Math.max(0,n(o.loan&&o.loan.pay))},ts:n(o.ts)||Date.now(),born:n(o.born)||Date.now(),nid:Math.max(1,n(o.nid)),peak:n(o.peak),biz:[]};
  if(Array.isArray(o.biz))for(const b of o.biz.slice(0,8)){if(!b||!TBY[b.t])continue;const T=TBY[b.t];const up={};
    for(const g of UPG_GENERIC)up[g.id]=Math.max(0,Math.min(g.max,Math.floor(n(b.up&&b.up[g.id]))));for(const u of T.up)up[u.id]=n(b.up&&b.up[u.id])?1:0;
    S.biz.push({id:n(b.id)||S.nid++,t:b.t,n:String(b.n||T.name).replace(/[\u0000-\u001f\u007f-\u009f​-‏‪-‮⁦-⁩]/g,'').slice(0,24)||T.name,staff:Math.max(1,Math.min(maxStaff({t:b.t,up}),Math.floor(n(b.staff))||T.s0)),
      p:Math.max(.5,Math.min(2,n(b.p)||1)),up,xp:Math.max(0,n(b.xp)),rep:Math.max(.6,Math.min(1.4,n(b.rep)||1)),spent:Math.max(0,n(b.spent))})}
  return S}
const fmt$=v=>{const a=Math.abs(v),s=v<0?'-$':'$';if(a>=1e12)return s+(a/1e12).toFixed(2)+'T';if(a>=1e9)return s+(a/1e9).toFixed(2)+'B';if(a>=1e6)return s+(a/1e6).toFixed(2)+'M';if(a>=1e4)return s+(a/1e3).toFixed(1)+'K';return s+Math.round(a).toLocaleString()};
if(typeof module!=='undefined')module.exports={trend,TYPES,TBY,UPG_GENERIC,bizStats,empire,newSave,newBiz,simulate,bizLevel,maxStaff,cleanSave,fmt$,upLv};
