/* Tycoon Town — 3D stores, people, orbit + walk cameras */
const GEO={},MAT={};
const gBox=(w,h,d)=>{const k='b'+w+'|'+h+'|'+d;return GEO[k]||(GEO[k]=new THREE.BoxGeometry(w,h,d))};
const gCyl=(a,b,h,n=12)=>{const k='c'+a+'|'+b+'|'+h+'|'+n;return GEO[k]||(GEO[k]=new THREE.CylinderGeometry(a,b,h,n))};
const gSph=(r,n=12)=>{const k='s'+r+'|'+n;return GEO[k]||(GEO[k]=new THREE.SphereGeometry(r,n,Math.max(6,n*.7|0)))};
const mL=(c,e)=>{const k=c+'|'+(e||0);return MAT[k]||(MAT[k]=new THREE.MeshLambertMaterial({color:c,emissive:e||0}))};
const GLASS=new THREE.MeshLambertMaterial({color:0xbfe8ff,transparent:true,opacity:.28,side:THREE.DoubleSide,depthWrite:false});
const WATER=new THREE.MeshLambertMaterial({color:0x3fa9ff,transparent:true,opacity:.45,depthWrite:false});
function bx(g,w,h,d,c,x,y,z,e){const m=new THREE.Mesh(gBox(w,h,d),mL(c,e));m.position.set(x,y,z);g.add(m);return m}
function cy(g,a,b,h,c,x,y,z,n){const m=new THREE.Mesh(gCyl(a,b,h,n),mL(c));m.position.set(x,y,z);g.add(m);return m}
function sp(g,r,c,x,y,z,e){const m=new THREE.Mesh(gSph(r),mL(c,e));m.position.set(x,y,z);g.add(m);return m}
const PK=(pal,i)=>pal[i%pal.length];
const R=(()=>{let s=1;return{seed(v){s=v>>>0||1},n(){s=(s*1664525+1013904223)>>>0;return s/4294967296}}})();

/* ---------- fixtures: each faces +z, returns {g,w,d} ---------- */
const FX={
  shelf(pal){const g=new THREE.Group();bx(g,2,1.8,.08,0x6b6f76,0,.9,-.26);bx(g,.06,1.8,.6,0x55585e,-.97,.9,0);bx(g,.06,1.8,.6,0x55585e,.97,.9,0);
    for(const y of[.12,.57,1.02,1.47]){bx(g,1.9,.04,.56,0x8a8f96,0,y,0);for(let i=0;i<6;i++){const h=.18+R.n()*.16;bx(g,.24,h,.3,PK(pal,(R.n()*9)|0),-.78+i*.31,y+.02+h/2,.02)}}return{g,w:2,d:.6}},
  bookcase(pal){const g=new THREE.Group();bx(g,2,2.1,.5,0x4a3020,0,1.05,0);for(const y of[.15,.65,1.15,1.65]){let x=-.9;while(x<.85){const w=.06+R.n()*.07,h=.3+R.n()*.12;bx(g,w,h,.36,PK(pal,(R.n()*9)|0),x+w/2,y+h/2,.06);x+=w+.01}}return{g,w:2,d:.5}},
  counter(pal,T){const g=new THREE.Group();bx(g,2,1,.8,0x2d2f36,0,.5,0);bx(g,2.1,.06,.9,new THREE.Color(T.acc).getHex(),0,1.03,0);bx(g,.4,.25,.3,0x222222,.5,1.2,-.1);bx(g,.36,.24,.04,0x55ffaa,.5,1.42,-.2,0x1a6640);return{g,w:2.1,d:.9,till:1}},
  table(pal){const g=new THREE.Group();cy(g,.55,.55,.06,0xf2efe8,0,.76,0,18);cy(g,.06,.06,.74,0x333333,0,.38,0);
    for(const[a,b]of[[0,.85],[0,-.85],[.85,0],[-.85,0]]){bx(g,.4,.45,.4,PK(pal,1),a,.23,b);bx(g,.4,.5,.06,PK(pal,1),a+(a?Math.sign(a)*.17:0),.7,b+(b?Math.sign(b)*.17:0))}return{g,w:1.9,d:1.9}},
  display(pal){const g=new THREE.Group();bx(g,1.6,.8,.8,0xeee7da,0,.4,0);for(let i=0;i<5;i++){const k=R.n();const x=-.6+i*.3;if(k<.4)bx(g,.2,.22,.2,PK(pal,i),x,.91,0);else if(k<.7)cy(g,.1,.1,.26,PK(pal,i+1),x,.93,0);else sp(g,.12,PK(pal,i+2),x,.92,0)}return{g,w:1.6,d:.8}},
  fridge(pal){const g=new THREE.Group();bx(g,1.8,2.1,.7,0xe8eef2,0,1.05,0);bx(g,1.6,1.8,.04,0x9fd8ff,0,1.1,.34,0x10303a);
    for(const y of[.5,1,1.5])for(let i=0;i<5;i++)bx(g,.18,.3,.18,PK(pal,i+((y*2)|0)),-.6+i*.3,y,.15);return{g,w:1.8,d:.7}},
  tv(pal){const g=new THREE.Group();bx(g,1.8,.6,.6,0x22252b,0,.3,0);cy(g,.05,.05,.5,0x333333,0,.85,-.1);bx(g,1.6,.95,.08,0x111111,0,1.5,-.1);bx(g,1.48,.84,.02,PK(pal,(R.n()*5)|0),0,1.5,-.05,PK(pal,(R.n()*5)|0));return{g,w:1.8,d:.6}},
  arcade(pal){const g=new THREE.Group();const c=PK(pal,(R.n()*5)|0);bx(g,.8,1.8,.8,0x1a1a2e,0,.9,0);bx(g,.82,.3,.82,c,0,1.95,0,c);const s=bx(g,.62,.5,.04,0x55ffff,0,1.35,.36,0x22aaaa);s.rotation.x=-.3;bx(g,.7,.12,.3,0x333333,0,.98,.42);return{g,w:.9,d:.9}},
  oven(pal){const g=new THREE.Group();bx(g,1.6,1.2,.9,0x8a8f96,0,.6,0);bx(g,1.1,.5,.04,0xff8a3d,0,.65,.45,0x7a2a00);bx(g,1.7,.08,1,0x5a5f66,0,1.24,0);cy(g,.12,.12,.8,0x5a5f66,.5,1.65,-.2);return{g,w:1.7,d:1}},
  gym(pal,T,i){const g=new THREE.Group();if(i%2){bx(g,.8,.25,1.8,0x222222,0,.15,0);bx(g,.7,.04,1.5,0x444444,0,.29,.05);bx(g,.06,1.1,.06,0x999999,-.35,.8,-.75);bx(g,.06,1.1,.06,0x999999,.35,.8,-.75);bx(g,.8,.3,.1,PK(pal,1),0,1.35,-.75,0x330000)}
    else{bx(g,.4,.45,1.4,PK(pal,1),0,.3,0);bx(g,1.8,.05,.05,0xaaaaaa,0,1.1,-.5);for(const x of[-.8,.8])cy(g,.22,.22,.12,0x111111,x,1.1,-.5).rotation.z=Math.PI/2;bx(g,.06,1.1,.06,0x999999,-.6,.55,-.5);bx(g,.06,1.1,.06,0x999999,.6,.55,-.5)}return{g,w:1.9,d:1.8}},
  cage(pal){const g=new THREE.Group();bx(g,1.6,.7,.8,0xdcdcdc,0,.35,0);bx(g,1.6,.05,.8,0x999999,0,1.4,0);for(let i=0;i<9;i++)cy(g,.015,.015,.7,0xaaaaaa,-.75+i*.19,1.05,.38,4);
    for(let i=0;i<2;i++){const c=PK(pal,i);sp(g,.16,c,-.4+i*.8,.88,0);sp(g,.1,c,-.25+i*.8,1.02,.08)}return{g,w:1.6,d:.8}},
  tank(pal){const g=new THREE.Group();bx(g,1.8,.8,.7,0x2a2f36,0,.4,0);const w=new THREE.Mesh(gBox(1.7,.9,.6),WATER);w.position.set(0,1.25,0);g.add(w);bx(g,1.7,.06,.6,0x2a2f36,0,1.73,0);
    for(let i=0;i<5;i++){const f=sp(g,.07,PK(pal,i),-.6+R.n()*1.2,1.0+R.n()*.5,-.15+R.n()*.3,PK(pal,i));f.scale.set(1.6,1,.6);f.userData.fish=R.n()*6}return{g,w:1.8,d:.7}},
  case(pal){const g=new THREE.Group();bx(g,1.6,.8,.7,0x2a2340,0,.4,0);const gl=new THREE.Mesh(gBox(1.55,.45,.65),GLASS);gl.position.set(0,1.03,0);g.add(gl);
    for(let i=0;i<6;i++)sp(g,.06,PK(pal,i),-.6+i*.24,.88,0,PK(pal,i));return{g,w:1.6,d:.7}},
  bucket(pal){const g=new THREE.Group();bx(g,1.8,.5,.7,0x6b4a2b,0,.25,0);for(let i=0;i<4;i++){cy(g,.18,.14,.35,0x3d5a80,-.66+i*.44,.68,0);for(let k=0;k<5;k++)sp(g,.08,PK(pal,i+k),-.66+i*.44+(R.n()-.5)*.25,.95+R.n()*.2,(R.n()-.5)*.2)}return{g,w:1.8,d:.7}},
  plant(){const g=new THREE.Group();cy(g,.28,.22,.5,0xc2703d,0,.25,0);for(let i=0;i<5;i++)sp(g,.28,i%2?0x3c8d40:0x2e7d32,(R.n()-.5)*.4,.75+R.n()*.5,(R.n()-.5)*.4);return{g,w:.7,d:.7}},
  rack(pal){const g=new THREE.Group();cy(g,.03,.03,1.6,0x999999,-.8,.8,0);cy(g,.03,.03,1.6,0x999999,.8,.8,0);const bar=cy(g,.025,.025,1.6,0xbbbbbb,0,1.55,0);bar.rotation.z=Math.PI/2;
    for(let i=0;i<7;i++){bx(g,.16,.7,.42,PK(pal,i),-.6+i*.2,1.15,0)}return{g,w:1.8,d:.6}},
  car(pal){const g=new THREE.Group(),c=PK(pal,(R.n()*5)|0);bx(g,3.8,.55,1.7,c,0,.55,0);const cab=bx(g,2,.5,1.5,c,-.2,1.07,0);bx(g,2.02,.38,1.52,0x223344,-.2,1.07,0,0x0a1620);
    for(const[x,z]of[[1.2,.8],[1.2,-.8],[-1.2,.8],[-1.2,-.8]]){const w=cy(g,.34,.34,.26,0x111111,x,.34,z,14);w.rotation.x=Math.PI/2}bx(g,.05,.12,.4,0xffffcc,1.9,.6,.5,0x666644);bx(g,.05,.12,.4,0xffffcc,1.9,.6,-.5,0x666644);
    return{g,w:3.9,d:1.8}},
  seats(pal){const g=new THREE.Group();for(let i=0;i<6;i++){bx(g,.5,.45,.5,0x8b0000,-1.4+i*.56,.25,0);bx(g,.5,.6,.1,0x8b0000,-1.4+i*.56,.7,-.22)}return{g,w:3.4,d:.6}},
};

/* ---------- people ---------- */
const SKIN=[0xf1c27d,0xe0ac69,0xc68642,0x8d5524,0xffdbac,0x5c3a21],SHIRT=[0xe63946,0x457b9d,0x2a9d8f,0xf4a261,0x8338ec,0xffbe0b,0x06d6a0,0xef476f,0x118ab2,0x666666];
function makePerson(shirt,uniform){const g=new THREE.Group(),legs=[];
  for(const x of[-.11,.11]){const p=new THREE.Group();p.position.set(x,.78,0);const l=new THREE.Mesh(gBox(.15,.78,.17),mL(0x2b2d42));l.position.y=-.39;p.add(l);g.add(p);legs.push(p)}
  bx(g,.48,.62,.28,shirt,0,1.08,0);if(uniform)bx(g,.5,.18,.3,0xffffff,0,1.3,0);sp(g,.2,pick(SKIN),0,1.58,0);const h=sp(g,.205,pick([0x222222,0x5a3a1a,0xc9a227,0x8b4513,0x111111]),0,1.64,-.02);h.scale.set(1,.7,1);
  g.userData.legs=legs;return g}

/* ---------- world ---------- */
const W3={scene:null,cam:null,r:null,root:null,people:[],staff:[],walls:[],col:[],mode:'orbit',orb:{th:.55,ph:1.0,d:24,tx:0,ty:1,tz:0},fp:{x:0,z:12,yaw:Math.PI,pitch:0},info:null,spawnT:0,coins:[]};
function worldInit(canvas){const r=W3.r=new THREE.WebGLRenderer({canvas,antialias:true});r.setPixelRatio(Math.min(2,devicePixelRatio||1));
  const s=W3.scene=new THREE.Scene();s.background=new THREE.Color(0x9fd3ff);s.fog=new THREE.Fog(0x9fd3ff,60,140);
  s.add(new THREE.HemisphereLight(0xffffff,0x6b7a55,.95));const d=new THREE.DirectionalLight(0xffffff,.65);d.position.set(10,20,12);s.add(d);
  W3.cam=new THREE.PerspectiveCamera(55,1,.1,400);W3.coinTex=(()=>{const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');x.fillStyle='#2ecc71';x.beginPath();x.arc(32,32,28,0,7);x.fill();x.fillStyle='#fff';x.font='bold 40px sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText('$',32,35);return new THREE.CanvasTexture(c)})();
  orbitInput(canvas);worldResize()}
function worldResize(){const c=W3.r.domElement,w=c.clientWidth||innerWidth,h=c.clientHeight||innerHeight;W3.r.setSize(w,h,false);W3.cam.aspect=w/h;W3.cam.updateProjectionMatrix()}
function signTex(text,bg,fg){const c=document.createElement('canvas');c.width=512;c.height=128;const x=c.getContext('2d');x.fillStyle=bg;x.fillRect(0,0,512,128);x.fillStyle=fg;
  let fs=64;x.font=`${fs}px Bungee, Impact, sans-serif`;while(x.measureText(text).width>480&&fs>20){fs-=4;x.font=`${fs}px Bungee, Impact, sans-serif`}x.textAlign='center';x.textBaseline='middle';x.fillText(text,256,68);const t=new THREE.CanvasTexture(c);return t}
/* build the scene for one business (yours or someone else's) */
function buildStore(b){const T=TBY[b.t];if(W3.root){W3.scene.remove(W3.root);W3.root.traverse(o=>{if(o.material&&o.material.map&&o.material.map!==W3.coinTex){o.material.map.dispose();o.material.dispose()}})}
  W3.people=[];W3.staff=[];W3.coins=[];W3.walls=[];W3.col=[];R.seed(b.id*7919+b.t.length*31+1);
  const root=W3.root=new THREE.Group();W3.scene.add(root);const sz=upLv(b,'size'),W=12+5*sz,D=9+3*sz,H=4;
  const side=T.out?10:0;
  /* ground, lot, street */
  bx(root,200,.1,200,0x7dbb5a,0,-.06,0);bx(root,W+8+side*2,.04,D+8,0x6b7078,side/2,0,-1);bx(root,W+60,.06,3,0xcfcfc6,0,.02,D/2+2.2);bx(root,W+60,.05,7,0x34373c,0,.01,D/2+7.2);
  for(let x=-(W+60)/2;x<(W+60)/2;x+=4)bx(root,2,.02,.18,0xffd23f,x+1,.05,D/2+7.2);
  for(let i=0;i<10;i++){const x=(i<5?-1:1)*(W/2+side+8+((i%5)*6)),z=-D/2-4+(i%3)*5;cy(root,.25,.3,1.4,0x7a4a2a,x,.7,z);sp(root,1.4,0x2e8b3e,x,2.3,z)}
  /* floor + walls (walls hide when the orbit camera is outside them) */
  bx(root,W,.1,D,T.floor,0,.05,0);
  const wallC=T.wall,trim=new THREE.Color(wallC).multiplyScalar(.7).getHex();
  const mkWall=(w,h,d,x,z,nx,nz)=>{const g=new THREE.Group();bx(g,w,h,d,wallC,0,h/2,0);bx(g,w+.1,.3,d+.1,trim,0,h+.15,0);g.position.set(x,0,z);g.userData={nx,nz,x,z};root.add(g);W3.walls.push(g)};
  mkWall(W,H,.25,0,-D/2,0,-1);mkWall(.25,H,D,-W/2,0,-1,0);mkWall(.25,H,D,W/2,0,1,0);
  W3.col.push([-W/2-.2,W/2+.2,-D/2-.2,-D/2+.2],[-W/2-.2,-W/2+.2,-D/2,D/2],[W/2-.2,W/2+.2,-D/2,D/2]);
  /* front: glass with a door gap, header and sign */
  const gw=(W-2.4)/2;for(const s of[-1,1]){const p=new THREE.Mesh(gBox(gw,H-.6,.08),GLASS);p.position.set(s*(1.2+gw/2),(H-.6)/2,D/2);root.add(p);bx(root,.12,H,.12,trim,s*W/2,H/2,D/2);bx(root,.1,H-.6,.12,trim,s*1.2,(H-.6)/2,D/2);W3.col.push([s>0?1.2:-W/2,s>0?W/2:-1.2,D/2-.15,D/2+.15])}
  bx(root,W+.2,.6,.3,trim,0,H-.3,D/2);bx(root,2.2,.04,1.2,0x333333,0,.11,D/2+.2);
  const sw=Math.min(W-2,7);const sg=new THREE.Mesh(new THREE.PlaneGeometry(sw,sw/4),new THREE.MeshBasicMaterial({map:signTex(b.n.toUpperCase(),'#13202b',T.acc)}));sg.position.set(0,H+sw/8+.05,D/2+.2);root.add(sg);bx(root,sw+.25,sw/4+.25,.3,trim,0,H+sw/8+.05,D/2);
  /* ceiling (only visible from inside) + lights */
  const lights=W3.lights=new THREE.Group();root.add(lights);const ceil=new THREE.Mesh(new THREE.PlaneGeometry(W,D),mL(0xf4f4f0));ceil.rotation.x=Math.PI/2;ceil.position.y=H;lights.add(ceil);
  for(let x=-W/2+3;x<W/2-1;x+=4)for(let z=-D/2+2.5;z<D/2-1;z+=4)bx(lights,1.4,.05,.3,0xffffff,x,H-.04,z,0xffffee);lights.visible=W3.mode==='walk';
  /* ads posters + decor */
  for(let i=0;i<upLv(b,'ads');i++){const x=-W/2+2+i*(W-4)/Math.max(1,upLv(b,'ads'));bx(root,1.4,1,.04,PK(T.pal,i),x+.7,2.4,-D/2+.15,PK(T.pal,i))}
  /* fixtures on a grid: cells back to front, centre aisle kept clear */
  const c=T.cell,cells=[];const zs=[];for(let z=-D/2+.6;z+c<=D/2-3;z+=c)zs.push(z);
  for(const z of zs)for(let k=0;.7+c/2+k*c+c/2<=W/2-.35;k++)for(const s of[-1,1])cells.push({x:s*(.7+c/2+k*c),z,lane:z+c});
  const list=[];for(const u of T.up)if(upLv(b,u.id)&&u.fx)list.push(...u.fx);const base=T.fx.length+2*sz+upLv(b,'decor');for(let i=0;i<base;i++)list.push(T.fx[i%T.fx.length]);for(let i=0;i<upLv(b,'decor');i++)list.push('plant');
  const tills=[],browse=[],staffSpots=[];
  const place=(kind,x,z,rot=0,i=0)=>{const f=FX[kind](T.pal,T,i);f.g.position.set(x,0,z);f.g.rotation.y=rot;root.add(f.g);const hw=(rot?f.d:f.w)/2+.15,hd=(rot?f.w:f.d)/2+.15;W3.col.push([x-hw,x+hw,z-hd,z+hd]);
    if(kind==='tank')f.g.traverse(o=>{if(o.userData.fish!==undefined)W3.people.push({fish:o,ph:o.userData.fish,bx:o.position.x})});return f};
  /* main till at the front left */
  const tc=place('counter',-W/2+2.4,D/2-2.2);tills.push({x:-W/2+2.4,z:D/2-1.2});staffSpots.push({x:-W/2+2.4,z:D/2-3,ry:0});
  if(T.big==='screen'){const s=bx(root,W-3,H-1.2,.1,0xddeeff,0,H/2+.3,-D/2+.2,0x8899aa);}
  list.slice(0,cells.length).forEach((k,i)=>{const cl=cells[i];const f=place(k,cl.x,cl.z+((FX[k]?0:0)),0,i);const fz=cl.z+f.d/2+.1;f.g.position.z=fz;W3.col[W3.col.length-1]=[cl.x-f.w/2-.15,cl.x+f.w/2+.15,fz-f.d/2-.15,fz+f.d/2+.15];
    browse.push({x:cl.x+(R.n()-.5)*.6,z:Math.min(cl.lane-.35,fz+f.d/2+.65),lane:Math.min(cl.lane-.3,fz+f.d/2+.9)});if(k==='counter'){tills.push({x:cl.x,z:fz+1});staffSpots.push({x:cl.x,z:fz-.9,ry:0})}else if(i%3===1)staffSpots.push({x:cl.x+1.1,z:fz+f.d/2+.5,ry:Math.PI})});
  /* outside extras */
  if(T.out==='pump'){const cx=W/2+side/2+2;bx(root,8,.25,5.5,0xdddddd,cx,4.6,2.5,0x222222);for(const px of[-1,1])bx(root,.3,4.5,.3,0xcccccc,cx+px*3,2.3,2.5);
    for(let i=0;i<1+Math.min(3,sz+1);i++){const z=-1+i*2.2;bx(root,.6,1.5,.5,0xff6b35,cx,.75,z);bx(root,.4,.3,.04,0x111111,cx,1.2,z+.26,0x003311);W3.col.push([cx-.4,cx+.4,z-.35,z+.35])}}
  if(T.out==='car'){const cx=W/2+side/2+1;for(let i=0;i<2+sz;i++){const f=FX.car(T.pal);f.g.position.set(cx,0,-D/2+2.5+i*2.6);f.g.rotation.y=Math.PI/2*0;root.add(f.g);W3.col.push([cx-2,cx+2,-D/2+1.6+i*2.6,-D/2+3.4+i*2.6])}}
  W3.info={W,D,H,tills,browse,staffSpots,T,b};
  /* staff */
  const ns=Math.min(b.staff,staffSpots.length+2);for(let i=0;i<ns;i++){const p=makePerson(new THREE.Color(T.acc).getHex(),true);const s=staffSpots[i%staffSpots.length];p.position.set(s.x+(i>=staffSpots.length?.8:0),0,s.z);p.rotation.y=s.ry||0;root.add(p);W3.staff.push({g:p,ph:R.n()*6})}
  W3.spawnT=0;if(W3.mode==='walk')resetWalk();W3.orb.d=Math.min(70,Math.max(W3.orb.d,14+sz*5))}
function resetWalk(){const I=W3.info;W3.fp={x:0,z:I.D/2+5,yaw:0,pitch:-.05}}
/* customers walk door -> aisle -> shelf -> till -> door */
function spawnCustomer(){const I=W3.info;if(!I||!I.browse.length)return;const sideS=Math.random()<.5?-1:1,D=I.D,W=I.W,ex=sideS*(W/2+12),sw=D/2+1.6;
  const br=pick(I.browse),till=pick(I.tills),p=makePerson(pick(SHIRT));p.position.set(ex,0,sw);W3.root.add(p);
  const pts=[[0,sw],[0,D/2-1],[0,br.lane],[br.x,br.lane],[br.x,br.z,'wait',1.5+Math.random()*2.5],[br.x,br.lane],[0,br.lane],[0,till.z+.4],[till.x+.5,till.z+.4],[till.x,till.z,'pay',1.4],[0,till.z+.6],[0,D/2-1],[0,sw],[-ex,sw]];
  W3.people.push({g:p,pts,i:0,w:0,sp:1.3+Math.random()*.5})}
function coinPop(x,y,z){const s=new THREE.Sprite(new THREE.SpriteMaterial({map:W3.coinTex,transparent:true}));s.scale.set(.6,.6,.6);s.position.set(x,y,z);W3.root.add(s);W3.coins.push({s,t:0})}
function worldTick(dt,rate,onPay){const I=W3.info;if(!I)return;const t=performance.now()/1000;
  W3.spawnT-=dt;const cap=14+6*upLv(I.b,'size');const live=W3.people.filter(p=>p.g).length;if(W3.spawnT<=0&&live<cap){spawnCustomer();W3.spawnT=rate*(.6+Math.random()*.8)}
  W3.people=W3.people.filter(p=>{if(p.fish){p.fish.position.x=p.bx+Math.sin(t*.8+p.ph)*.35;p.fish.rotation.y=Math.cos(t*.8+p.ph)>0?0:Math.PI;return true}
    const g=p.g,pt=p.pts[p.i];if(p.w>0){p.w-=dt;g.userData.legs.forEach(l=>l.rotation.x*=.8);if(p.w<=0)p.i++;return true}
    const dx=pt[0]-g.position.x,dz=pt[1]-g.position.z,d=Math.hypot(dx,dz);
    if(d<.08){if(pt[2]){p.w=pt[3];if(pt[2]==='pay'){coinPop(g.position.x,2.3,g.position.z);onPay&&onPay()}}else p.i++;if(p.i>=p.pts.length){W3.root.remove(g);return false}return true}
    const st=Math.min(d,p.sp*dt);g.position.x+=dx/d*st;g.position.z+=dz/d*st;g.rotation.y=Math.atan2(dx,dz);const sw=Math.sin(t*9*p.sp)*.5;g.userData.legs[0].rotation.x=sw;g.userData.legs[1].rotation.x=-sw;return true});
  W3.staff.forEach(s=>{s.g.position.y=Math.abs(Math.sin(t*2+s.ph))*.03});
  W3.coins=W3.coins.filter(c=>{c.t+=dt;c.s.position.y+=dt*1.2;c.s.material.opacity=1-c.t;if(c.t>=1){W3.root.remove(c.s);c.s.material.dispose();return false}return true})}

/* ---------- cameras ---------- */
const PT=new Map();let pinch=null;const keysW={};
function orbitInput(cv){
  cv.addEventListener('pointerdown',e=>{try{cv.setPointerCapture(e.pointerId)}catch(_){}PT.set(e.pointerId,{x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,left:e.pointerType!=='mouse'&&e.clientX<cv.getBoundingClientRect().left+cv.clientWidth/2,btn:e.button,sh:e.shiftKey});pinch=null});
  cv.addEventListener('pointermove',e=>{const p=PT.get(e.pointerId);if(!p)return;const dx=e.clientX-p.x,dy=e.clientY-p.y;p.x=e.clientX;p.y=e.clientY;
    if(W3.mode==='orbit'){if(PT.size===1){if(p.btn===2||p.sh)orbPan(dx,dy);else{W3.orb.th-=dx*.006;W3.orb.ph=Math.max(.2,Math.min(1.45,W3.orb.ph-dy*.005))}}
      else if(PT.size===2){const a=[...PT.values()];const dd=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),mx=(a[0].x+a[1].x)/2,my=(a[0].y+a[1].y)/2;if(pinch){W3.orb.d=Math.max(6,Math.min(80,W3.orb.d*pinch.d/Math.max(20,dd)));orbPan(mx-pinch.mx,my-pinch.my)}pinch={d:dd,mx,my}}}
    else{if(!p.left){W3.fp.yaw-=dx*.005;W3.fp.pitch=Math.max(-1.2,Math.min(1.2,W3.fp.pitch-dy*.004))}}});
  const up=e=>{PT.delete(e.pointerId);pinch=null};cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
  cv.addEventListener('wheel',e=>{e.preventDefault();if(W3.mode==='orbit')W3.orb.d=Math.max(6,Math.min(80,W3.orb.d*Math.exp(e.deltaY*.0012)))},{passive:false});
  cv.addEventListener('contextmenu',e=>e.preventDefault());
  addEventListener('keydown',e=>{if(e.target.tagName==='INPUT')return;keysW[e.code]=true});addEventListener('keyup',e=>keysW[e.code]=false);addEventListener('blur',()=>{for(const k in keysW)keysW[k]=false})}
function orbPan(dx,dy){const o=W3.orb,k=o.d*.0016,c=Math.cos(o.th),s=Math.sin(o.th);const I=W3.info||{W:20,D:20};
  o.tx=Math.max(-I.W/2-12,Math.min(I.W/2+12,o.tx-(dx*c)*k-(dy*s)*k));o.tz=Math.max(-I.D/2-8,Math.min(I.D/2+10,o.tz+(dx*s)*k-(dy*c)*k))}
function walkJoy(){for(const p of PT.values())if(p.left){const dx=p.x-p.sx,dy=p.y-p.sy,d=Math.hypot(dx,dy);if(d<8)return{x:0,y:0,on:1,sx:p.sx,sy:p.sy,cx:p.x,cy:p.y};const m=Math.min(1,d/55)/d;return{x:dx*m,y:dy*m,on:1,sx:p.sx,sy:p.sy,cx:p.x,cy:p.y}}return null}
function collide(x,z,r){for(const[a,b,c,d]of W3.col){const cx=Math.max(a,Math.min(b,x)),cz=Math.max(c,Math.min(d,z)),dx=x-cx,dz=z-cz,dd=Math.hypot(dx,dz);
    if(dd<r){if(dd>1e-6){x=cx+dx/dd*r;z=cz+dz/dd*r}else{const o=[x-a,b-x,z-c,d-z],m=Math.min(...o);if(m===o[0])x=a-r;else if(m===o[1])x=b+r;else if(m===o[2])z=c-r;else z=d+r}}}return[x,z]}
function camUpdate(dt){const cam=W3.cam,I=W3.info;const c=W3.r.domElement,cw=c.clientWidth,ch=c.clientHeight;const ox=W3.offX||0,oy=W3.offY||0;if(ox||oy)cam.setViewOffset(cw,ch,ox,oy,cw,ch);else if(cam.view)cam.clearViewOffset();
  if(W3.mode==='orbit'){const o=W3.orb,sp=Math.sin(o.ph);cam.position.set(o.tx+o.d*sp*Math.sin(o.th),o.ty+o.d*Math.cos(o.ph),o.tz+o.d*sp*Math.cos(o.th));cam.lookAt(o.tx,o.ty,o.tz);
    for(const w of W3.walls){const u=w.userData;w.visible=!((u.nz<0&&cam.position.z<u.z)||(u.nx<0&&cam.position.x<u.x)||(u.nx>0&&cam.position.x>u.x))}}
  else{const f=W3.fp;let mx=0,mz=0;if(keysW.KeyW||keysW.ArrowUp)mz-=1;if(keysW.KeyS||keysW.ArrowDown)mz+=1;if(keysW.KeyA||keysW.ArrowLeft)mx-=1;if(keysW.KeyD||keysW.ArrowRight)mx+=1;
    const j=walkJoy();if(j){mx=j.x;mz=j.y}const l=Math.hypot(mx,mz);if(l>1){mx/=l;mz/=l}const s=3.2*dt,c=Math.cos(f.yaw),sn=Math.sin(f.yaw);
    let nx=f.x+(mx*c+mz*sn)*s,nz=f.z+(-mx*sn+mz*c)*s;[nx,nz]=collide(nx,nz,.32);if(I){nx=Math.max(-I.W/2-30,Math.min(I.W/2+30,nx));nz=Math.max(-I.D/2-20,Math.min(I.D/2+14,nz))}f.x=nx;f.z=nz;
    cam.position.set(f.x,1.6,f.z);cam.rotation.order='YXZ';cam.rotation.set(f.pitch,f.yaw,0);W3.walls.forEach(w=>w.visible=true)}if(W3.lights)W3.lights.visible=W3.mode==='walk'}
function worldRender(){W3.r.render(W3.scene,W3.cam)}
